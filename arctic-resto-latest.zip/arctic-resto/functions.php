<?php
/**
 * Arctic Resto theme bootstrap.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AR_VERSION', '1.2.1' );
define( 'AR_DIR', get_template_directory() );
define( 'AR_URI', get_template_directory_uri() );

require_once AR_DIR . '/inc/helpers.php';
require_once AR_DIR . '/inc/setup.php';
require_once AR_DIR . '/inc/optimize.php';
require_once AR_DIR . '/inc/post-types.php';
require_once AR_DIR . '/inc/customizer.php';
require_once AR_DIR . '/inc/portal.php';
require_once AR_DIR . '/inc/territory.php';
require_once AR_DIR . '/inc/seo.php';
require_once AR_DIR . '/inc/ai.php';
require_once AR_DIR . '/inc/forms.php';
require_once AR_DIR . '/inc/elementor.php';

if ( is_admin() ) {
	require_once AR_DIR . '/inc/demo-importer.php';
}
