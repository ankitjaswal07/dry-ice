<?php
/**
 * Default site header: top bar (message, franchise portal log in / register, contact),
 * sticky main navigation and the mobile drawer.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$cta_text = ar_mod( 'ar_cta_text', 'Get Instant Quote' );
$cta_url  = ar_abs_url( ar_mod( 'ar_cta_url', '/estimator/' ) );
$topbar   = ar_mod( 'ar_topbar', 'Now serving New Jersey & Connecticut · Franchise territories available' );
?>
<header class="ar-header" id="ar-header">
	<div class="ar-topbar">
		<div class="ar-wrap">
			<p class="ar-topbar__msg"><?php if ( $topbar ) : ?><span class="ar-live"></span><?php echo esc_html( $topbar ); ?><?php endif; ?></p>
			<div class="ar-topbar__right">
				<?php echo ar_portal_links_html( 'top' ); // phpcs:ignore ?>
				<a class="ar-topbar__tel" href="<?php echo esc_url( ar_phone_href() ); ?>"><?php echo esc_html( ar_phone() ); ?></a>
				<a class="ar-topbar__mail" href="mailto:<?php echo esc_attr( ar_email() ); ?>"><?php echo esc_html( ar_email() ); ?></a>
			</div>
		</div>
	</div>
	<div class="ar-bar-main">
		<div class="ar-wrap ar-bar-main__in">
			<a class="ar-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
				<?php if ( has_custom_logo() ) : ?>
					<?php echo wp_kses_post( get_custom_logo() ); ?>
				<?php else : ?>
					<span class="ar-logo__mark"><?php echo ar_svg( 'snow', 'ar-i ar-logo__i' ); // phpcs:ignore ?></span>
					<span class="ar-logo__text">Arctic<b> Resto</b></span>
				<?php endif; ?>
			</a>

			<nav class="ar-nav" id="ar-nav" aria-label="<?php esc_attr_e( 'Primary', 'arctic-resto' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'ar-menu',
						'fallback_cb'    => 'ar_fallback_menu',
						'depth'          => 2,
					)
				);
				?>
				<div class="ar-nav__mobile">
					<?php echo ar_portal_links_html( 'drawer' ); // phpcs:ignore ?>
					<a class="ar-nav__phone" href="<?php echo esc_url( ar_phone_href() ); ?>"><?php echo ar_svg( 'phone' ); // phpcs:ignore ?> <?php echo esc_html( ar_phone() ); ?></a>
					<a class="ar-btn ar-btn--primary" href="<?php echo esc_url( $cta_url ); ?>"><span><?php echo esc_html( $cta_text ); ?></span></a>
				</div>
			</nav>

			<a class="ar-btn ar-btn--primary ar-header__cta" href="<?php echo esc_url( $cta_url ); ?>"><span><?php echo esc_html( $cta_text ); ?></span></a>
			<button class="ar-burger" type="button" aria-controls="ar-nav" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'arctic-resto' ); ?>"><?php echo ar_svg( 'menu' ); // phpcs:ignore ?></button>
		</div>
	</div>
</header>
