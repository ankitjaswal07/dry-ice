<?php
/**
 * Default site footer.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$socials = array(
	'ar_facebook'  => 'Facebook',
	'ar_instagram' => 'Instagram',
	'ar_linkedin'  => 'LinkedIn',
	'ar_youtube'   => 'YouTube',
);
$fr      = get_page_by_path( 'franchise' );
?>
<footer class="ar-footer">
	<div class="ar-footer__cta">
		<div class="ar-wrap">
			<div>
				<h2><?php esc_html_e( 'Ready for that', 'arctic-resto' ); ?> <span class="ar-grad"><?php esc_html_e( 'safe, clean feeling?', 'arctic-resto' ); ?></span></h2>
				<p><?php esc_html_e( 'Book a free assessment, or explore owning your own mobile dry ice cleaning business.', 'arctic-resto' ); ?></p>
			</div>
			<div class="ar-actions">
				<a class="ar-btn ar-btn--primary" href="<?php echo esc_url( ar_abs_url( ar_mod( 'ar_cta_url', '/estimator/' ) ) ); ?>"><span><?php echo esc_html( ar_mod( 'ar_cta_text', 'Get Instant Quote' ) ); ?></span><?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></a>
				<a class="ar-btn ar-btn--ghost" href="<?php echo esc_url( $fr ? get_permalink( $fr ) : home_url( '/franchise/' ) ); ?>"><span><?php esc_html_e( 'Own a Franchise', 'arctic-resto' ); ?></span></a>
			</div>
		</div>
	</div>

	<div class="ar-wrap ar-footer__cols">
		<div class="ar-footer__brand">
			<a class="ar-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<span class="ar-logo__mark"><?php echo ar_svg( 'snow', 'ar-i ar-logo__i' ); // phpcs:ignore ?></span>
				<span class="ar-logo__text">Arctic<b> Resto</b></span>
			</a>
			<p><?php echo esc_html( ar_mod( 'ar_footer_text', '' ) ); ?></p>
			<form class="ar-news" data-ar-form method="post" action="#" novalidate>
				<input type="hidden" name="action" value="ar_form"><input type="hidden" name="form_type" value="newsletter"><input type="hidden" name="ts" value=""><input class="ar-hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
				<input type="email" name="email" required placeholder="<?php esc_attr_e( 'Your email for tips & news', 'arctic-resto' ); ?>" aria-label="<?php esc_attr_e( 'Email address', 'arctic-resto' ); ?>">
				<button type="submit" aria-label="<?php esc_attr_e( 'Subscribe', 'arctic-resto' ); ?>"><?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></button>
				<p class="ar-form__msg" role="status" aria-live="polite"></p>
			</form>
			<p class="ar-social">
				<?php foreach ( $socials as $k => $label ) : ?>
					<?php if ( ar_mod( $k ) ) : ?><a href="<?php echo esc_url( ar_mod( $k ) ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $label ); ?>"><?php echo esc_html( strtoupper( substr( $label, 0, 2 ) ) ); ?></a><?php endif; ?>
				<?php endforeach; ?>
			</p>
		</div>

		<div>
			<h3><?php esc_html_e( 'Services', 'arctic-resto' ); ?></h3>
			<?php
			if ( has_nav_menu( 'footer_services' ) ) {
				wp_nav_menu( array( 'theme_location' => 'footer_services', 'container' => false, 'depth' => 1 ) );
			} else {
				echo '<ul>';
				foreach ( ar_get_services() as $p ) {
					echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
				}
				echo '</ul>';
			}
			?>
		</div>

		<div>
			<h3><?php esc_html_e( 'Company', 'arctic-resto' ); ?></h3>
			<?php
			if ( has_nav_menu( 'footer_company' ) ) {
				wp_nav_menu( array( 'theme_location' => 'footer_company', 'container' => false, 'depth' => 1 ) );
			} else {
				echo '<ul>';
				wp_list_pages( array( 'title_li' => '', 'depth' => 1, 'number' => 8 ) );
				echo '</ul>';
			}
			$terr = ar_get_territories();
			if ( $terr ) :
				?>
				<h3 class="ar-footer__sub"><?php esc_html_e( 'Territories', 'arctic-resto' ); ?></h3>
				<ul>
					<?php foreach ( $terr as $t ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $t ) ); ?>"><?php echo esc_html( get_the_title( $t ) ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div>
			<h3><?php esc_html_e( 'Get in touch', 'arctic-resto' ); ?></h3>
			<ul class="ar-footer__contact">
				<li><?php echo ar_svg( 'phone' ); // phpcs:ignore ?><a href="<?php echo esc_url( ar_phone_href() ); ?>"><?php echo esc_html( ar_phone() ); ?></a></li>
				<li><?php echo ar_svg( 'mail' ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( ar_email() ); ?>"><?php echo esc_html( ar_email() ); ?></a></li>
				<li><?php echo ar_svg( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( ar_location() ); ?></span></li>
			</ul>
			<h3 class="ar-footer__sub"><?php echo esc_html( ar_mod( 'ar_portal_label', 'Franchise Portal' ) ); ?></h3>
			<ul class="ar-footer__contact">
				<?php if ( ar_portal_state() ) : ?>
					<li><?php echo ar_svg( 'lock' ); // phpcs:ignore ?><a href="<?php echo esc_url( ar_portal_dashboard_url() ); ?>"><?php esc_html_e( 'Dashboard', 'arctic-resto' ); ?></a></li>
					<li><?php echo ar_svg( 'arrow' ); // phpcs:ignore ?><a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Log out', 'arctic-resto' ); ?></a></li>
				<?php else : ?>
					<li><?php echo ar_svg( 'lock' ); // phpcs:ignore ?><a href="<?php echo esc_url( ar_portal_login_url() ); ?>"><?php esc_html_e( 'Franchise portal log in', 'arctic-resto' ); ?></a></li>
					<li><?php echo ar_svg( 'user' ); // phpcs:ignore ?><a href="<?php echo esc_url( ar_portal_register_url() ); ?>"><?php esc_html_e( 'Register for the portal', 'arctic-resto' ); ?></a></li>
				<?php endif; ?>
			</ul>
		</div>
	</div>

	<div class="ar-footer__bottom">
		<div class="ar-wrap">
			<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'arctic-resto' ); ?></p>
			<p><?php echo esc_html( ar_mod( 'ar_legal_text', '' ) ); ?></p>
		</div>
	</div>
</footer>
