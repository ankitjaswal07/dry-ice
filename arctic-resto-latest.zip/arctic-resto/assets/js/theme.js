/*!
 * Arctic Resto – theme.js
 * Dependency-free. Every module is idempotent and scoped, so it also runs
 * inside the Elementor editor whenever a widget is re-rendered.
 */
(function () {
  'use strict';

  var d = document;
  var w = window;
  var reduce = !!(w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var I18N = (w.ARC && w.ARC.i18n) || {};

  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }
  function once(el, k) {
    // Distinct prefix: several widgets are *selected* by data-ar-<name>, so the
    // "already initialised" marker must never reuse those attribute names.
    var a = 'data-ar-init-' + k;
    if (el.hasAttribute(a)) { return false; }
    el.setAttribute(a, '1');
    return true;
  }
  function scope(root, sel) {
    var out = $$(sel, root);
    if (root && root.matches && root.matches(sel)) { out.unshift(root); }
    return out;
  }
  function editor() { return d.body && d.body.classList.contains('elementor-editor-active'); }

  /* ---------------------------------------------------------- reveal */
  var io = null;
  function revealDone(el) {
    el.classList.add('is-in');
    var delay = parseInt(el.style.getPropertyValue('--d') || '0', 10) || 0;
    // Strip the reveal hooks afterwards so hover transforms (tilt) stay snappy.
    setTimeout(function () { el.removeAttribute('data-ar-reveal'); el.classList.remove('is-in'); }, 1100 + delay);
  }
  function reveal(root) {
    var els = scope(root, '[data-ar-reveal]:not(.is-in)');
    if (!els.length) { return; }
    if (editor() || reduce || !('IntersectionObserver' in w)) {
      els.forEach(function (el) { el.removeAttribute('data-ar-reveal'); });
      return;
    }
    io = io || new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { io.unobserve(e.target); revealDone(e.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  /* -------------------------------------------------------- counters */
  function counters(root) {
    scope(root, '[data-ar-count]').forEach(function (el) {
      if (!once(el, 'cnt')) { return; }
      var to = parseFloat(el.getAttribute('data-to')) || 0;
      var pre = el.getAttribute('data-prefix') || '';
      var suf = el.getAttribute('data-suffix') || '';
      var dec = (String(to).split('.')[1] || '').length;
      function fmt(v) {
        return pre + v.toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
      }
      function run() {
        if (reduce || editor() || to === 0) { el.textContent = fmt(to); return; }
        var s = performance.now();
        (function tick(n) {
          var p = Math.min((n - s) / 1800, 1);
          var e = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
          el.textContent = fmt(to * e);
          if (p < 1) { requestAnimationFrame(tick); }
        })(s);
      }
      if ('IntersectionObserver' in w) {
        var o = new IntersectionObserver(function (en) {
          if (en[0].isIntersecting) { o.disconnect(); run(); }
        }, { threshold: 0.4 });
        o.observe(el);
      } else { run(); }
    });
  }

  /* ------------------------------------------------------- particles */
  function particles(root) {
    scope(root, '[data-ar-particles]').forEach(function (host) {
      if (!once(host, 'pt')) { return; }
      var c = d.createElement('canvas');
      var x = c.getContext('2d');
      if (!x) { return; }
      host.appendChild(c);
      var W = 0, H = 0, ps = [], raf = 0, visible = true;
      var mouse = { x: -999, y: -999 };
      function make() {
        return { x: Math.random() * W, y: Math.random() * H, r: Math.random() * 2.2 + 0.4, vy: Math.random() * 0.4 + 0.12, vx: 0, a: Math.random() * 6.28, s: Math.random() * 0.015 + 0.004, o: Math.random() * 0.5 + 0.15 };
      }
      function size() {
        var dpr = Math.min(w.devicePixelRatio || 1, 2);
        W = host.clientWidth; H = host.clientHeight;
        c.width = W * dpr; c.height = H * dpr;
        c.style.width = W + 'px'; c.style.height = H + 'px';
        x.setTransform(dpr, 0, 0, dpr, 0, 0);
        var n = Math.max(24, Math.min(130, Math.floor(W * H * 0.00005)));
        ps = [];
        for (var i = 0; i < n; i++) { ps.push(make()); }
      }
      function draw() {
        x.clearRect(0, 0, W, H);
        for (var i = 0; i < ps.length; i++) {
          var p = ps[i];
          p.a += p.s;
          var dx = p.x - mouse.x, dy = p.y - mouse.y, dist = Math.hypot(dx, dy);
          if (dist < 120) { p.vx += (dx / (dist || 1)) * ((120 - dist) / 120) * 0.6; }
          p.vx *= 0.94;
          p.x += Math.sin(p.a) * 0.35 + p.vx;
          p.y += p.vy;
          if (p.y > H + 6) { p.y = -6; p.x = Math.random() * W; }
          if (p.x > W + 6) { p.x = -6; } else if (p.x < -6) { p.x = W + 6; }
          x.beginPath();
          x.fillStyle = 'rgba(200,240,255,' + p.o + ')';
          x.arc(p.x, p.y, p.r, 0, 6.283);
          x.fill();
        }
        if (!reduce && visible && host.isConnected) { raf = requestAnimationFrame(draw); }
      }
      size(); draw();
      w.addEventListener('resize', size, { passive: true });
      host.parentNode.addEventListener('mousemove', function (e) {
        var r = host.getBoundingClientRect();
        mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top;
      }, { passive: true });
      if ('IntersectionObserver' in w) {
        new IntersectionObserver(function (en) {
          visible = en[0].isIntersecting;
          if (visible && !reduce) { cancelAnimationFrame(raf); draw(); }
        }).observe(host);
      }
    });
  }

  /* ---------------------------------------------------- word rotator */
  function rotator(root) {
    scope(root, '[data-ar-rotator]').forEach(function (el) {
      if (!once(el, 'rot')) { return; }
      var words = (el.getAttribute('data-words') || '').split('|').filter(Boolean);
      if (words.length < 2 || reduce) { return; }
      var i = 0, span = el.firstElementChild;
      var t = setInterval(function () {
        if (!el.isConnected) { clearInterval(t); return; }
        i = (i + 1) % words.length;
        var n = span.cloneNode(false); // re-inserting restarts the CSS animation
        n.textContent = words[i];
        el.replaceChild(n, span);
        span = n;
      }, 2400);
    });
  }

  /* ------------------------------------------------- tilt + spotlight */
  function tilt(root) {
    scope(root, '[data-ar-tilt]').forEach(function (el) {
      if (!once(el, 'tl')) { return; }
      el.addEventListener('mousemove', function (e) {
        var r = el.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
        el.style.setProperty('--mx', px + 'px');
        el.style.setProperty('--my', py + 'px');
        if (!reduce) {
          el.style.transform = 'perspective(900px) rotateX(' + ((py / r.height - 0.5) * -5) + 'deg) rotateY(' + ((px / r.width - 0.5) * 5) + 'deg)';
        }
      });
      el.addEventListener('mouseleave', function () { el.style.transform = ''; });
    });
  }

  /* -------------------------------------------------------- carousel */
  function carousel(root) {
    scope(root, '[data-ar-carousel]').forEach(function (el) {
      if (!once(el, 'car')) { return; }
      var slides = $$('.ar-slide', el), dots = $$('.ar-dots button', el), i = 0, t;
      function go(n) {
        i = (n + slides.length) % slides.length;
        slides.forEach(function (s, k) { s.classList.toggle('is-active', k === i); });
        dots.forEach(function (b, k) { b.classList.toggle('is-active', k === i); });
      }
      function auto() {
        clearInterval(t);
        if (reduce || editor() || slides.length < 2) { return; }
        t = setInterval(function () { if (!el.isConnected) { clearInterval(t); return; } go(i + 1); }, 6500);
      }
      dots.forEach(function (b, k) { b.addEventListener('click', function () { go(k); auto(); }); });
      $$('.ar-arrows button', el).forEach(function (b) {
        b.addEventListener('click', function () { go(i + parseInt(b.getAttribute('data-dir'), 10)); auto(); });
      });
      el.addEventListener('mouseenter', function () { clearInterval(t); });
      el.addEventListener('mouseleave', auto);
      auto();
    });
  }

  /* ------------------------------------------------------------- FAQ */
  function faq(root) {
    scope(root, '[data-ar-faq]').forEach(function (el) {
      if (!once(el, 'faq')) { return; }
      var items = $$('.ar-acc__i', el), cat = 'all', q = '', empty = $('.ar-empty', el);
      items.forEach(function (it) {
        var b = $('.ar-acc__q', it);
        b.addEventListener('click', function () {
          var open = it.classList.contains('is-open');
          items.forEach(function (o) { o.classList.remove('is-open'); $('.ar-acc__q', o).setAttribute('aria-expanded', 'false'); });
          if (!open) { it.classList.add('is-open'); b.setAttribute('aria-expanded', 'true'); }
        });
      });
      function filter() {
        var n = 0;
        items.forEach(function (it) {
          var ok = (cat === 'all' || it.getAttribute('data-cat') === cat) && (!q || it.textContent.toLowerCase().indexOf(q) > -1);
          it.hidden = !ok;
          if (ok) { n++; }
        });
        if (empty) { empty.hidden = n > 0; }
      }
      var s = $('[data-faq-search]', el);
      if (s) { s.addEventListener('input', function () { q = s.value.toLowerCase().trim(); filter(); }); }
      $$('.ar-chips button', el).forEach(function (b) {
        b.addEventListener('click', function () {
          cat = b.getAttribute('data-cat');
          $$('.ar-chips button', el).forEach(function (x) { x.classList.toggle('is-active', x === b); });
          filter();
        });
      });
    });
  }

  /* ---------------------------------------------------- before/after */
  function ba(root) {
    scope(root, '[data-ar-ba]').forEach(function (el) {
      if (!once(el, 'ba')) { return; }
      var drag = false;
      function set(p) {
        p = Math.max(0, Math.min(100, p));
        el.style.setProperty('--pos', p + '%');
        el.setAttribute('aria-valuenow', Math.round(p));
      }
      function at(x) { var r = el.getBoundingClientRect(); set(((x - r.left) / r.width) * 100); }
      el.addEventListener('pointerdown', function (e) {
        drag = true;
        try { el.setPointerCapture(e.pointerId); } catch (err) { /* noop */ }
        at(e.clientX);
      });
      el.addEventListener('pointermove', function (e) { if (drag) { at(e.clientX); } });
      el.addEventListener('pointerup', function () { drag = false; });
      el.addEventListener('pointercancel', function () { drag = false; });
      el.addEventListener('keydown', function (e) {
        var v = parseFloat(el.getAttribute('aria-valuenow')) || 50;
        if (e.key === 'ArrowLeft') { set(v - 4); e.preventDefault(); }
        if (e.key === 'ArrowRight') { set(v + 4); e.preventDefault(); }
      });
    });
    scope(root, '[data-ar-batabs]').forEach(function (wrap) {
      if (!once(wrap, 'bt')) { return; }
      var tabs = $$('.ar-tabs button', wrap), panels = $$('.ar-bapanel', wrap);
      tabs.forEach(function (b, i) {
        b.addEventListener('click', function () {
          tabs.forEach(function (x) { x.classList.toggle('is-active', x === b); });
          panels.forEach(function (p, k) { p.classList.toggle('is-active', k === i); });
        });
      });
    });
  }

  /* ------------------------------------------------------ calculator */
  function calc(root) {
    scope(root, '[data-ar-calc]').forEach(function (el) {
      if (!once(el, 'calc')) { return; }
      var ins = $$('input[type=range]', el), tot = $('[data-total]', el), cur = 0, raf = 0;
      function update() {
        var v = {};
        ins.forEach(function (i) {
          v[i.name] = +i.value;
          var o = $('[data-out="' + i.name + '"]', el);
          if (o) { o.textContent = (o.getAttribute('data-fmt') || '') + (+i.value).toLocaleString(); }
        });
        var to = v.jobs * v.ticket * v.weeks, from = cur, s = performance.now();
        cancelAnimationFrame(raf);
        (function t(n) {
          var p = Math.min((n - s) / (reduce ? 1 : 600), 1), e = 1 - Math.pow(1 - p, 3);
          cur = from + (to - from) * e;
          tot.textContent = '$' + Math.round(cur).toLocaleString();
          if (p < 1) { raf = requestAnimationFrame(t); }
        })(s);
      }
      ins.forEach(function (i) { i.addEventListener('input', update); });
      update();
    });
  }

  /* ----------------------------------------------------- territories */
  function terr(root) {
    scope(root, '[data-ar-terr]').forEach(function (el) {
      if (!once(el, 'terr')) { return; }
      var groups = [$$('.ar-pin', el), $$('.ar-tpanel', el), $$('.ar-tabsq button', el)];
      function sel(i) {
        groups.forEach(function (l) { l.forEach(function (n) { n.classList.toggle('is-active', +n.getAttribute('data-i') === i); }); });
      }
      groups[0].concat(groups[2]).forEach(function (b) {
        b.addEventListener('click', function () { sel(+b.getAttribute('data-i')); });
      });
    });
  }

  /* --------------------------------------------------------- gallery */
  function lightbox(list, start) {
    var i = start;
    var lb = d.createElement('div');
    lb.className = 'ar-lb';
    lb.setAttribute('role', 'dialog');
    lb.setAttribute('aria-modal', 'true');
    lb.innerHTML = '<button class="x" aria-label="Close">&times;</button><button class="p" aria-label="Previous">&#8249;</button><button class="n" aria-label="Next">&#8250;</button><figure><img alt=""><figcaption></figcaption></figure>';
    d.body.appendChild(lb);
    var img = $('img', lb), cap = $('figcaption', lb);
    function show() {
      var it = list[i];
      img.src = it.getAttribute('data-src');
      img.alt = it.getAttribute('data-title') || '';
      cap.textContent = it.getAttribute('data-title') || '';
    }
    function close() { d.removeEventListener('keydown', key); lb.remove(); }
    function step(n) { i = (i + n + list.length) % list.length; show(); }
    function key(e) {
      if (e.key === 'Escape') { close(); }
      if (e.key === 'ArrowRight') { step(1); }
      if (e.key === 'ArrowLeft') { step(-1); }
    }
    lb.addEventListener('click', function (e) { if (e.target === lb) { close(); } });
    $('.x', lb).addEventListener('click', close);
    $('.p', lb).addEventListener('click', function () { step(-1); });
    $('.n', lb).addEventListener('click', function () { step(1); });
    d.addEventListener('keydown', key);
    show();
  }
  function gallery(root) {
    scope(root, '[data-ar-gallery]').forEach(function (el) {
      if (!once(el, 'gal')) { return; }
      var items = $$('.ar-gi', el), chips = $$('.ar-chips button', el);
      chips.forEach(function (b) {
        b.addEventListener('click', function () {
          var c = b.getAttribute('data-cat');
          chips.forEach(function (x) { x.classList.toggle('is-active', x === b); });
          items.forEach(function (it) { it.hidden = !(c === 'all' || it.getAttribute('data-cat') === c); });
        });
      });
      items.forEach(function (it) {
        it.addEventListener('click', function () {
          var vis = items.filter(function (x) { return !x.hidden; });
          lightbox(vis, vis.indexOf(it));
        });
      });
    });
  }

  /* ---------------------------------------------------- science tabs */
  function tabs(root) {
    scope(root, '[data-ar-tabs]').forEach(function (el) {
      if (!once(el, 'tabs')) { return; }
      var t = $$('.ar-sci__tab', el);
      t.forEach(function (b) {
        b.addEventListener('click', function () { t.forEach(function (x) { x.classList.toggle('is-active', x === b); }); });
      });
    });
  }

  /* ----------------------------------------------------------- forms */
  function forms(root) {
    scope(root, 'form[data-ar-form]').forEach(function (f) {
      if (!once(f, 'frm')) { return; }
      var ts = $('[name=ts]', f), msg = $('.ar-form__msg', f), btn = $('[type=submit]', f);
      var t0 = Date.now(); // elapsed time is measured in the browser, so clock differences never matter
      function say(t, cls) { if (msg) { msg.textContent = t || ''; msg.className = 'ar-form__msg ' + (cls || ''); } }
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!f.checkValidity()) { if (f.reportValidity) { f.reportValidity(); } return; }
        if (!w.ARC || !w.ARC.ajax) { say(I18N.error, 'is-err'); return; }
        if (ts) { ts.value = Math.max(1, Date.now() - t0); }
        if (btn) { btn.disabled = true; }
        say(I18N.sending, '');
        fetch(w.ARC.ajax, { method: 'POST', body: new FormData(f), credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (j) {
            if (j && j.success) {
              var box = f.parentNode, ok = $(':scope > .ar-success', box);
              if (ok) {
                f.hidden = true; ok.hidden = false;
                var res = $('.ar-est__res', box); if (res) { res.hidden = true; }
                var est = f.closest('.ar-est'); if (est) { est.classList.add('is-done'); }
              } else {
                say((j.data && j.data.message) || I18N.ok, 'is-ok');
                f.reset();
                t0 = Date.now();
              }
            } else {
              say((j && j.data && j.data.message) || I18N.error, 'is-err');
            }
          })
          .catch(function () { say(I18N.error, 'is-err'); })
          .then(function () { if (btn) { btn.disabled = false; } });
      });
      var reset = f.parentNode.querySelector('[data-reset],[data-restart]');
      if (reset) {
        reset.addEventListener('click', function () {
          var box = f.parentNode;
          f.reset(); f.hidden = false; $(':scope > .ar-success', box).hidden = true;
          var res = $('.ar-est__res', box); if (res) { res.hidden = false; }
          t0 = Date.now();
          say('');
          var est = f.closest('.ar-est');
          if (est) { est.classList.remove('is-done'); est.dispatchEvent(new CustomEvent('ar-restart')); }
        });
      }
    });
  }

  /* -------------------------------------------------------- estimator */
  function est(root) {
    scope(root, '[data-ar-est]').forEach(function (el) {
      if (!once(el, 'est')) { return; }
      var cfg = {};
      try { cfg = JSON.parse(el.getAttribute('data-cfg') || '{}'); } catch (err) { cfg = { rate: 275, hours: [3, 6, 12], mult: [1, 1.35, 1.8] }; }
      var panes = $$('.ar-est__pane', el), steps = $$('.ar-est__steps li', el);
      var back = $('[data-back]', el), next = $('[data-next]', el), step = 0;
      var st = { service: '', size: 1, cond: 1 };
      var first = $('[data-group=service] .ar-opt.is-sel', el);
      st.service = first ? first.getAttribute('data-v') : '';
      $$('.ar-est__opts', el).forEach(function (g) {
        $$('.ar-opt', g).forEach(function (b) {
          b.addEventListener('click', function () {
            $$('.ar-opt', g).forEach(function (x) { x.classList.toggle('is-sel', x === b); });
            var k = g.getAttribute('data-group');
            if (k === 'service') { st.service = b.getAttribute('data-v'); }
            if (k === 'size') { st.size = +b.getAttribute('data-v'); }
            if (k === 'cond') { st.cond = +b.getAttribute('data-v'); }
          });
        });
      });
      function money(n) { return '$' + n.toLocaleString(); }
      function show(n) {
        step = n;
        panes.forEach(function (p, i) { p.classList.toggle('is-active', i === n); });
        steps.forEach(function (s, i) { s.classList.toggle('is-active', i === n); s.classList.toggle('is-done', i < n); });
        back.disabled = n === 0;
        el.classList.toggle('is-final', n === 2);
        if (n === 2) {
          var h = cfg.hours[st.size] * cfg.mult[st.cond];
          var mid = Math.round((h * cfg.rate) / 50) * 50;
          var lo = Math.round((mid * 0.85) / 50) * 50, hi = Math.round((mid * 1.2) / 50) * 50;
          var sz = $('[data-group=size] .ar-opt.is-sel', el), cd = $('[data-group=cond] .ar-opt.is-sel', el);
          var range = money(lo) + ' – ' + money(hi);
          var meta = 'Approx. ' + Math.round(h) + ' hours on-site · ' + sz.getAttribute('data-l') + ' · ' + cd.getAttribute('data-l');
          $('[data-r-svc]', el).textContent = st.service;
          $('[data-r-range]', el).textContent = range;
          $('[data-r-meta]', el).textContent = meta;
          $('[name=service]', el).value = st.service;
          $('[name=size]', el).value = sz.getAttribute('data-l');
          $('[name=condition]', el).value = cd.getAttribute('data-l');
          $('[name=estimate]', el).value = range + ' (' + meta + ')';
        }
      }
      next.addEventListener('click', function () { show(Math.min(step + 1, 2)); });
      back.addEventListener('click', function () { show(Math.max(step - 1, 0)); });
      el.addEventListener('ar-restart', function () { show(0); });
    });
  }

  /* ---------------------------------------------------------- header */
  function header() {
    var h = $('#ar-header');
    var bar = $('.ar-progress i'), top = $('.ar-top');
    function onScroll() {
      if (h) { h.classList.toggle('is-scrolled', w.scrollY > 24); }
      if (top) { top.classList.toggle('is-show', w.scrollY > 700); }
      if (bar) {
        var m = d.documentElement.scrollHeight - w.innerHeight;
        bar.style.transform = 'scaleX(' + (m > 0 ? w.scrollY / m : 0) + ')';
      }
    }
    onScroll();
    w.addEventListener('scroll', onScroll, { passive: true });
    if (top) { top.addEventListener('click', function () { w.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); }); }
    if (!h) { return; }

    var burger = $('.ar-burger', h), nav = $('#ar-nav');
    function setOpen(v) {
      nav.classList.toggle('is-open', v);
      burger.setAttribute('aria-expanded', v ? 'true' : 'false');
      d.body.style.overflow = v ? 'hidden' : '';
      if (v) { d.documentElement.style.setProperty('--ar-hh', h.getBoundingClientRect().bottom + 'px'); }
    }
    if (burger && nav) {
      burger.addEventListener('click', function () { setOpen(!nav.classList.contains('is-open')); });
      d.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setOpen(false); } });
      w.addEventListener('resize', function () { if (w.innerWidth > 1100) { setOpen(false); } });
      $$('.menu-item-has-children', nav).forEach(function (li) {
        var a = $(':scope > a', li);
        var t = d.createElement('button');
        t.type = 'button'; t.className = 'ar-sub-toggle';
        t.setAttribute('aria-label', 'Toggle submenu');
        li.insertBefore(t, a.nextSibling);
        t.addEventListener('click', function () { li.classList.toggle('is-open'); });
      });
    }
  }

  /* ------------------------------------------------------------ boot */
  /* -------------------------------------------------- on-page navigation */
  function pagenav(root) {
    scope(root, '[data-ar-pnav]').forEach(function (el) {
      if (!once(el, 'pn')) { return; }
      var bar = $('.ar-pnav__bar', el), box = $('.ar-pnav__links', el), links = $$('a', box);
      var hdr = $('#ar-header'), last = -2;
      var targets = links.map(function (a) {
        var id = (a.getAttribute('href') || '').replace('#', '');
        return id ? d.getElementById(id) : null;
      });
      function measure() { el.style.minHeight = bar.offsetHeight + 'px'; }
      function update() {
        var top = hdr ? Math.round(hdr.getBoundingClientRect().bottom) : 0;
        d.documentElement.style.setProperty('--ar-stick', top + 'px');
        el.classList.toggle('is-stuck', !editor() && el.getBoundingClientRect().top <= top);
        var cur = -1, line = top + bar.offsetHeight + 40;
        targets.forEach(function (t, i) { if (t && t.getBoundingClientRect().top <= line) { cur = i; } });
        if (cur === last) { return; }
        last = cur;
        links.forEach(function (a, i) { a.classList.toggle('is-active', i === cur); });
        if (cur > -1 && box.scrollWidth > box.clientWidth) {
          box.scrollTo({ left: links[cur].offsetLeft - box.clientWidth / 2 + links[cur].offsetWidth / 2, behavior: reduce ? 'auto' : 'smooth' });
        }
      }
      w.addEventListener('scroll', update, { passive: true });
      w.addEventListener('resize', function () { measure(); update(); });
      w.addEventListener('load', function () { measure(); update(); });
      measure(); update();
    });
  }

  var modules = [reveal, counters, particles, rotator, tilt, carousel, faq, ba, calc, terr, gallery, tabs, forms, est, pagenav];
  function init(root) {
    modules.forEach(function (fn) {
      try { fn(root || d); } catch (err) { if (w.console) { console.error('[arctic-resto]', err); } }
    });
  }
  function boot() {
    d.documentElement.classList.add('ar-ready');
    try { header(); } catch (err) { if (w.console) { console.error('[arctic-resto]', err); } }
    init(d);
  }
  if (d.readyState === 'loading') { d.addEventListener('DOMContentLoaded', boot); } else { boot(); }

  // Elementor editor: re-init whenever a widget is (re)rendered.
  function hook() {
    if (w.elementorFrontend && w.elementorFrontend.hooks) {
      w.elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($el) { init($el[0]); });
    }
  }
  if (w.jQuery) { w.jQuery(w).on('elementor/frontend/init', hook); }
  hook();
}());
