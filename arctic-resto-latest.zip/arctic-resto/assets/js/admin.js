(function () {
  'use strict';
  var run = document.getElementById('ar-run');
  var rm = document.getElementById('ar-remove');
  var log = document.getElementById('ar-log');
  var bar = document.getElementById('ar-bar');
  var after = document.getElementById('ar-after');
  if (!run || !window.ARDEMO) { return; }

  function add(text, cls) {
    var li = document.createElement('li');
    li.textContent = text;
    if (cls) { li.className = cls; }
    log.appendChild(li);
    li.scrollIntoView({ block: 'nearest' });
    return li;
  }
  function call(step, offset) {
    var fd = new FormData();
    fd.append('action', 'ar_demo_step');
    fd.append('nonce', ARDEMO.nonce);
    fd.append('step', step);
    fd.append('offset', offset);
    return fetch(ARDEMO.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }
  function lock(v) { run.disabled = v; if (rm) { rm.disabled = v; } }

  function start() {
    lock(true);
    log.innerHTML = '';
    after.hidden = true;
    bar.style.width = '2%';
    var steps = ARDEMO.steps, i = 0;
    (function next() {
      if (i >= steps.length) {
        bar.style.width = '100%';
        add('All done! Your site is ready.', 'ok');
        after.hidden = false;
        run.textContent = 'Re-import demo content';
        lock(false);
        return;
      }
      var st = steps[i], line = add(st[1] + '…', 'busy');
      (function chunk(offset) {
        call(st[0], offset).then(function (j) {
          if (!j || !j.success) { throw new Error((j && j.data && j.data.message) || 'Request failed'); }
          line.textContent = j.data.msg;
          if (j.data.more) { chunk(j.data.offset); return; }
          line.className = 'ok';
          i++;
          bar.style.width = Math.round((i / steps.length) * 100) + '%';
          next();
        }).catch(function (e) {
          line.textContent = st[1] + ' failed: ' + e.message;
          line.className = 'err';
          lock(false);
        });
      })(0);
    })();
  }

  run.addEventListener('click', function () {
    if (window.confirm('Import the demo content now? Existing demo items will be updated.')) { start(); }
  });
  if (rm) {
    rm.addEventListener('click', function () {
      if (!window.confirm('Remove all demo pages, services, posts, images and menus created by the importer?')) { return; }
      lock(true);
      log.innerHTML = '';
      var line = add('Removing demo content…', 'busy');
      call('remove', 0).then(function (j) {
        line.textContent = j && j.success ? j.data.msg : 'Failed';
        line.className = j && j.success ? 'ok' : 'err';
        setTimeout(function () { window.location.reload(); }, 1200);
      }).catch(function () { line.textContent = 'Failed'; line.className = 'err'; lock(false); });
    });
  }
}());
