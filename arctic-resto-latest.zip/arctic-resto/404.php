<?php
/**
 * 404 template.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>
<section class="ar-sec ar-t-void ar-404">
	<div class="ar-hero__grid"></div>
	<i class="ar-fog ar-fog--1" aria-hidden="true"></i>
	<div class="ar-particles" data-ar-particles></div>
	<div class="ar-wrap ar-404__in">
		<p class="ar-404__n ar-grad ar-float">404</p>
		<h1><?php esc_html_e( 'This page melted away.', 'arctic-resto' ); ?></h1>
		<p><?php esc_html_e( "Like dry ice, it sublimated — the page you're looking for doesn't exist.", 'arctic-resto' ); ?></p>
		<div class="ar-actions ar-actions--c">
			<a class="ar-btn ar-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span><?php esc_html_e( 'Back to home', 'arctic-resto' ); ?></span><?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></a>
			<a class="ar-btn ar-btn--ghost" href="<?php echo esc_url( ar_phone_href() ); ?>"><?php echo ar_svg( 'phone' ); // phpcs:ignore ?><span><?php echo esc_html( ar_phone() ); ?></span></a>
		</div>
	</div>
</section>
<?php
get_footer();
