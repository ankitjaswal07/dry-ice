<?php
/**
 * Fallback template: blog index, archives and search results.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();

if ( is_search() ) {
	/* translators: %s search query */
	$title = sprintf( __( 'Search: %s', 'arctic-resto' ), get_search_query() );
} elseif ( is_archive() ) {
	$title = get_the_archive_title();
} else {
	$title = __( 'Latest articles', 'arctic-resto' );
}
?>
<section class="ar-sec ar-phero ar-t-void">
	<div class="ar-hero__shade"></div><div class="ar-hero__grid"></div>
	<i class="ar-fog ar-fog--1" aria-hidden="true"></i>
	<div class="ar-wrap ar-phero__inner">
		<?php echo ar_breadcrumbs(); // phpcs:ignore ?>
		<h1 class="ar-phero__title"><?php echo esc_html( wp_strip_all_tags( $title ) ); ?></h1>
	</div>
</section>

<section class="ar-sec ar-t-light ar-pad-lg">
	<div class="ar-wrap">
		<?php if ( have_posts() ) : ?>
			<div class="ar-grid ar-cols-3">
				<?php
				$i = 0;
				while ( have_posts() ) {
					the_post();
					echo ar_post_card( get_post(), $i++ ); // phpcs:ignore
				}
				?>
			</div>
			<nav class="ar-pager"><?php echo wp_kses_post( paginate_links( array( 'prev_text' => '‹', 'next_text' => '›' ) ) ); ?></nav>
		<?php else : ?>
			<p class="ar-empty"><?php esc_html_e( 'Nothing found. Try a different search.', 'arctic-resto' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
