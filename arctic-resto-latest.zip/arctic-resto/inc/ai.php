<?php
/**
 * AI-agent optimisation ("GEO / AEO"):
 *  - robots.txt rules for AI search & assistant crawlers (allow or block, from the Customizer)
 *  - /llms.txt  – concise, curated site map for language models
 *  - /llms-full.txt – full text of services and key pages in Markdown
 *  - /any-page.md – clean Markdown mirror of every page (text pulled from the Elementor content)
 * Everything is generated live from your content, so it never goes stale.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
/* robots.txt                                                          */
/* ------------------------------------------------------------------ */
function ar_ai_bots() {
	return array(
		'GPTBot',
		'OAI-SearchBot',
		'ChatGPT-User',
		'ClaudeBot',
		'Claude-User',
		'Claude-SearchBot',
		'PerplexityBot',
		'Perplexity-User',
		'Google-Extended',
		'Applebot-Extended',
		'CCBot',
		'Amazonbot',
		'meta-externalagent',
	);
}

add_filter(
	'robots_txt',
	function ( $output, $public ) {
		if ( ! $public ) {
			return $output;
		}
		$block = 'block' === ar_mod( 'ar_ai_access', 'allow' );
		$out   = rtrim( $output ) . "\n\n# AI crawlers: " . ( $block ? 'blocked' : 'allowed' ) . " (Appearance > Customize > Arctic Resto Settings)\n";
		foreach ( ar_ai_bots() as $b ) {
			$out .= 'User-agent: ' . $b . "\n";
			$out .= $block ? "Disallow: /\n\n" : "Allow: /\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n\n";
		}
		if ( ! $block ) {
			$out .= '# LLM-friendly site summary: ' . home_url( '/llms.txt' ) . "\n";
		}
		return $out;
	},
	20,
	2
);

/* ------------------------------------------------------------------ */
/* Endpoints                                                           */
/* ------------------------------------------------------------------ */
add_action(
	'parse_request',
	function ( $wp ) {
		if ( is_admin() ) {
			return;
		}
		$path = isset( $wp->request ) ? trim( (string) $wp->request, '/' ) : '';
		if ( 'llms.txt' === $path ) {
			ar_send_text( ar_llms_text( false ), 'text/plain' );
		} elseif ( 'llms-full.txt' === $path ) {
			ar_send_text( ar_llms_text( true ), 'text/plain' );
		} elseif ( preg_match( '/\.md$/i', $path ) ) {
			ar_serve_markdown( $path );
		}
	}
);

function ar_send_text( $body, $type, $headers = array() ) {
	status_header( 200 );
	header( 'Content-Type: ' . $type . '; charset=utf-8' );
	header( 'Cache-Control: public, max-age=3600' );
	header( 'X-Content-Type-Options: nosniff' );
	foreach ( $headers as $h ) {
		header( $h, false );
	}
	echo $body; // phpcs:ignore
	exit;
}

/** URL of the Markdown mirror for a post (empty when pretty permalinks are off). */
function ar_md_url( $post ) {
	if ( ! $post || ! get_option( 'permalink_structure' ) ) {
		return '';
	}
	if ( 'page' === $post->post_type && (int) get_option( 'page_on_front' ) === (int) $post->ID ) {
		return home_url( '/index.md' );
	}
	return untrailingslashit( get_permalink( $post ) ) . '.md';
}

function ar_serve_markdown( $path ) {
	$slug = preg_replace( '/\.md$/i', '', $path );
	$id   = ( 'index' === $slug ) ? (int) get_option( 'page_on_front' ) : (int) url_to_postid( home_url( '/' . $slug . '/' ) );
	$post = $id ? get_post( $id ) : null;
	if ( ! $post || 'publish' !== $post->post_status || '1' === get_post_meta( $post->ID, '_ar_noindex', true ) ) {
		return; // Fall through to the normal 404.
	}
	ar_send_text(
		ar_post_markdown( $post ),
		'text/markdown',
		array(
			'Link: <' . get_permalink( $post ) . '>; rel="canonical"',
			'X-Robots-Tag: noindex, follow',
		)
	);
}

/* ------------------------------------------------------------------ */
/* Markdown generation                                                 */
/* ------------------------------------------------------------------ */
function ar_md_clean( $html ) {
	$t = (string) $html;
	$t = preg_replace( '/\{\{(.+?)\}\}/s', '$1', $t );
	$t = preg_replace( '/<h[1-4][^>]*>(.*?)<\/h[1-4]>/is', "\n\n### $1\n\n", $t );
	$t = preg_replace( '/<li[^>]*>(.*?)<\/li>/is', "\n- $1", $t );
	$t = preg_replace( '/<\/p>|<br\s*\/?>/i', "\n\n", $t );
	$t = wp_strip_all_tags( $t );
	$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
	$t = preg_replace( "/\n{3,}/", "\n\n", $t );
	return trim( $t );
}

function ar_widget_md( $type, $s ) {
	if ( 'text-editor' === $type ) {
		return ar_md_clean( isset( $s['editor'] ) ? $s['editor'] : '' ) . "\n\n";
	}
	if ( 0 !== strpos( (string) $type, 'ar_' ) ) {
		return '';
	}
	$skip = array( 'ar_terr_hero', 'ar_page_nav', 'ar_terr_cards', 'ar_coverage', 'ar_form', 'ar_estimator', 'ar_marquee', 'ar_calculator', 'ar_gallery', 'ar_testimonials', 'ar_before_after', 'ar_posts', 'ar_services', 'ar_stats', 'ar_team', 'ar_cta' );
	if ( in_array( $type, $skip, true ) ) {
		return '';
	}
	$hero = in_array( $type, array( 'ar_hero', 'ar_page_hero' ), true );
	$o    = '';
	if ( ! $hero && ! empty( $s['title'] ) && is_string( $s['title'] ) ) {
		$o .= '## ' . ar_md_clean( $s['title'] ) . "\n\n";
	}
	foreach ( array( 'subtitle', 'question', 'answer', 'body', 'quote', 'text', 'note' ) as $k ) {
		if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
			$o .= ar_md_clean( $s[ $k ] ) . "\n\n";
		}
	}
	foreach ( array( 'checks', 'aside_list', 'good', 'bad' ) as $k ) {
		if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
			foreach ( ar_lines( $s[ $k ] ) as $l ) {
				$o .= '- ' . $l . "\n";
			}
			$o .= "\n";
		}
	}
	foreach ( array( 'items', 'facts' ) as $rk ) {
		if ( empty( $s[ $rk ] ) || ! is_array( $s[ $rk ] ) ) {
			continue;
		}
		foreach ( $s[ $rk ] as $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			if ( isset( $it['q'], $it['a'] ) ) {
				$o .= '### ' . ar_md_clean( $it['q'] ) . "\n\n" . ar_md_clean( $it['a'] ) . "\n\n";
			} elseif ( isset( $it['label'], $it['value'] ) && is_string( $it['value'] ) ) {
				$o .= '- **' . ar_md_clean( $it['label'] ) . ':** ' . ar_md_clean( $it['value'] ) . "\n";
			} elseif ( isset( $it['title'], $it['a'], $it['b'] ) ) {
				$o .= '- ' . ar_md_clean( $it['title'] ) . ' — dry ice: ' . ar_md_clean( $it['a'] ) . '; traditional: ' . ar_md_clean( $it['b'] ) . "\n";
			} elseif ( isset( $it['name'], $it['blurb'] ) ) {
				$o .= '### ' . ar_md_clean( $it['name'] ) . ( ! empty( $it['status'] ) ? ' (' . ar_md_clean( $it['status'] ) . ')' : '' ) . "\n\n" . ar_md_clean( $it['blurb'] ) . "\n\n";
				if ( ! empty( $it['areas'] ) ) {
					$o .= 'Coverage: ' . implode( ', ', ar_lines( $it['areas'] ) ) . "\n\n";
				}
			} elseif ( isset( $it['title'] ) ) {
				$h  = ( ! empty( $it['year'] ) ? ar_md_clean( $it['year'] ) . ' — ' : '' ) . ar_md_clean( $it['title'] );
				$o .= '### ' . $h . "\n\n" . ( ! empty( $it['text'] ) ? ar_md_clean( $it['text'] ) . "\n\n" : '' );
			}
		}
		$o .= "\n";
	}
	return $o;
}

function ar_elements_md( $els ) {
	$o = '';
	foreach ( (array) $els as $el ) {
		if ( ! is_array( $el ) ) {
			continue;
		}
		if ( isset( $el['elType'] ) && 'widget' === $el['elType'] ) {
			$o .= ar_widget_md( isset( $el['widgetType'] ) ? $el['widgetType'] : '', isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array() );
		}
		if ( ! empty( $el['elements'] ) ) {
			$o .= ar_elements_md( $el['elements'] );
		}
	}
	return $o;
}

function ar_post_markdown( $post ) {
	$md = '# ' . get_the_title( $post ) . "\n\n";
	if ( has_excerpt( $post ) ) {
		$md .= '> ' . wp_strip_all_tags( $post->post_excerpt ) . "\n\n";
	}
	$md .= 'Source: ' . get_permalink( $post ) . "\n";
	$md .= 'Last updated: ' . get_the_modified_date( 'Y-m-d', $post ) . "\n\n";
	if ( ar_is_elementor( $post->ID ) ) {
		$data = json_decode( (string) get_post_meta( $post->ID, '_elementor_data', true ), true );
		if ( is_array( $data ) ) {
			$md .= ar_elements_md( $data );
		}
	} else {
		$md .= ar_md_clean( strip_shortcodes( $post->post_content ) ) . "\n";
	}
	if ( 'ar_service' === $post->post_type ) {
		$m = ar_service_meta( $post->ID );
		if ( $m['surfaces'] && false === strpos( $md, 'Surfaces' ) ) {
			$md .= "\n## Surfaces\n\n" . implode( ', ', $m['surfaces'] ) . "\n";
		}
		$md .= "\n## Contact\n\n" . ar_phone() . ' · ' . ar_email() . ' · ' . ar_location() . "\n";
	}
	if ( 'page' === $post->post_type && function_exists( 'ar_is_territory' ) && ar_is_territory( $post->ID ) ) {
		$tm  = ar_terr_meta( $post->ID );
		$md .= "\n## Coverage\n\nStatus: " . $tm['status'] . "\n\n" . ( $tm['areas'] ? '- ' . implode( "\n- ", $tm['areas'] ) . "\n" : '' );
	}
	return trim( preg_replace( "/\n{3,}/", "\n\n", $md ) ) . "\n";
}

/* ------------------------------------------------------------------ */
/* llms.txt                                                            */
/* ------------------------------------------------------------------ */
function ar_llms_text( $full ) {
	$name = get_bloginfo( 'name' );
	$o    = '# ' . $name . "\n\n";
	$o   .= '> ' . ar_ai_summary() . "\n\n";
	$o   .= 'Service area: ' . implode( ', ', ar_areas() ) . '. Phone: ' . ar_phone() . '. Email: ' . ar_email() . ".\n\n";

	$svcs = ar_get_services();
	if ( $svcs ) {
		$o .= "## Services\n\n";
		foreach ( $svcs as $p ) {
			$m  = ar_service_meta( $p->ID );
			$o .= '- [' . get_the_title( $p ) . '](' . ( ar_md_url( $p ) ? ar_md_url( $p ) : get_permalink( $p ) ) . '): ' . ( $m['tagline'] ? $m['tagline'] . '. ' : '' ) . wp_strip_all_tags( $p->post_excerpt ) . "\n";
		}
		$o .= "\n";
	}

	$keys  = array( 'how-it-works', 'about', 'franchise', 'territories', 'faq', 'gallery', 'estimator', 'contact', 'blog' );
	$pages = array();
	foreach ( $keys as $slug ) {
		$pg = get_page_by_path( $slug );
		if ( $pg && 'publish' === $pg->post_status ) {
			$pages[ $slug ] = $pg;
		}
	}
	if ( $pages ) {
		$o .= "## Key pages\n\n";
		foreach ( $pages as $pg ) {
			$o .= '- [' . get_the_title( $pg ) . '](' . ( ar_md_url( $pg ) ? ar_md_url( $pg ) : get_permalink( $pg ) ) . ')' . ( has_excerpt( $pg ) ? ': ' . wp_strip_all_tags( $pg->post_excerpt ) : '' ) . "\n";
		}
		$o .= "\n";
	}

	$terr = function_exists( 'ar_get_territories' ) ? ar_get_territories() : array();
	if ( $terr ) {
		$o .= "## Territories\n\n";
		foreach ( $terr as $tp ) {
			$tm = ar_terr_meta( $tp->ID );
			$o .= '- [' . $tm['name'] . '](' . ( ar_md_url( $tp ) ? ar_md_url( $tp ) : $tm['link'] ) . '): ' . $tm['status'] . ( $tm['blurb'] ? '. ' . $tm['blurb'] : '' ) . "\n";
		}
		$o .= "\n";
	}

	$o .= "## Franchise\n\n";
	$o .= "Arctic Resto is the industry's first mobile dry ice cleaning franchise. Franchisees own their van and equipment. Applications and franchise-owner sign-in are handled in the franchise portal. Register: " . ar_portal_register_url() . " Log in: " . ar_portal_login_url() . "\n\n";

	$o .= "## Machine-readable\n\n";
	$o .= '- [Sitemap](' . home_url( '/wp-sitemap.xml' ) . ")\n";
	$o .= '- [Full text of services and key pages](' . home_url( '/llms-full.txt' ) . ")\n";
	$o .= '- [Services JSON (WordPress REST API)](' . rest_url( 'wp/v2/ar_service' ) . ")\n";
	$o .= "- Every page has a Markdown version: add .md to its URL (for example /services/fire-restoration.md)\n";

	if ( $full ) {
		$o .= "\n---\n\n# Full content\n\n";
		foreach ( $svcs as $p ) {
			$o .= ar_post_markdown( $p ) . "\n---\n\n";
		}
		foreach ( array( 'how-it-works', 'about', 'franchise', 'territories', 'faq' ) as $slug ) {
			if ( isset( $pages[ $slug ] ) ) {
				$o .= ar_post_markdown( $pages[ $slug ] ) . "\n---\n\n";
			}
		}
	}
	return trim( $o ) . "\n";
}
