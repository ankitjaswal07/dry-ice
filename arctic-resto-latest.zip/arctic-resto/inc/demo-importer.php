<?php
/**
 * One-click demo importer (Appearance → Demo Import).
 * Runs in small AJAX steps so it never times out, is safe to re-run (idempotent)
 * and every page it creates is real, editable Elementor content.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once AR_DIR . '/inc/demo/content.php';
require_once AR_DIR . '/inc/demo/service-extra.php';
require_once AR_DIR . '/inc/demo/service-more.php';
require_once AR_DIR . '/inc/demo/territory-content.php';
require_once AR_DIR . '/inc/demo/franchise-content.php';

/* ------------------------------------------------------------------ */
/* Admin page                                                          */
/* ------------------------------------------------------------------ */
add_action(
	'admin_menu',
	function () {
		add_theme_page( __( 'Arctic Resto Demo Import', 'arctic-resto' ), __( 'Demo Import', 'arctic-resto' ), 'manage_options', 'ar-demo', 'ar_demo_page' );
	}
);

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'appearance_page_ar-demo' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'ar-admin', AR_URI . '/assets/css/admin.css', array(), AR_VERSION );
		wp_enqueue_script( 'ar-admin', AR_URI . '/assets/js/admin.js', array(), AR_VERSION, true );
		wp_localize_script(
			'ar-admin',
			'ARDEMO',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'ar_demo' ),
				'steps' => array(
					array( 'media', __( 'Importing images', 'arctic-resto' ) ),
					array( 'services', __( 'Creating services', 'arctic-resto' ) ),
					array( 'testimonials', __( 'Adding testimonials', 'arctic-resto' ) ),
					array( 'posts', __( 'Writing blog posts', 'arctic-resto' ) ),
					array( 'pages', __( 'Building Elementor pages', 'arctic-resto' ) ),
					array( 'menus', __( 'Creating menus', 'arctic-resto' ) ),
					array( 'settings', __( 'Applying site settings', 'arctic-resto' ) ),
				),
			)
		);
	}
);

add_action(
	'admin_notices',
	function () {
		if ( get_option( 'ar_demo_done' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( $screen && 'appearance_page_ar-demo' === $screen->id ) {
			return;
		}
		echo '<div class="notice notice-info is-dismissible"><p><strong>' . esc_html__( 'Arctic Resto is active.', 'arctic-resto' ) . '</strong> ' . esc_html__( 'Import the demo content to get all pages, services and menus, fully editable with Elementor.', 'arctic-resto' ) . ' <a class="button button-primary" href="' . esc_url( admin_url( 'themes.php?page=ar-demo' ) ) . '">' . esc_html__( 'Import demo', 'arctic-resto' ) . '</a></p></div>';
	}
);

add_action(
	'admin_notices',
	function () {
		if ( ar_has_portal() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'themes', 'appearance_page_ar-demo' ), true ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Franchise portal not connected.', 'arctic-resto' ) . '</strong> ' . esc_html__( 'Add your franchise portal URL so the Apply and Login buttons point to it. Until then they open the Contact page.', 'arctic-resto' ) . ' <a class="button" href="' . esc_url( admin_url( 'customize.php?autofocus[section]=ar_site' ) ) . '">' . esc_html__( 'Set portal URL', 'arctic-resto' ) . '</a></p></div>';
	}
);

function ar_demo_page() {
	$has_el = did_action( 'elementor/loaded' );
	?>
	<div class="wrap ar-demo">
		<h1><?php esc_html_e( 'Arctic Resto — Demo Import', 'arctic-resto' ); ?></h1>
		<p class="ar-demo__lead"><?php esc_html_e( 'One click creates every page, 7 services, testimonials, blog posts, menus and settings. All pages are built from Arctic Resto widgets, so you can edit everything with Elementor.', 'arctic-resto' ); ?></p>

		<?php if ( ! $has_el ) : ?>
			<div class="notice notice-error inline"><p><?php esc_html_e( 'Elementor is required. Please install and activate the free Elementor plugin first.', 'arctic-resto' ); ?> <a href="<?php echo esc_url( admin_url( 'plugin-install.php?s=elementor&tab=search&type=term' ) ); ?>"><?php esc_html_e( 'Install Elementor', 'arctic-resto' ); ?></a></p></div>
		<?php endif; ?>

		<div class="ar-demo__grid">
			<div class="ar-demo__card">
				<h2><?php esc_html_e( 'What will be imported', 'arctic-resto' ); ?></h2>
				<ul>
					<li><strong>16 pages</strong> (including 4 child territory pages) — Home, About, Services, How It Works, Franchise, Territories, Gallery, Blog, FAQ, Instant Estimator, Contact, Privacy Policy</li>
					<li><strong>7 services</strong> — Aerospace & Defense, Food Processing & Equipment, Manufacturing & Machinery, Utilities & Power Plants, Automotive Restoration, Boats & Marinas, Fire Restoration (each a full Elementor page)</li>
					<li><strong>5 testimonials</strong> and <strong>6 blog posts</strong></li>
					<li><strong>3 menus</strong> (primary with mega menu, footer company, footer services)</li>
					<li><strong>24 demo images</strong> added to your Media Library (7 ship with the theme, 17 stock photos are downloaded during import — your server needs internet access)</li>
					<li>Homepage, permalinks (post name) and Elementor settings</li>
				</ul>
				<p class="description"><?php esc_html_e( 'Safe to run again — existing demo items are updated, not duplicated. Your own pages are never deleted.', 'arctic-resto' ); ?></p>
				<p>
					<button class="button button-primary button-hero" id="ar-run" <?php disabled( ! $has_el ); ?>><?php echo get_option( 'ar_demo_done' ) ? esc_html__( 'Re-import demo content', 'arctic-resto' ) : esc_html__( 'Import demo content', 'arctic-resto' ); ?></button>
					<?php if ( get_option( 'ar_demo_done' ) ) : ?>
						<button class="button button-link-delete" id="ar-remove"><?php esc_html_e( 'Remove demo content', 'arctic-resto' ); ?></button>
					<?php endif; ?>
				</p>
			</div>
			<div class="ar-demo__card">
				<h2><?php esc_html_e( 'Progress', 'arctic-resto' ); ?></h2>
				<div class="ar-demo__bar"><i id="ar-bar"></i></div>
				<ol id="ar-log" class="ar-demo__log"><li class="muted"><?php esc_html_e( 'Waiting to start…', 'arctic-resto' ); ?></li></ol>
				<p id="ar-after" hidden>
					<a class="button button-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View site', 'arctic-resto' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>"><?php esc_html_e( 'Edit pages with Elementor', 'arctic-resto' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=ar_site' ) ); ?>"><?php esc_html_e( 'Customize (phone, email, colours)', 'arctic-resto' ); ?></a>
				</p>
			</div>
		</div>
	</div>
	<?php
}

/* ------------------------------------------------------------------ */
/* AJAX dispatcher                                                     */
/* ------------------------------------------------------------------ */
add_action(
	'wp_ajax_ar_demo_step',
	function () {
		check_ajax_referer( 'ar_demo', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'arctic-resto' ) ), 403 );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore
		}
		$step   = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$fn     = 'ar_demo_step_' . $step;
		if ( ! function_exists( $fn ) ) {
			wp_send_json_error( array( 'message' => 'Unknown step.' ), 400 );
		}
		try {
			wp_send_json_success( call_user_func( $fn, $offset ) );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}
	}
);

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
function ar_demo_find( $key, $type ) {
	$ids = get_posts(
		array(
			'post_type'      => $type,
			'post_status'    => 'any',
			'meta_key'       => '_ar_demo_key', // phpcs:ignore
			'meta_value'     => $key, // phpcs:ignore
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);
	return $ids ? (int) $ids[0] : 0;
}

function ar_demo_upsert( $key, $args ) {
	$id = ar_demo_find( $key, $args['post_type'] );
	if ( ! $id && 'page' === $args['post_type'] && ! empty( $args['post_name'] ) ) {
		$adopt = get_page_by_path( $args['post_name'] ); // Adopt e.g. the default Privacy Policy draft.
		if ( $adopt && ! get_post_meta( $adopt->ID, '_ar_demo_key', true ) ) {
			$id = (int) $adopt->ID;
		}
	}
	if ( $id ) {
		$args['ID'] = $id;
		$id         = wp_update_post( wp_slash( $args ), true );
	} else {
		$id = wp_insert_post( wp_slash( $args ), true );
	}
	if ( is_wp_error( $id ) ) {
		throw new \Exception( $id->get_error_message() );
	}
	update_post_meta( $id, '_ar_demo_key', $key );
	return (int) $id;
}

function ar_demo_elementor_meta( $post_id, $elements, $type = 'wp-page' ) {
	update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $elements ) ) );
	update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
	update_post_meta( $post_id, '_elementor_template_type', $type );
	update_post_meta( $post_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.25.0' );
	update_post_meta( $post_id, '_wp_page_template', 'default' );
	delete_post_meta( $post_id, '_elementor_css' );
}

function ar_demo_page_id( $slug ) {
	return ar_demo_find( 'page:' . $slug, 'page' );
}

/* ------------------------------------------------------------------ */
/* Steps                                                               */
/* ------------------------------------------------------------------ */
function ar_demo_step_media( $offset ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$manifest = ar_demo_media_manifest();
	$keys     = array_keys( $manifest );
	$total    = count( $keys );
	$map      = get_option( 'ar_demo_media', array() );
	$failed   = get_option( 'ar_demo_media_failed', array() );
	if ( 0 === $offset ) {
		$failed = array();
	}
	$step  = 3; // small chunks: remote downloads can be slow on cheap hosting.
	$chunk = array_slice( $keys, $offset, $step );
	foreach ( $chunk as $key ) {
		if ( isset( $map[ $key ] ) && get_post( $map[ $key ] ) ) {
			continue;
		}
		$name  = $key . '.jpg';
		$local = AR_DIR . '/assets/images/' . $name;
		$tmp   = '';
		if ( file_exists( $local ) ) {
			$tmp = wp_tempnam( $name );
			if ( ! $tmp || ! copy( $local, $tmp ) ) {
				$tmp = '';
			}
		} elseif ( ! empty( $manifest[ $key ] ) ) {
			$dl  = download_url( $manifest[ $key ], 45 );
			$tmp = is_wp_error( $dl ) ? '' : $dl;
		}
		if ( ! $tmp ) {
			$failed[] = $key;
			continue;
		}
		$label = ucwords( str_replace( '-', ' ', $key ) );
		$id    = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), 0, $label );
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp ); // phpcs:ignore
			$failed[] = $key;
			continue;
		}
		update_post_meta( $id, '_ar_demo', $key );
		update_post_meta( $id, '_wp_attachment_image_alt', $label );
		$map[ $key ] = $id;
	}
	update_option( 'ar_demo_media', $map );
	update_option( 'ar_demo_media_failed', array_values( array_unique( $failed ) ) );

	$next = $offset + $step;
	$done = min( $next, $total );
	$msg  = sprintf( /* translators: 1: done 2: total */ __( 'Imported %1$d of %2$d images', 'arctic-resto' ), $done, $total );
	if ( $next >= $total && $failed ) {
		$msg .= ' — ' . sprintf( /* translators: %d count */ __( '%d could not be downloaded (pages will link to the source image instead)', 'arctic-resto' ), count( array_unique( $failed ) ) );
	}
	return array(
		'msg'    => $msg,
		'more'   => $next < $total,
		'offset' => $next,
	);
}

function ar_demo_step_services( $offset ) {
	$n = 0;
	foreach ( ar_demo_services() as $i => $s ) {
		$id = ar_demo_upsert(
			'service:' . $s['slug'],
			array(
				'post_type'    => 'ar_service',
				'post_status'  => 'publish',
				'post_title'   => $s['title'],
				'post_name'    => $s['slug'],
				'post_excerpt' => $s['blurb'],
				'menu_order'   => $i,
			)
		);
		update_post_meta( $id, '_ar_tagline', $s['tagline'] );
		update_post_meta( $id, '_ar_icon', $s['icon'] );
		update_post_meta( $id, '_ar_points', implode( "\n", $s['points'] ) );
		update_post_meta( $id, '_ar_surfaces', implode( "\n", $s['surfaces'] ) );
		$x = ar_demo_service_extra( $s['slug'] );
		if ( $x ) {
			update_post_meta( $id, '_ar_seo_title', $x['seo_title'] );
			update_post_meta( $id, '_ar_seo_desc', $x['seo_desc'] );
		}
		$img = ar_demo_img( $s['img'] );
		if ( $img['id'] ) {
			set_post_thumbnail( $id, $img['id'] );
		}
		ar_demo_elementor_meta( $id, ar_demo_service_elements( $s ), 'wp-post' );
		$n++;
	}
	return array( 'msg' => sprintf( /* translators: %d count */ __( 'Created %d services', 'arctic-resto' ), $n ), 'more' => false );
}

function ar_demo_step_testimonials( $offset ) {
	foreach ( ar_demo_testimonials() as $i => $t ) {
		$id = ar_demo_upsert(
			'testimonial:' . $i,
			array(
				'post_type'    => 'ar_testimonial',
				'post_status'  => 'publish',
				'post_title'   => $t[0],
				'post_content' => $t[3],
				'menu_order'   => $i,
			)
		);
		update_post_meta( $id, '_ar_role', $t[1] );
		update_post_meta( $id, '_ar_tag', $t[2] );
	}
	return array( 'msg' => __( 'Added 5 testimonials', 'arctic-resto' ), 'more' => false );
}

function ar_demo_step_posts( $offset ) {
	$hello = get_page_by_path( 'hello-world', OBJECT, 'post' );
	if ( $hello && ! get_post_meta( $hello->ID, '_ar_demo_key', true ) ) {
		wp_trash_post( $hello->ID );
	}
	foreach ( ar_demo_posts() as $p ) {
		$term = term_exists( $p[3], 'category' );
		if ( ! $term ) {
			$term = wp_insert_term( $p[3], 'category' );
		}
		$cat  = is_wp_error( $term ) ? 0 : (int) ( is_array( $term ) ? $term['term_id'] : $term );
		$body = '';
		foreach ( $p[6] as $para ) {
			$body .= '<p>' . esc_html( $para ) . "</p>\n\n";
		}
		$id = ar_demo_upsert(
			'post:' . $p[0],
			array(
				'post_type'     => 'post',
				'post_status'   => 'publish',
				'post_title'    => $p[1],
				'post_name'     => $p[0],
				'post_excerpt'  => $p[2],
				'post_content'  => $body,
				'post_date'     => $p[4] . ' 09:00:00',
				'post_category' => $cat ? array( $cat ) : array(),
			)
		);
		$img = ar_demo_img( $p[5] );
		if ( $img['id'] ) {
			set_post_thumbnail( $id, $img['id'] );
		}
	}
	return array( 'msg' => __( 'Published 6 blog posts', 'arctic-resto' ), 'more' => false );
}

function ar_demo_step_pages( $offset ) {
	$sample = get_page_by_path( 'sample-page' );
	if ( $sample && ! get_post_meta( $sample->ID, '_ar_demo_key', true ) ) {
		wp_trash_post( $sample->ID );
	}
	$n = 0;
	foreach ( ar_demo_pages() as $slug => $p ) {
		$id = ar_demo_upsert(
			'page:' . $slug,
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $p['title'],
				'post_name'    => basename( $slug ),
				'post_parent'  => false !== strpos( $slug, '/' ) ? ar_demo_page_id( dirname( $slug ) ) : 0,
				'menu_order'   => isset( $p['order'] ) ? (int) $p['order'] : 0,
				'post_excerpt' => $p['excerpt'],
			)
		);
		ar_demo_elementor_meta( $id, $p['els'], 'wp-page' );
		$seo = ar_demo_seo_titles();
		if ( isset( $seo[ $slug ] ) ) {
			update_post_meta( $id, '_ar_seo_title', $seo[ $slug ] );
		}
		if ( ! empty( $p['seo_title'] ) ) {
			update_post_meta( $id, '_ar_seo_title', $p['seo_title'] );
		}
		update_post_meta( $id, '_ar_seo_desc', ! empty( $p['seo_desc'] ) ? $p['seo_desc'] : wp_trim_words( $p['excerpt'], 28, '' ) );
		if ( ! empty( $p['meta'] ) ) {
			foreach ( $p['meta'] as $mk => $mv ) {
				update_post_meta( $id, $mk, $mv );
			}
		}
		if ( ! empty( $p['thumb'] ) ) {
			$timg = ar_demo_img( $p['thumb'] );
			if ( $timg['id'] ) {
				set_post_thumbnail( $id, $timg['id'] );
			}
		}
		$n++;
	}
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
	return array( 'msg' => sprintf( /* translators: %d count */ __( 'Built %d Elementor pages', 'arctic-resto' ), $n ), 'more' => false );
}

function ar_demo_menu( $name, $location ) {
	$menu = wp_get_nav_menu_object( $name );
	$id   = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu( $name );
	foreach ( (array) wp_get_nav_menu_items( $id ) as $it ) {
		wp_delete_post( $it->ID, true );
	}
	$locs              = get_theme_mod( 'nav_menu_locations', array() );
	$locs[ $location ] = $id;
	set_theme_mod( 'nav_menu_locations', $locs );
	return $id;
}

function ar_demo_menu_item( $menu, $title, $args ) {
	return wp_update_nav_menu_item(
		$menu,
		0,
		array_merge(
			array(
				'menu-item-title'  => $title,
				'menu-item-status' => 'publish',
			),
			$args
		)
	);
}
function ar_demo_mi_page( $slug ) {
	return array( 'menu-item-type' => 'post_type', 'menu-item-object' => 'page', 'menu-item-object-id' => ar_demo_page_id( $slug ) );
}

function ar_demo_step_menus( $offset ) {
	$m = ar_demo_menu( 'Arctic Resto Primary', 'primary' );
	ar_demo_menu_item( $m, 'Home', array( 'menu-item-type' => 'custom', 'menu-item-url' => home_url( '/' ) ) );
	$svc = ar_demo_menu_item( $m, 'Services', array_merge( ar_demo_mi_page( 'services' ), array( 'menu-item-classes' => 'ar-mega' ) ) );
	foreach ( ar_demo_services() as $s ) {
		ar_demo_menu_item( $m, $s['title'], array( 'menu-item-type' => 'post_type', 'menu-item-object' => 'ar_service', 'menu-item-object-id' => ar_demo_find( 'service:' . $s['slug'], 'ar_service' ), 'menu-item-parent-id' => $svc ) );
	}
	ar_demo_menu_item( $m, 'How It Works', ar_demo_mi_page( 'how-it-works' ) );
	ar_demo_menu_item( $m, 'Franchise', ar_demo_mi_page( 'franchise' ) );
	$terr = ar_demo_menu_item( $m, 'Territories', ar_demo_mi_page( 'territories' ) );
	foreach ( ar_demo_territory_data() as $t ) {
		ar_demo_menu_item( $m, $t['name'], array_merge( ar_demo_mi_page( 'territories/' . $t['slug'] ), array( 'menu-item-parent-id' => $terr ) ) );
	}
	ar_demo_menu_item( $m, 'About', ar_demo_mi_page( 'about' ) );
	$res = ar_demo_menu_item( $m, 'Resources', array( 'menu-item-type' => 'custom', 'menu-item-url' => '#' ) );
	foreach ( array( 'gallery' => 'Gallery', 'blog' => 'Blog', 'faq' => 'FAQ', 'estimator' => 'Instant Estimator' ) as $slug => $label ) {
		ar_demo_menu_item( $m, $label, array_merge( ar_demo_mi_page( $slug ), array( 'menu-item-parent-id' => $res ) ) );
	}
	ar_demo_menu_item( $m, 'Contact', ar_demo_mi_page( 'contact' ) );

	$c = ar_demo_menu( 'Arctic Resto Footer Company', 'footer_company' );
	foreach ( array( 'about' => 'About us', 'how-it-works' => 'How it works', 'franchise' => 'Franchise', 'territories' => 'Territories', 'gallery' => 'Gallery', 'blog' => 'Blog', 'faq' => 'FAQ', 'contact' => 'Contact', 'privacy-policy' => 'Privacy Policy' ) as $slug => $label ) {
		ar_demo_menu_item( $c, $label, ar_demo_mi_page( $slug ) );
	}

	$f = ar_demo_menu( 'Arctic Resto Footer Services', 'footer_services' );
	foreach ( ar_demo_services() as $s ) {
		ar_demo_menu_item( $f, $s['title'], array( 'menu-item-type' => 'post_type', 'menu-item-object' => 'ar_service', 'menu-item-object-id' => ar_demo_find( 'service:' . $s['slug'], 'ar_service' ) ) );
	}
	return array( 'msg' => __( 'Created primary and footer menus', 'arctic-resto' ), 'more' => false );
}

function ar_demo_step_settings( $offset ) {
	global $wp_rewrite;
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', ar_demo_page_id( 'home' ) );
	update_option( 'blogname', 'Arctic Resto' );
	update_option( 'blogdescription', 'Mobile Dry Ice Cleaning & Restoration — NJ & CT' );
	if ( ! get_option( 'permalink_structure' ) ) {
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
	}
	update_option( 'elementor_disable_color_schemes', 'yes' );
	update_option( 'elementor_disable_typography_schemes', 'yes' );
	ar_enable_elementor_cpt();
	update_option( 'ar_demo_done', 1 );
	flush_rewrite_rules( false );
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
	}
	return array( 'msg' => __( 'Homepage, permalinks and Elementor settings applied', 'arctic-resto' ), 'more' => false );
}

/** Remove everything the importer created. */
function ar_demo_step_remove( $offset ) {
	$ids = get_posts(
		array(
			'post_type'      => array( 'page', 'post', 'ar_service', 'ar_testimonial', 'attachment' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array( // phpcs:ignore
				'relation' => 'OR',
				array( 'key' => '_ar_demo_key', 'compare' => 'EXISTS' ),
				array( 'key' => '_ar_demo', 'compare' => 'EXISTS' ),
			),
		)
	);
	foreach ( $ids as $id ) {
		wp_delete_post( $id, true );
	}
	foreach ( array( 'Arctic Resto Primary', 'Arctic Resto Footer Company', 'Arctic Resto Footer Services' ) as $n ) {
		$m = wp_get_nav_menu_object( $n );
		if ( $m ) {
			wp_delete_nav_menu( $m->term_id );
		}
	}
	delete_option( 'ar_demo_media' );
	delete_option( 'ar_demo_media_failed' );
	delete_option( 'ar_demo_done' );
	update_option( 'show_on_front', 'posts' );
	update_option( 'page_on_front', 0 );
	return array( 'msg' => sprintf( /* translators: %d count */ __( 'Removed %d demo items', 'arctic-resto' ), count( $ids ) ), 'more' => false );
}
