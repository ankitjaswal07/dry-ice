<?php
/**
 * Theme setup, assets and menus.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'after_setup_theme',
	function () {
		load_theme_textdomain( 'arctic-resto', AR_DIR . '/languages' );

		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 80,
				'width'       => 280,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_post_type_support( 'page', 'excerpt' );

		register_nav_menus(
			array(
				'primary'         => __( 'Primary Menu', 'arctic-resto' ),
				'footer_company'  => __( 'Footer – Company', 'arctic-resto' ),
				'footer_services' => __( 'Footer – Services', 'arctic-resto' ),
			)
		);

		add_image_size( 'ar-card', 900, 620, true );
		add_image_size( 'ar-hero', 1920, 1080, false );

		$GLOBALS['content_width'] = 1280;
	}
);

/* Menu: flag the Services item as a mega menu, add ARIA */
add_filter(
	'nav_menu_css_class',
	function ( $classes, $item, $args, $depth ) {
		if ( 'primary' === ( $args->theme_location ?? '' ) && 0 === $depth && in_array( 'menu-item-has-children', $classes, true ) && 'services' === strtolower( trim( $item->title ) ) ) {
			$classes[] = 'ar-mega';
		}
		return $classes;
	},
	10,
	4
);

/* Assets */
add_action(
	'wp_enqueue_scripts',
	function () {
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$css = '/assets/css/theme' . $min . '.css';
		$js  = '/assets/js/theme' . $min . '.js';
		if ( ! file_exists( AR_DIR . $css ) ) {
			$css = '/assets/css/theme.css';
		}
		if ( ! file_exists( AR_DIR . $js ) ) {
			$js = '/assets/js/theme.js';
		}

		wp_enqueue_style( 'ar-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Sora:wght@500;600;700;800&display=swap', array(), null ); // phpcs:ignore
		wp_enqueue_style( 'ar-theme', AR_URI . $css, array(), filemtime( AR_DIR . $css ) );
		wp_enqueue_script(
			'ar-theme',
			AR_URI . $js,
			array(),
			filemtime( AR_DIR . $js ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_localize_script(
			'ar-theme',
			'ARC',
			array(
				'ajax' => admin_url( 'admin-ajax.php' ),
				'i18n' => array(
					'sending' => __( 'Sending…', 'arctic-resto' ),
					'error'   => __( 'Something went wrong. Please try again or call us.', 'arctic-resto' ),
					'ok'      => __( 'Thank you! We will be in touch shortly.', 'arctic-resto' ),
					'before'  => __( 'Before', 'arctic-resto' ),
					'after'   => __( 'After', 'arctic-resto' ),
				),
			)
		);

		// Icon fonts are only needed when Elementor is not inlining SVG icons.
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$svg = false;
			try {
				$svg = \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_font_icon_svg' );
			} catch ( \Throwable $e ) {
				$svg = false;
			}
			if ( ! $svg ) {
				foreach ( array( 'elementor-icons-fa-solid', 'elementor-icons-fa-brands', 'elementor-icons-fa-regular' ) as $h ) {
					if ( wp_style_is( $h, 'registered' ) ) {
						wp_enqueue_style( $h );
					}
				}
			}
		}
	},
	20
);

add_filter(
	'wp_resource_hints',
	function ( $urls, $relation ) {
		if ( 'preconnect' === $relation ) {
			$urls[] = 'https://fonts.googleapis.com';
			$urls[] = array(
				'href'        => 'https://fonts.gstatic.com',
				'crossorigin' => 'anonymous',
			);
		}
		return $urls;
	},
	10,
	2
);

/* Customizer-driven CSS variables */
add_action(
	'wp_head',
	function () {
		$accent = sanitize_hex_color( ar_mod( 'ar_c_accent', '#45d6ff' ) );
		$dark   = sanitize_hex_color( ar_mod( 'ar_c_dark', '#061325' ) );
		if ( '#45d6ff' === $accent && '#061325' === $dark ) {
			return;
		}
		echo '<style id="ar-vars">:root{--glacier:' . esc_html( $accent ) . ';--ink:' . esc_html( $dark ) . '}</style>' . "\n"; // phpcs:ignore
	},
	20
);
