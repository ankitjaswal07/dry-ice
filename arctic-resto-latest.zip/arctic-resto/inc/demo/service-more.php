<?php
/**
 * Extra service-page sections: a sticky "on this page" bar, an honest "good fit / not ideal" grid,
 * a "before we arrive" checklist, pricing factors (no invented prices) and local service areas.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_demo_service_more( $slug ) {
	static $all = null;
	if ( null === $all ) {
		$all = array(
			'aerospace-defense'       => array(
				'fit'    => array( 'Tooling, molds and fixtures with release agent, carbon or coating buildup', 'Ground support and hangar equipment', 'Parts where moisture, media and residue are unacceptable', 'On-site cleaning without disassembly' ),
				'notfit' => array( 'Very thick, fully cured coatings that must be removed to bare metal quickly — chemical or media stripping may be faster', 'Corrosion pitting or damage — dry ice cleans, it does not repair', 'Work that requires a specific certified process or vendor approval — check your requirements first' ),
				'prep'   => array(
					array( 'Share the specification', 'Send the part list and your cleaning specification or acceptance criteria.' ),
					array( 'Confirm site access', 'Provide access, badge and safety requirements for the crew and van.' ),
					array( 'Mark what to protect', 'Identify items that must be masked, removed or kept out of the work zone.' ),
					array( 'Name your inspector', 'Tell us who will inspect and sign off on the result.' ),
				),
			),
			'food-processing'         => array(
				'fit'    => array( 'Ovens, racks, conveyors and mixers with baked-on or greasy buildup', 'Equipment that cannot get wet or take long to dry', 'Restaurants and commercial kitchens needing waterless hood and equipment cleaning', 'Plants that clean during off-shifts or weekends' ),
				'notfit' => array( 'Sanitizing or disinfecting on its own — pair dry ice with your approved sanitation process', 'Very light, quick daily wipe-downs', 'Occupied areas where blasting noise cannot be scheduled around' ),
				'prep'   => array(
					array( 'Choose an off-shift window', 'Pick a time when production is stopped so cleaning does not interrupt product.' ),
					array( 'Clear product and packaging', 'Remove or cover product, packaging and ingredients in the work area.' ),
					array( 'Apply your lockout', 'Lock out equipment according to your procedure before we begin.' ),
					array( 'Share quality requirements', 'Tell us about allergen, GMP and documentation requirements.' ),
				),
			),
			'manufacturing-machinery' => array(
				'fit'    => array( 'Presses, molds and conveyors with grease, oil or carbon buildup', 'Equipment that is costly or slow to disassemble', 'Preventive-maintenance programs on a schedule', 'Cleaning near motors and cabinets under your lockout procedure' ),
				'notfit' => array( 'Heavy rust or thick scale that needs abrasive removal', 'Surfaces where a coating must be fully stripped — another method may be quicker', 'Any work that cannot be locked out safely' ),
				'prep'   => array(
					array( 'Lock out the machine', 'Apply your lockout/tagout procedure and confirm who releases it.' ),
					array( 'Describe the buildup', 'List contaminants and materials — oil, mold release, adhesive, carbon.' ),
					array( 'Give us a downtime window', 'Tell us how long the machine can be down and when.' ),
					array( 'Flag sensitive areas', 'Point out sensors, wiring or seals that need extra care.' ),
				),
			),
			'utilities-power'         => array(
				'fit'    => array( 'Generators, switchgear and control cabinets with dust or oil film', 'Turbine and heat-exchange surfaces with fouling', 'Cleaning inside an outage window', 'Sites that need dry, non-conductive cleaning' ),
				'notfit' => array( 'Energized equipment, unless the owner’s procedures explicitly allow it', 'Confined spaces without a ventilation and entry plan', 'Heavy scale or corrosion that may need a different treatment' ),
				'prep'   => array(
					array( 'Share the outage schedule', 'Send the equipment list, dates and access windows.' ),
					array( 'Arrange isolation and permits', 'Complete isolation, lockout and work permits per your procedures.' ),
					array( 'Plan ventilation', 'Agree a confined-space and CO₂ ventilation plan with your safety team.' ),
					array( 'Provide van access', 'Confirm parking, access route and any escort requirements.' ),
				),
			),
			'automotive-restoration'  => array(
				'fit'    => array( 'Undercarriages and frames with undercoating or road grime', 'Engine bays cleaned without soaking wiring', 'Interiors and chrome cleaned with gentle settings', 'Restorers who want to see the true condition of the metal' ),
				'notfit' => array( 'Heavy, bonded rust that needs abrasive or chemical treatment', 'Stripping full-body paint from large panels — other methods are usually faster', 'Cars that cannot be protected soon after cleaning — bare metal oxidizes quickly' ),
				'prep'   => array(
					array( 'Remove valuables', 'Take personal items out of the car before cleaning.' ),
					array( 'Note what is original', 'Tell us about finishes, markings or parts you want preserved.' ),
					array( 'Plan the next coat', 'Line up primer, paint or rust-preventive coating right after cleaning.' ),
					array( 'Choose the location', 'Pick a shop, garage or driveway with space for the van.' ),
				),
			),
			'boats-marinas'           => array(
				'fit'    => array( 'Boats hauled out on stands, in boatyards or marinas', 'Hull growth, barnacles and salt', 'Engines, bilges and outdrives that need degreasing', 'Owners and yards that want no runoff into the water' ),
				'notfit' => array( 'Gelcoat repair or blister work — cleaning does not repair', 'Hull bottoms while the boat is afloat', 'Very large multi-layer bottom-paint removal, which may be quicker with other methods and needs containment' ),
				'prep'   => array(
					array( 'Schedule the haul-out', 'Have the boat out of the water and secure on stands.' ),
					array( 'Check yard rules', 'Confirm containment and disposal requirements with the yard.' ),
					array( 'Clear loose gear', 'Remove cushions, electronics and loose equipment from the work area.' ),
					array( 'Tell us the paint type', 'Share the bottom-paint type and number of layers if you know them.' ),
				),
			),
			'fire-restoration'        => array(
				'fit'    => array( 'Exposed joists, framing and masonry with soot or char', 'Mold on wood and hard surfaces without adding moisture', 'Restoration contractors who want a dry method', 'Odor caused by residue trapped in framing' ),
				'notfit' => array( 'Structurally compromised members — those need an engineer and rebuild crew', 'Porous materials such as insulation and drywall, which are usually removed and replaced', 'Work without a containment and ventilation plan' ),
				'prep'   => array(
					array( 'Confirm the structure is safe', 'Make sure the building is safe to enter before scheduling.' ),
					array( 'Coordinate with your contractor', 'Involve the restoration contractor and insurer so scope is agreed.' ),
					array( 'Clear contents and debris', 'Remove contents and loose debris from the areas to be cleaned.' ),
					array( 'Plan containment', 'Agree containment, ventilation and access for the van.' ),
				),
			),
		);
	}
	return isset( $all[ $slug ] ) ? $all[ $slug ] : null;
}

/** Sticky "On this page" bar for a service page. */
function ar_demo_service_nav() {
	return ar_demo_w(
		'ar_page_nav',
		array(
			'label' => 'On this page',
			'items' => array(
				array( 'label' => 'Overview', 'anchor' => 'overview' ),
				array( 'label' => 'What we do', 'anchor' => 'what' ),
				array( 'label' => 'Guide', 'anchor' => 'guide' ),
				array( 'label' => 'Compare', 'anchor' => 'compare' ),
				array( 'label' => 'Good fit', 'anchor' => 'fit' ),
				array( 'label' => 'Pricing', 'anchor' => 'pricing' ),
				array( 'label' => 'Process', 'anchor' => 'process' ),
				array( 'label' => 'Where we work', 'anchor' => 'areas' ),
				array( 'label' => 'FAQ', 'anchor' => 'faq' ),
			),
			'b1_t'  => 'Get a quote',
			'b1_u'  => ar_demo_link( '/estimator/' ),
		)
	);
}

/** Fit grid + preparation checklist + pricing factors. */
function ar_demo_service_more_elements( $s ) {
	$m = ar_demo_service_more( $s['slug'] );
	if ( ! $m ) {
		return array();
	}
	$prep = array();
	foreach ( $m['prep'] as $p ) {
		$prep[] = array( 'icon' => ar_demo_icon( 'fas fa-clipboard-check' ), 'title' => $p[0], 'text' => $p[1] );
	}
	$price = array(
		array( 'icon' => ar_demo_icon( 'fas fa-ruler-combined' ), 'title' => 'Size of the area', 'text' => 'Larger surfaces and more equipment take more time and more dry ice.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-layer-group' ), 'title' => 'Type and thickness of buildup', 'text' => 'Light film cleans quickly; thick coatings, carbon or growth need more passes.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-truck-loading' ), 'title' => 'Access and setup', 'text' => 'Tight spaces, distance from the van and safety or containment needs affect setup time.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-calendar-alt' ), 'title' => 'Schedule', 'text' => 'Off-shift, weekend or urgent work can change how the job is planned and priced.' ),
	);
	return array(
		ar_demo_w(
			'ar_fit',
			array_merge(
				ar_demo_h( 'Is it right for you?', 'A clear look at {{when dry ice fits}}', 'So you know what to expect before you book.' ),
				array(
					'good_t' => 'Good fit',
					'good'   => implode( "\n", $m['fit'] ),
					'bad_t'  => 'Probably not the best fit',
					'bad'    => implode( "\n", $m['notfit'] ),
					'note'   => 'Not sure? Describe your project and we will tell you honestly whether dry ice is the right method.',
					'anchor' => 'fit',
					'theme'  => 'light',
				)
			)
		),
		ar_demo_w(
			'ar_icon_boxes',
			array_merge(
				ar_demo_h( 'Preparation', 'What to have ready {{before we arrive}}' ),
				array( 'layout' => 'cards', 'cols' => '4', 'theme' => 'frost', 'items' => $prep )
			)
		),
		ar_demo_w(
			'ar_icon_boxes',
			array_merge(
				ar_demo_h( 'Pricing', 'What affects your {{quote}}', 'Every job is quoted after a free assessment. These are the factors that matter most.' ),
				array( 'layout' => 'numbered', 'cols' => '4', 'theme' => 'light', 'anchor' => 'pricing', 'items' => $price )
			)
		),
	);
}

/** Local internal links: where this service is available. */
function ar_demo_service_areas( $s ) {
	return ar_demo_w(
		'ar_terr_cards',
		array_merge(
			ar_demo_h( 'Where we work', strtolower( $s['title'] ) . ' cleaning across {{NJ & CT}}', 'Choose a territory to see coverage areas, local guidance and how to book.' ),
			array( 'count' => -1, 'anchor' => 'areas', 'theme' => 'frost' )
		)
	);
}
