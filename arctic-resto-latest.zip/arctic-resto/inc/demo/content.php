<?php
/**
 * Demo content definitions. Every page is expressed as Elementor containers that
 * each hold one Arctic Resto widget, so the whole site is editable in Elementor.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
/* Builders                                                            */
/* ------------------------------------------------------------------ */
/**
 * Demo image manifest.
 * Brand images (hero, van, pellets, territories) ship inside the theme; the stock photos are
 * downloaded into the Media Library during import (free Pexels licence), which keeps the theme
 * package small. The key is used everywhere demo content refers to an image.
 */
function ar_demo_media_manifest() {
	$px  = function ( $id, $w, $h ) {
		return 'https://images.pexels.com/photos/' . $id . '/pexels-photo-' . $id . '.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=' . $h . '&w=' . $w;
	};
	$out = array();
	// Shipped with the theme (assets/images/<key>.jpg).
	foreach ( array( 'hero-blast', 'van', 'pellets', 'territory-ct', 'territory-nj', 'territory-ma', 'territory-se' ) as $k ) {
		$out[ $k ] = '';
	}
	// Downloaded on import: key => remote URL.
	$out['aerospace']          = $px( 37616786, 1400, 900 );
	$out['aerospace-hero']     = $px( 5262808, 1600, 900 );
	$out['food']               = $px( 38336747, 1400, 900 );
	$out['food-hero']          = $px( 5532664, 1600, 900 );
	$out['manufacturing']      = $px( 34718922, 1400, 900 );
	$out['manufacturing-hero'] = $px( 38427501, 1600, 900 );
	$out['power']              = $px( 20220795, 1400, 900 );
	$out['power-hero']         = $px( 35596450, 1600, 900 );
	$out['auto']               = $px( 8310758, 1400, 900 );
	$out['auto-hero']          = $px( 10866831, 1600, 900 );
	$out['marine']             = $px( 38327266, 1400, 900 );
	$out['marine-hero']        = $px( 11471788, 1600, 900 );
	$out['fire']               = $px( 10252687, 1400, 900 );
	$out['fire-hero']          = $px( 13531436, 1600, 900 );
	$out['worker']             = $px( 37668425, 1600, 1000 );
	$out['engine']             = $px( 7565174, 1400, 900 );
	$out['boat-repair']        = $px( 37274934, 1400, 900 );
	return $out;
}

/** Elementor media value for a demo image: Media Library item, else theme file, else source URL. */
function ar_demo_img( $key ) {
	$map = get_option( 'ar_demo_media', array() );
	if ( isset( $map[ $key ] ) && wp_get_attachment_url( $map[ $key ] ) ) {
		return array( 'url' => wp_get_attachment_url( $map[ $key ] ), 'id' => (int) $map[ $key ] );
	}
	if ( file_exists( AR_DIR . '/assets/images/' . $key . '.jpg' ) ) {
		return array( 'url' => ar_theme_img( $key ), 'id' => '' );
	}
	$man = ar_demo_media_manifest();
	return array( 'url' => ! empty( $man[ $key ] ) ? $man[ $key ] : '', 'id' => '' );
}
function ar_demo_icon( $c ) {
	$lib = 0 === strpos( $c, 'fab ' ) ? 'fa-brands' : ( 0 === strpos( $c, 'far ' ) ? 'fa-regular' : 'fa-solid' );
	return array( 'value' => $c, 'library' => $lib );
}
function ar_demo_link( $p ) {
	return array( 'url' => $p, 'is_external' => '', 'nofollow' => '', 'custom_attributes' => '' );
}
function ar_demo_uid() {
	return substr( md5( uniqid( '', true ) ), 0, 7 );
}
function ar_demo_ids( $settings ) {
	foreach ( $settings as $k => $v ) {
		if ( is_array( $v ) && $v && isset( $v[0] ) && is_array( $v[0] ) ) {
			foreach ( $v as $i => $item ) {
				if ( ! isset( $item['_id'] ) ) {
					$item['_id'] = ar_demo_uid();
				}
				$v[ $i ] = $item;
			}
			$settings[ $k ] = $v;
		}
	}
	return $settings;
}
/** One full-width container holding one widget. */
function ar_demo_w( $type, $s ) {
	return array(
		'id'       => ar_demo_uid(),
		'elType'   => 'container',
		'isInner'  => false,
		'settings' => array(
			'content_width'  => 'full',
			'flex_direction' => 'column',
			'padding'        => array( 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ),
			'flex_gap'       => array( 'unit' => 'px', 'size' => 0, 'column' => '0', 'row' => '0', 'isLinked' => true ),
			'css_classes'    => 'ar-con',
		),
		'elements' => array(
			array(
				'id'         => ar_demo_uid(),
				'elType'     => 'widget',
				'isInner'    => false,
				'widgetType' => $type,
				'settings'   => ar_demo_ids( $s ),
				'elements'   => array(),
			),
		),
	);
}
function ar_demo_h( $eyebrow, $title, $sub = '', $align = 'center' ) {
	return array( 'eyebrow' => $eyebrow, 'title' => $title, 'subtitle' => $sub, 'align' => $align );
}
function ar_demo_cta( $title = 'Book your free assessment', $text = "Tell us about your surface, contaminant and timeline. We'll recommend the right pressure, pellet size and approach." ) {
	return ar_demo_w( 'ar_cta', array( 'title' => $title, 'text' => $text, 'b1_t' => 'Get Instant Quote', 'b1_u' => ar_demo_link( '/estimator/' ), 'theme' => 'gradient' ) );
}
function ar_demo_hero( $eyebrow, $title, $sub, $bg, $b1 = '', $b1u = '', $b2 = '', $b2u = '' ) {
	return ar_demo_w(
		'ar_page_hero',
		array(
			'eyebrow'  => $eyebrow,
			'title'    => $title,
			'subtitle' => $sub,
			'bg'       => ar_demo_img( $bg ),
			'crumbs'   => 'yes',
			'b1_t'     => $b1,
			'b1_u'     => ar_demo_link( $b1u ),
			'b2_t'     => $b2,
			'b2_u'     => ar_demo_link( $b2u ),
		)
	);
}

/* ------------------------------------------------------------------ */
/* Services                                                            */
/* ------------------------------------------------------------------ */
function ar_demo_services() {
	return array(
		array(
			'slug' => 'aerospace-defense', 'title' => 'Aerospace & Defense', 'tagline' => 'Precision cleaning for flight-critical assets', 'icon' => 'fas fa-plane', 'img' => 'aerospace', 'hero' => 'aerospace-hero',
			'blurb' => 'Non-abrasive, zero-moisture cleaning for airframes, turbine components, tooling and ground support equipment — without the risk of FOD, corrosion or hydrogen embrittlement.',
			'points' => array( 'Paint & coating removal', 'Engine & turbine parts', 'Composite-safe' ),
			'surfaces' => array( 'Aluminum', 'Titanium', 'Composites', 'Stainless' ),
			'body' => array(
				array( 'Clean without compromising tolerances', 'Dry ice pellets sublimate on contact, so there is no media, no moisture and no residue left behind. That means no FOD risk and no re-work on sensitive assemblies.' ),
				array( 'Tooling, molds and GSE', 'Remove release agents, carbon buildup, epoxy and paint from tooling and ground support equipment in place — keeping your maintenance windows short and your hangar productive.' ),
				array( 'Preserve critical finishes', 'Because dry ice is non-abrasive, it preserves surface finishes and dimensional integrity on components where micron-level tolerances matter.' ),
			),
			'faqs' => array(
				array( 'Will dry ice damage aluminum or composite parts?', 'No. Dry ice is non-abrasive, and we tune pressure and pellet size so critical surface finishes and tolerances are preserved.' ),
				array( 'Is there any foreign object debris (FOD) risk?', 'Pellets sublimate into gas on contact, so there is no blasting media left behind to become FOD.' ),
			),
		),
		array(
			'slug' => 'food-processing', 'title' => 'Food Processing & Equipment', 'tagline' => 'Sanitize production lines without water or chemicals', 'icon' => 'fas fa-utensils', 'img' => 'food', 'hero' => 'food-hero',
			'blurb' => 'In-place cleaning for ovens, conveyors, mixers and packaging lines. Dry ice is FDA-approved for food processing equipment — and with no wash-down water there is less risk, less downtime and faster returns to production.',
			'points' => array( 'Bakery ovens & conveyors', 'In-place cleaning', 'No water, no rinse' ),
			'surfaces' => array( 'Stainless steel', 'Belts', 'Plastics', 'Welded frames' ),
			'body' => array(
				array( 'Food-safe, allergen-friendly', 'Dry ice cleaning removes grease, carbonized residue, starch and protein buildup without water, solvents or secondary waste — reducing cross-contamination risk.' ),
				array( 'Cut downtime between shifts', 'Because there is no drying time and no teardown, equipment can return to production immediately. Many plants reclaim hours per shift.' ),
				array( 'Audit-ready', 'The process leaves no chemical residue, so you avoid the documentation headaches that come with caustic cleaners.' ),
			),
			'faqs' => array(
				array( 'Is dry ice safe for food-related areas?', 'Yes. Dry ice is FDA-approved for food processing equipment, making it ideal for restaurants, commercial kitchens and production plants.' ),
				array( 'Can you clean around a tight production schedule?', 'Yes. With no drying time and no teardown, we can clean during off-shifts and return equipment to service quickly.' ),
			),
		),
		array(
			'slug' => 'manufacturing-machinery', 'title' => 'Manufacturing & Machinery', 'tagline' => 'Keep production lines running at full capacity', 'icon' => 'fas fa-industry', 'img' => 'manufacturing', 'hero' => 'manufacturing-hero',
			'blurb' => 'Remove grease, oil, adhesives, mold release, ink and production buildup from live machinery and equipment — often without shutting down the line for long.',
			'points' => array( 'Injection molds & presses', 'Electrical cabinets', 'Preventive maintenance' ),
			'surfaces' => array( 'Steel', 'Cast iron', 'Plastic', 'Concrete floors' ),
			'body' => array(
				array( 'Clean without teardown', 'Our technicians reach into tight spaces on active machinery. Dry ice does not conduct electricity or add moisture, so motors, sensors and PLCs stay protected.' ),
				array( 'Mold & press maintenance', 'Strip release agents, carbon and scale from injection molds, extrusion dies and stamping presses without hours of hand-scrubbing or surface damage.' ),
				array( 'Predictable PM schedules', 'Regular dry ice cleaning keeps heat exchangers, bearings and conveyors running cooler and longer, reducing unplanned downtime.' ),
			),
			'faqs' => array(
				array( 'Can machinery be cleaned while installed?', 'In most cases yes. Dry ice is dry and non-conductive, so we clean in place and avoid lengthy teardown.' ),
				array( 'What contaminants do you remove?', 'Grease, oil, adhesives, mold release, ink, carbon and general production buildup from a wide range of surfaces.' ),
			),
		),
		array(
			'slug' => 'utilities-power', 'title' => 'Utilities & Power Plants', 'tagline' => 'Non-conductive cleaning for energized equipment', 'icon' => 'fas fa-bolt', 'img' => 'power', 'hero' => 'power-hero',
			'blurb' => 'Safely clean turbines, generators, switchgear and control equipment. Dry ice is non-conductive, so sensitive electrical assets stay protected.',
			'points' => array( 'Generators & turbines', 'Switchgear & transformers', 'Outage-window cleaning' ),
			'surfaces' => array( 'Copper windings', 'Insulators', 'Bus bars', 'Turbine blades' ),
			'body' => array(
				array( 'Work within outage windows', 'Turnaround schedules are tight. Our fully equipped Sprinter vans mobilize quickly, so cleaning happens on your timeline.' ),
				array( 'Electrically safe', 'Because dry ice is non-conductive and leaves no residue, switchgear and control cabinets can be cleaned with minimal disruption.' ),
				array( 'Turbines & heat exchangers', 'Remove fouling, scale and carbon without the thermal shock or abrasion of traditional methods.' ),
			),
			'faqs' => array(
				array( 'Is dry ice safe around electrical equipment?', 'Dry ice is non-conductive and leaves no moisture or residue, making it well suited to switchgear, generators and control cabinets.' ),
				array( 'Can you work inside an outage window?', 'Yes. Our vans arrive fully equipped so work begins the moment access is granted.' ),
			),
		),
		array(
			'slug' => 'automotive-restoration', 'title' => 'Automotive Restoration', 'tagline' => 'Bring classics back without stripping originality', 'icon' => 'fas fa-car', 'img' => 'auto', 'hero' => 'auto-hero',
			'blurb' => 'Strip undercoating, grease, rust and decades of road grime from classic and collector cars without damaging paint, chrome, wiring harnesses or delicate original parts.',
			'points' => array( 'Undercarriage & engine bays', 'Interiors & fabrics', 'Chrome & original finishes' ),
			'surfaces' => array( 'Steel', 'Aluminum', 'Rubber', 'Chrome', 'Fabric' ),
			'body' => array(
				array( 'Preserve originality', 'Dry ice removes contaminants without altering the metal, paint or patina underneath. No warping thin panels, no lifting decals, no soaking wiring.' ),
				array( 'Complete undercarriage restoration', 'Reveal the original chassis, suspension and drivetrain by stripping undercoating, rust scale and grease — without disassembly.' ),
				array( 'Engines and interiors', 'Degrease engine bays and restore chrome details and fabric interiors without water, so a car can be shown, driven or sold looking factory-fresh.' ),
			),
			'faqs' => array(
				array( 'Will it harm paint, chrome or wiring?', 'No. Dry ice sublimates on contact and leaves no chemical residue, making it ideal for sensitive areas like paint, engines and electronic components.' ),
				array( 'Can it clean interiors?', 'Yes. Dry ice can restore chrome details and fabric interiors without the abrasiveness of other cleaning methods.' ),
			),
		),
		array(
			'slug' => 'boats-marinas', 'title' => 'Boats & Marinas', 'tagline' => 'Hull, engine and bilge cleaning — nothing in the water', 'icon' => 'fas fa-anchor', 'img' => 'marine', 'hero' => 'marine-hero',
			'blurb' => 'Effectively remove salt, barnacles and contaminants from boats and marine equipment with zero moisture — at your slip, yard or marina, with nothing entering the water.',
			'points' => array( 'Hull & bottom paint removal', 'Engines & bilges', 'Marina-friendly' ),
			'surfaces' => array( 'Fiberglass', 'Aluminum hulls', 'Teak', 'Outdrives' ),
			'body' => array(
				array( 'Environmentally sound', 'Dry ice pellets turn to CO₂ gas on contact — no media, no water and no chemical runoff into the harbor.' ),
				array( 'Bottom paint and barnacles', 'Strip antifouling paint and marine growth back to gelcoat or bare aluminum without gouging the substrate.' ),
				array( 'Engines, outdrives and bilges', 'Degrease engines, outdrives and bilges without washing oil and grime into the water below.' ),
			),
			'faqs' => array(
				array( 'Does anything enter the water?', 'No. Pellets turn to CO₂ gas on contact, so no media, chemicals or wash water reach the harbor.' ),
				array( 'What does marine cleaning remove?', 'Salt, barnacles, marine growth, old bottom paint, oil and grime — with zero moisture.' ),
			),
		),
		array(
			'slug' => 'fire-restoration', 'title' => 'Fire Restoration', 'tagline' => 'Lift soot, char and smoke odor without adding moisture', 'icon' => 'fas fa-fire', 'img' => 'fire', 'hero' => 'fire-hero',
			'blurb' => 'Dry ice cleaning for fire, water and mold damage — an eco-friendly, chemical-free solution that removes soot, char and mold from wood, brick and joists without adding moisture.',
			'points' => array( 'Soot, char & smoke odor', 'Mold & water-stain removal', 'Restores wood, brick & joists' ),
			'surfaces' => array( 'Wood framing', 'Brick', 'Concrete', 'Structural steel' ),
			'body' => array(
				array( 'No added moisture', 'Unlike pressure washing or chemical washes, dry ice adds zero water — avoiding the secondary mold risk that often follows fire restoration.' ),
				array( 'Eliminate smoke odor at the source', 'Dry ice removes the char and residue that trap smoke odor in framing and masonry — homes smell clean again, not perfumed.' ),
				array( 'Faster reoccupancy', 'With no drying time, no chemical rinse and no secondary waste, restoration contractors can move to the rebuild phase sooner.' ),
			),
			'faqs' => array(
				array( 'Does dry ice cleaning remove smoke odors?', 'Absolutely. It effectively eliminates smoke residue and lingering odors, restoring air quality in fire-damaged spaces.' ),
				array( 'Is it safe for wood, brick and metal?', 'Yes. Dry ice cleaning is gentle yet powerful, safe for materials like wood, brick and metal without causing additional damage.' ),
				array( 'Can it remove mold?', 'Yes. It removes mold from surfaces without introducing moisture, reducing the risk of regrowth.' ),
			),
		),
	);
}

/** Elementor layout for one service page. */
function ar_demo_service_elements_basic( $s ) {
	$process = array(
		array( 'icon' => ar_demo_icon( 'fas fa-clipboard-check' ), 'title' => 'Free Assessment', 'text' => 'Tell us about your surface, contaminant and timeline. We recommend the right pressure, pellet size and approach.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'We Come to You', 'text' => 'Our fully outfitted Mercedes Sprinter vans arrive on-site with industrial-grade equipment.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-snowflake' ), 'title' => 'Dry Ice Cleaning', 'text' => 'Recycled CO₂ pellets lift contaminants without water, chemicals or abrasion.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-check-circle' ), 'title' => 'Clean, Dry & Done', 'text' => 'Pellets sublimate into gas, leaving only the dislodged residue to sweep up.' ),
	);
	$caps = array();
	foreach ( $s['body'] as $b ) {
		$caps[] = array( 'icon' => ar_demo_icon( $s['icon'] ), 'title' => $b[0], 'text' => $b[1] );
	}
	$faq = array();
	foreach ( $s['faqs'] as $f ) {
		$faq[] = array( 'q' => $f[0], 'a' => $f[1], 'cat' => 'General' );
	}
	return array(
		ar_demo_hero( $s['tagline'], $s['title'], $s['blurb'], $s['hero'], 'Get instant quote', '/estimator/', 'All services', '/services/' ),
		ar_demo_w( 'ar_icon_boxes', array( 'layout' => 'bar', 'cols' => '4', 'theme' => 'dark', 'pad' => 'sm', 'items' => array(
			array( 'icon' => ar_demo_icon( 'fas fa-tint' ), 'title' => 'No water', 'text' => 'Completely dry' ),
			array( 'icon' => ar_demo_icon( 'fas fa-flask' ), 'title' => 'No chemicals', 'text' => 'Recycled CO₂' ),
			array( 'icon' => ar_demo_icon( 'fas fa-recycle' ), 'title' => 'No waste', 'text' => 'Pellets sublimate' ),
			array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'On-site', 'text' => 'Mobile Sprinter van' ),
		) ) ),
		ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'What we do', 'Capabilities for {{' . strtolower( $s['title'] ) . '}}' ), array( 'layout' => 'numbered', 'cols' => '3', 'theme' => 'light', 'items' => $caps ) ) ),
		ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'Key benefits', 'Built for {{' . strtolower( $s['title'] ) . '}}', '', 'left' ), array(
			'body'    => '<p>Surfaces we clean: ' . esc_html( implode( ', ', $s['surfaces'] ) ) . '.</p><p>Set the pressure and pellet size for harsh or delicate applications — one process, no water, no chemicals, no secondary waste.</p>',
			'checks'  => implode( "\n", $s['points'] ),
			'image'   => ar_demo_img( $s['img'] ),
			'badge_t' => 'On-site service',
			'badge_s' => 'NJ & CT',
			'b1_t'    => 'Get a free quote',
			'b1_u'    => ar_demo_link( '/estimator/' ),
			'theme'   => 'frost',
		) ) ),
		ar_demo_w( 'ar_before_after', array_merge( ar_demo_h( 'See the difference', 'Drag to reveal the {{clean}}' ), array( 'items' => array( array( 'label' => $s['title'], 'after' => ar_demo_img( $s['img'] ) ) ), 'theme' => 'void' ) ) ),
		ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Process', 'How we clean {{' . strtolower( $s['title'] ) . '}}' ), array( 'layout' => 'process', 'cols' => '4', 'theme' => 'light', 'items' => $process ) ) ),
		ar_demo_w( 'ar_faq', array_merge( ar_demo_h( 'FAQ', 'Questions about {{' . strtolower( $s['title'] ) . '}}' ), array( 'items' => $faq, 'theme' => 'frost' ) ) ),
		ar_demo_w( 'ar_services', array_merge( ar_demo_h( 'Related services', 'You may also {{need}}' ), array( 'layout' => 'grid', 'count' => 3, 'exclude' => 'yes', 'theme' => 'light' ) ) ),
		ar_demo_cta(),
	);
}

/* ------------------------------------------------------------------ */
/* Testimonials & posts                                                */
/* ------------------------------------------------------------------ */
function ar_demo_testimonials() {
	return array(
		array( 'Dana Whitfield', 'Plant Manager, Regional Bakery', 'Food Processing', 'They cleaned our bakery ovens and conveyors in a single overnight shift. No water, no chemicals, and we were back in production before the morning crew arrived.' ),
		array( 'Marcus Ellery', 'Maintenance Lead, Aerospace Supplier', 'Aerospace & Defense', 'Our tooling comes back looking new without a single scratch on the substrate. The team understood our tolerances right away and worked around our schedule.' ),
		array( 'Tony Ricci', 'Classic Car Restorer', 'Automotive Restoration', 'We had a 1967 fastback with decades of undercoating. Dry ice took it to bare metal without touching the original paint on the fenders. Unbelievable result.' ),
		array( 'Priya Nandakumar', 'Homeowner', 'Fire Restoration', 'After the fire, the smell was the hardest part. Dry ice removed the char from the joists and the house smells like wood again — not chemicals.' ),
		array( 'Captain Ben Alvarado', 'Marina Operator', 'Boats & Marinas', 'Hull cleaning at our slip with nothing going into the water was a game changer for our marina. We now book them every spring.' ),
	);
}

function ar_demo_posts() {
	return array(
		array( 'dry-ice-cleaning-for-fire-restoration', 'Why Dry Ice Cleaning Is Changing Fire Restoration', 'Soot, char and smoke odor — removed without water or chemicals. Here is why restoration pros are switching.', 'Fire Restoration', '2025-09-18', 'fire', array(
			'Restoration companies face significant challenges when treating fire, water and mold damage in homes and businesses. Traditional methods add moisture and chemicals to surfaces that are already vulnerable.',
			'Dry ice cleaning removes soot, char, mold and water stains, restoring wood, brick and structural joists to nearly their original condition. Because the pellets sublimate on contact, there is no secondary waste to collect or dispose of.',
			'The result is a cleaner, faster job: no drying time, no chemical smell and no risk of introducing new moisture into framing. That is why dry ice is quickly becoming the method of choice for restoration professionals.',
			'The process is also gentle on structural integrity. Its non-abrasive nature preserves surfaces, making it a safe choice for delicate restoration work.',
		) ),
		array( 'dry-ice-blasting-for-food-plants', 'Dry Ice Blasting in Food Plants: Cleaner Lines, Less Downtime', 'FDA-approved and waterless — how dry ice keeps production lines sanitary between shifts.', 'Food Processing', '2025-08-26', 'food', array(
			'Water is the enemy of a food plant sanitation crew: it spreads contamination, needs drying time and carries risk for electrical equipment.',
			'Dry ice cleaning is FDA-approved for food processing equipment and uses no water or chemicals. Ovens, conveyors, mixers and packaging lines can be cleaned in place.',
			'With no secondary waste and no drying, teams reclaim hours per shift and simplify audit documentation.',
		) ),
		array( 'restoring-a-classic-without-losing-originality', 'Restoring a Classic Without Losing Its Originality', 'Undercoating, grease and grime come off; the original paint and patina stay put.', 'Automotive', '2025-07-30', 'auto', array(
			'Car enthusiasts want to preserve what is original. Media blasting and chemical strippers can pit metal, lift decals and soak wiring.',
			'Dry ice restores a vehicle’s original finish, from chrome details to fabric interiors, without abrasiveness. Since it sublimates on contact there is no chemical residue on paint, engines or electronic components.',
			'The result: a chassis that looks factory-fresh and a restoration you can be proud to show.',
		) ),
		array( 'marine-cleaning-with-zero-moisture', 'Marine Cleaning: Removing Salt and Barnacles with Zero Moisture', 'Hull, engine and bilge cleaning that keeps the harbor clean too.', 'Marine', '2025-06-12', 'marine', array(
			'Boat owners and marinas need effective solutions that will not send contaminants into the water.',
			'Dry ice effectively removes salt, barnacles and contaminants from boats and marine equipment with zero moisture. Pellets become CO₂ gas on contact.',
			'It is a spring commissioning upgrade that saves time and protects the environment.',
		) ),
		array( 'how-dry-ice-cleaning-works', 'How Dry Ice Cleaning Actually Works', 'Kinetic energy, thermal shock and sublimation — the science behind the safe, clean feeling.', 'Education', '2025-05-20', 'pellets', array(
			'Solid CO₂ pellets are accelerated by compressed air through a nozzle. On impact, three things happen almost at once.',
			'First, kinetic energy dislodges loose material. Second, thermal shock embrittles the contaminant so it cracks and lifts. Third, the pellet sublimates — expanding rapidly into gas and lifting the contaminant from the surface.',
			'The pellet is gone in milliseconds. What is left is only the dislodged residue, ready to sweep up.',
		) ),
		array( 'why-mobile-dry-ice-franchise', 'Why Mobile Dry Ice Cleaning Is Ready to Franchise', 'A business-in-a-box, a fully outfitted van and seven industries to serve.', 'Franchise', '2025-04-08', 'van', array(
			'Arctic Resto launched in early 2024 with a bold approach: build the franchise framework first, then scale.',
			'Franchisees own their van and equipment 100%. Once financing is secured the van is built, training is scheduled and owners are ready for their first jobs at the close of training.',
			'With a centralized call center, done-for-you marketing and a custom technology platform, owners can focus on the work and the customers.',
		) ),
	);
}

/* ------------------------------------------------------------------ */
/* Shared snippets                                                     */
/* ------------------------------------------------------------------ */
function ar_demo_process_items() {
	return array(
		array( 'icon' => ar_demo_icon( 'fas fa-clipboard-check' ), 'title' => 'Free Assessment', 'text' => 'Tell us about your surface, contaminant and timeline. We recommend the right pressure, pellet size and approach.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'We Come to You', 'text' => 'Our fully outfitted Mercedes Sprinter vans arrive on-site with industrial-grade equipment. No need to move a thing.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-snowflake' ), 'title' => 'Dry Ice Cleaning', 'text' => 'Recycled CO₂ pellets are accelerated at the surface, lifting contaminants without water, chemicals or abrasion.' ),
		array( 'icon' => ar_demo_icon( 'fas fa-check-circle' ), 'title' => 'Clean, Dry & Done', 'text' => 'Pellets sublimate into gas, leaving only the dislodged residue to sweep up. Back in service — fast.' ),
	);
}
function ar_demo_compare() {
	return array(
		array( 'title' => 'Water required', 'a' => 'None', 'b' => 'Gallons per job' ),
		array( 'title' => 'Chemicals', 'a' => 'None', 'b' => 'Solvents & detergents' ),
		array( 'title' => 'Secondary waste', 'a' => 'None — pellets sublimate', 'b' => 'Media, runoff & sludge' ),
		array( 'title' => 'Abrasion to surface', 'a' => 'Non-abrasive', 'b' => 'Pitting & wear' ),
		array( 'title' => 'Downtime', 'a' => 'Minimal, in-place', 'b' => 'Teardown & drying time' ),
	);
}
function ar_demo_faqs() {
	return array(
		array( 'General', 'What is dry ice cleaning?', 'Dry ice cleaning accelerates solid CO₂ pellets with compressed air. The pellets lift contaminants from the surface and then sublimate straight into gas — leaving no water, media or chemical residue.' ),
		array( 'General', 'Does dry ice cleaning create a mess?', 'No. Unlike traditional cleaning methods, it produces zero secondary waste — only the removed dirt or grime remains.' ),
		array( 'General', 'What surfaces can it clean?', 'Steel, metal, cement, stone, wood and plastic, among others. We adjust pressure and pellet size for harsh or delicate applications.' ),
		array( 'General', 'Do you come to me?', 'Yes. We are fully mobile. Our Mercedes Sprinter vans carry 900 lbs of dry ice, a compressor and industrial-grade blasting equipment.' ),
		array( 'Safety', 'Is dry ice cleaning safe for food-related areas?', 'Dry ice is FDA-approved for food processing equipment, making it ideal for restaurants and commercial kitchens.' ),
		array( 'Safety', 'Is it safe for electrical equipment?', 'Yes. Dry ice is non-conductive and completely dry, which protects motors, switchgear and control equipment.' ),
		array( 'Safety', 'Is it safe for people and pets?', 'The process uses recycled carbon dioxide with no chemicals. Our technicians manage ventilation and safe work zones on every job.' ),
		array( 'Restoration', 'Does it remove smoke odor and mold?', 'Yes. It removes soot, char, smoke residue and mold without introducing moisture, helping to eliminate lingering odors.' ),
		array( 'Restoration', 'How does it compare to traditional restoration?', 'Unlike pressure washing or abrasive cleaning, dry ice cleaning is non-destructive and leaves no secondary waste.' ),
		array( 'Restoration', 'How quickly can fire-damaged surfaces be restored?', 'The process is fast and requires minimal downtime, allowing restoration work to proceed efficiently.' ),
		array( 'Business', 'Where do you operate?', 'We serve New Jersey and Connecticut today, with Massachusetts franchise territories opening and Southeast expansion planned.' ),
		array( 'Business', 'Can I own an Arctic Resto franchise?', 'Yes. Ours is the industry’s first and only mobile dry ice cleaning franchise opportunity. Visit the franchise page to learn more.' ),
		array( 'Business', 'How do I get a quote?', 'Use our instant estimator, call us or send a message. We recommend the right pressure, pellet size and approach for your project.' ),
	);
}
function ar_demo_faq_items( $only = null ) {
	$out = array();
	foreach ( ar_demo_faqs() as $i => $f ) {
		if ( null !== $only && ! in_array( $i, $only, true ) ) {
			continue;
		}
		$out[] = array( 'cat' => $f[0], 'q' => $f[1], 'a' => $f[2] );
	}
	return $out;
}
function ar_demo_territories() {
	return array(
		array( 'code' => 'CT', 'name' => 'Connecticut', 'tone' => 'live', 'status' => 'Serving now', 'blurb' => 'Home base. Our first corporate van hits the road weekly across Connecticut.', 'areas' => "Fairfield County\nNew Haven County\nHartford County\nLitchfield County\nMiddlesex County\nNew London County\nTolland County\nWindham County", 'x' => 62, 'y' => 42 ),
		array( 'code' => 'NJ', 'name' => 'New Jersey', 'tone' => 'live', 'status' => 'Serving now', 'blurb' => 'Industrial and commercial customers across northern and central New Jersey.', 'areas' => "Bergen County\nEssex County\nHudson County\nMiddlesex County\nMonmouth County\nMorris County\nPassaic County\nUnion County", 'x' => 38, 'y' => 68 ),
		array( 'code' => 'MA', 'name' => 'Massachusetts', 'tone' => 'soon', 'status' => 'Franchise territories opening', 'blurb' => 'Prime territories now being offered to franchise owners.', 'areas' => "Suffolk County\nMiddlesex County\nNorfolk County\nWorcester County\nHampden County\nEssex County", 'x' => 66, 'y' => 20 ),
		array( 'code' => 'SE', 'name' => 'Southeast USA', 'tone' => 'plan', 'status' => 'Planned expansion', 'blurb' => 'Expansion into the Southeast is planned. Register your interest early.', 'areas' => "Georgia\nFlorida\nThe Carolinas\nTennessee", 'x' => 22, 'y' => 88 ),
	);
}

/* ------------------------------------------------------------------ */
/* Pages                                                               */
/* ------------------------------------------------------------------ */
function ar_demo_pages() {
	$features = array( 'A proven business model', 'Low initial investment', 'Access to a world-class executive team', 'Unique, differentiated branding', 'Multiple revenue streams', 'Comprehensive “done for you” marketing', 'Lead generation & appointment setting', 'Extensive training & corporate support', 'Industry-leading proprietary technology suite' );
	$pages    = array();

	/* ---------------- HOME ---------------- */
	$pages['home'] = array(
		'title'   => 'Home',
		'excerpt' => 'Arctic Resto is an eco-friendly mobile dry ice cleaning service for aerospace, food processing, manufacturing, power plants, automotive, marine and fire restoration across NJ & CT. No water. No chemicals. No mess.',
		'els'     => array(
			ar_demo_w( 'ar_hero', array(
				'badge' => 'Mobile dry ice cleaning · NJ & CT', 'title_a' => 'Experience the power of mobile dry ice cleaning for',
				'words' => "Aerospace\nFood Plants\nFactories\nPower Plants\nClassic Cars\nBoats & Marinas\nFire Damage", 'title_b' => '',
				'subtitle' => 'Arctic Resto is an eco-friendly mobile cleaning service with fully outfitted Mercedes Sprinter vans. No water. No chemicals. No mess — just clean and green.',
				'b1_t' => 'Get Instant Quote', 'b1_u' => ar_demo_link( '/estimator/' ), 'b2_t' => 'See how it works', 'b2_u' => ar_demo_link( '/how-it-works/' ),
				'pills' => "No Water\nNo Chemicals\nClean & Green", 'bg' => ar_demo_img( 'hero-blast' ),
				'cards' => array(
					array( 'label' => 'Payload per van', 'value' => 900, 'suffix' => ' lb', 'note' => 'of dry ice · 3 insulated bins', 'tone' => 'glacier' ),
					array( 'label' => 'Secondary waste', 'value' => 0, 'suffix' => '%', 'note' => 'pellets sublimate to gas', 'tone' => 'mint' ),
					array( 'label' => 'Industries served', 'value' => 7, 'suffix' => '', 'note' => 'from hangars to marinas', 'tone' => 'glacier' ),
				),
			) ),
			ar_demo_w( 'ar_icon_boxes', array( 'layout' => 'bar', 'cols' => '4', 'theme' => 'dark', 'pad' => 'sm', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-certificate' ), 'title' => 'FDA-approved', 'text' => 'for food processing equipment' ),
				array( 'icon' => ar_demo_icon( 'fas fa-recycle' ), 'title' => 'Zero waste', 'text' => 'no secondary waste created' ),
				array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => '900 lbs', 'text' => 'of dry ice on every van' ),
				array( 'icon' => ar_demo_icon( 'fas fa-snowflake' ), 'title' => '100% mobile', 'text' => 'we come to your site' ),
			) ) ),
			ar_demo_w( 'ar_marquee', array( 'items' => "Aerospace & Defense\nFood Processing & Equipment\nManufacturing & Machinery\nUtilities & Power Plants\nAutomotive Restoration\nBoats & Marinas\nFire Restoration", 'theme' => 'void', 'pad' => 'sm' ) ),
			ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'Who we are', 'Use Arctic Resto for that {{safe, clean feeling}}', '', 'left' ), array(
				'body' => '<p>Arctic Resto is an eco-friendly mobile dry ice cleaning service which utilizes fully outfitted Mercedes Sprinter vans and a franchise owner business model. We focus on delivering professional results and minimizing downtime by using industrial-grade equipment and experienced technicians.</p><p>We serve industrial and commercial customers across the Northeast USA with plans to expand shortly into the Southeast. Dry ice cleaning works on steel, metal, cement, stone, wood, plastic and more — with adjustable pressure and pellet sizes for harsh or delicate applications.</p>',
				'image' => ar_demo_img( 'van' ), 'badge_t' => 'Fully outfitted', 'badge_s' => 'Mercedes Sprinter vans',
				'stats' => array( array( 'num' => 900, 'suffix' => ' lb', 'label' => 'Dry ice per van' ), array( 'num' => 7, 'suffix' => '', 'label' => 'Industries served' ), array( 'num' => 0, 'suffix' => '', 'label' => 'Gallons of water used' ) ),
				'b1_t' => 'More about us', 'b1_u' => ar_demo_link( '/about/' ), 'theme' => 'light',
			) ) ),
			ar_demo_w( 'ar_answer', array(
				'question' => 'What is mobile dry ice cleaning?',
				'answer' => 'Mobile dry ice cleaning uses solid CO₂ pellets and compressed air to lift dirt, grease, soot and coatings from surfaces — on your site, from a fully outfitted van. The pellets vanish as gas, so there is no water, no chemicals and no secondary waste. Arctic Resto serves industrial, commercial and residential customers across New Jersey and Connecticut.',
				'updated' => 'yes', 'facts_title' => 'Arctic Resto at a glance',
				'facts' => array(
					array( 'label' => 'Method', 'value' => 'Dry ice (solid CO₂) blasting with compressed air' ),
					array( 'label' => 'Delivery', 'value' => 'Mobile — Mercedes Sprinter vans carrying 900 lbs of dry ice' ),
					array( 'label' => 'Industries', 'value' => 'Aerospace & Defense, Food Processing, Manufacturing, Utilities & Power, Automotive Restoration, Boats & Marinas, Fire Restoration' ),
					array( 'label' => 'Service area', 'value' => 'New Jersey and Connecticut' ),
					array( 'label' => 'Environment', 'value' => 'No water, no chemicals, no secondary waste' ),
					array( 'label' => 'Franchise', 'value' => "Yes — the industry's first mobile dry ice cleaning franchise" ),
				),
				'b1_t' => 'Get a free quote', 'b1_u' => ar_demo_link( '/estimator/' ), 'b2_t' => 'How it works', 'b2_u' => ar_demo_link( '/how-it-works/' ),
				'theme' => 'frost', 'pad' => 'md',
			) ),
			ar_demo_w( 'ar_services', array_merge( ar_demo_h( 'Our dry ice cleaning services', 'One process. {{Seven demanding industries.}}', 'Versatile dry ice cleaning for residential, commercial and industrial needs — no water, no chemicals, just clean.' ), array( 'layout' => 'bento', 'count' => -1, 'theme' => 'frost' ) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'How it works', 'A simple process. {{A seamless experience.}}', 'From first call to a clean, dry surface — we handle everything on-site.' ), array( 'layout' => 'process', 'cols' => '4', 'theme' => 'void', 'howto' => 'yes', 'items' => ar_demo_process_items() ) ) ),
			ar_demo_w( 'ar_before_after', array_merge( ar_demo_h( 'Results you can see', 'Drag to reveal the {{clean}}', 'Soot, grease, rust and buildup lifted from the surface — without water, chemicals or abrasion.' ), array( 'items' => array(
				array( 'label' => 'Engine restoration', 'after' => ar_demo_img( 'auto-hero' ) ),
				array( 'label' => 'Industrial machinery', 'after' => ar_demo_img( 'worker' ) ),
				array( 'label' => 'Marine engine & hull', 'after' => ar_demo_img( 'boat-repair' ) ),
			), 'theme' => 'light' ) ) ),
			ar_demo_w( 'ar_compare', array_merge( ar_demo_h( 'Why choose Arctic Resto?', 'Cleaner than traditional cleaning. {{Kinder to your assets.}}', 'Does dry ice cleaning create a mess? No. It produces zero secondary waste — only the removed dirt or grime remains.', 'left' ), array( 'items' => ar_demo_compare(), 'theme' => 'dark' ) ) ),
			ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'Franchise opportunities', "The industry's first & only {{mobile dry ice cleaning franchise}}", '', 'left' ), array(
				'body' => '<p>A “business-in-a-box” franchise where you own your van and equipment 100%. Get trained and begin working right away with our easy business model.</p>',
				'checks' => implode( "\n", array_slice( $features, 0, 6 ) ), 'image' => ar_demo_img( 'pellets' ), 'reverse' => 'yes',
				'b1_t' => 'Explore the opportunity', 'b1_u' => ar_demo_link( '/franchise/' ), 'b2_t' => 'View territories', 'b2_u' => ar_demo_link( '/territories/' ), 'theme' => 'gradient',
			) ) ),
			ar_demo_w( 'ar_testimonials', array_merge( ar_demo_h( 'Client stories', "Trusted by teams who can't afford {{downtime}}" ), array( 'count' => 6, 'theme' => 'void' ) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Territories', 'Serving New Jersey & Connecticut. {{Growing fast.}}' ), array( 'layout' => 'cards', 'cols' => '4', 'theme' => 'frost', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-map-marker-alt' ), 'title' => 'Connecticut', 'text' => 'Serving now — home base for our first corporate van.', 'link' => ar_demo_link( '/territories/' ) ),
				array( 'icon' => ar_demo_icon( 'fas fa-map-marker-alt' ), 'title' => 'New Jersey', 'text' => 'Serving now — industrial and commercial customers.', 'link' => ar_demo_link( '/territories/' ) ),
				array( 'icon' => ar_demo_icon( 'fas fa-map-marker-alt' ), 'title' => 'Massachusetts', 'text' => 'Franchise territories opening.', 'link' => ar_demo_link( '/territories/' ) ),
				array( 'icon' => ar_demo_icon( 'fas fa-map-marker-alt' ), 'title' => 'Southeast USA', 'text' => 'Planned expansion — register your interest.', 'link' => ar_demo_link( '/territories/' ) ),
			) ) ) ),
			ar_demo_w( 'ar_posts', array_merge( ar_demo_h( 'Insights', 'Learn what {{dry ice}} can do' ), array( 'count' => 3, 'more_t' => 'View all articles', 'more_u' => ar_demo_link( '/blog/' ), 'theme' => 'light' ) ) ),
			ar_demo_w( 'ar_faq', array_merge( ar_demo_h( 'Got questions?', "We've got {{answers}}" ), array( 'items' => ar_demo_faq_items( array( 1, 4, 3, 7, 10 ) ), 'theme' => 'frost' ) ) ),
			ar_demo_cta( 'Ready for that safe, clean feeling?' ),
		),
	);

	/* ---------------- ABOUT ---------------- */
	$pages['about'] = array(
		'title'   => 'About Us',
		'excerpt' => 'Arctic Resto is an eco-friendly mobile dry ice cleaning service using fully outfitted Mercedes Sprinter vans and a franchise owner business model.',
		'els'     => array(
			ar_demo_hero( 'About Arctic Resto', 'Eco-friendly cleaning, {{delivered to your door.}}', 'An eco-friendly mobile dry ice cleaning service built on fully outfitted Mercedes Sprinter vans and a franchise owner business model.', 'hero-blast' ),
			ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'Who we are', 'Professional results. {{Minimal downtime.}}', '', 'left' ), array(
				'body' => '<p>We focus on delivering professional results and minimizing downtime by using industrial-grade equipment and experienced technicians. We serve industrial and commercial customers across the Northeast USA with plans to expand shortly into the Southeast.</p><p>Arctic Resto launched in early 2024 with a bold approach: build the franchise framework first and scale from day one. The first corporate van was custom-engineered with dedicated dry ice bins, a mounted compressor system and proper ventilation — carrying 900 lbs of dry ice for maximum efficiency on-site.</p>',
				'quote' => "This is a service people haven't really seen franchised before. We're offering entrepreneurs a chance to bring an emerging, sustainable service to their communities — and do it quickly.", 'quote_by' => 'Joe Pinto, Founder',
				'image' => ar_demo_img( 'van' ), 'badge_t' => '900 lb', 'badge_s' => 'dry ice capacity per van', 'reverse' => 'yes', 'theme' => 'light',
			) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'What we stand for', 'Principles behind {{every van}}' ), array( 'layout' => 'cards', 'cols' => '4', 'theme' => 'void', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-leaf' ), 'title' => 'Eco-friendly first', 'text' => 'Recycled CO₂, zero chemicals, zero water. Every job is the cleaner option for the environment.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'Fully mobile', 'text' => 'Mercedes Sprinter vans with industrial-grade blasting systems come to your facility.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-shield-alt' ), 'title' => 'Precision matters', 'text' => 'Adjustable pressure and pellet size so we clean delicate chrome or industrial steel equally well.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-award' ), 'title' => 'Franchise-grade standards', 'text' => 'Consistent training, SOPs and quality control — the same results, van to van.' ),
			) ) ) ),
			ar_demo_w( 'ar_timeline', array_merge( ar_demo_h( 'Our journey', 'From first van to {{a growing network}}' ), array( 'theme' => 'frost', 'items' => array(
				array( 'year' => '2024', 'title' => 'Launch', 'text' => 'Arctic Resto launches in Connecticut with a franchise framework built from day one.' ),
				array( 'year' => '2024', 'title' => 'First van on the road', 'text' => 'The first corporate Sprinter is engineered, fabricated and performing jobs weekly.' ),
				array( 'year' => '2025', 'title' => 'Franchise registered', 'text' => 'Franchise documents completed and registered, opening the first territories.' ),
				array( 'year' => 'Now', 'title' => 'Expanding in NJ & CT', 'text' => 'Serving industrial and commercial customers across New Jersey and Connecticut.' ),
				array( 'year' => 'Next', 'title' => 'MA & the Southeast', 'text' => 'New franchise territories in Massachusetts and planned Southeast expansion.' ),
			) ) ) ),
			ar_demo_w( 'ar_team', array_merge( ar_demo_h( 'The team', 'People behind {{the pellets}}', 'Demo team profiles — replace with your real team and photos.' ), array( 'theme' => 'light', 'items' => array(
				array( 'name' => 'Joe Pinto', 'role' => 'Founder' ),
				array( 'name' => 'Lead Technician', 'role' => 'Field Operations' ),
				array( 'name' => 'Franchise Director', 'role' => 'Franchise Development' ),
				array( 'name' => 'Customer Success', 'role' => 'Call Center' ),
			) ) ) ),
			ar_demo_cta(),
		),
	);

	/* ---------------- SERVICES ---------------- */
	$pages['services'] = array(
		'title'   => 'Services',
		'excerpt' => 'Versatile dry ice cleaning for aerospace, food processing, manufacturing, power plants, automotive restoration, boats & marinas and fire restoration.',
		'els'     => array(
			ar_demo_hero( 'Our dry ice cleaning services', 'Versatile cleaning for {{demanding industries.}}', 'Versatile dry ice cleaning for residential, commercial and industrial needs — no water, no chemicals, just clean.', 'hero-blast' ),
			ar_demo_w( 'ar_services', array( 'layout' => 'bento', 'count' => -1, 'theme' => 'frost', 'pad' => 'md' ) ),
			ar_demo_w( 'ar_services', array_merge( ar_demo_h( 'Service overview', 'What each service {{delivers}}' ), array( 'layout' => 'alternating', 'count' => -1, 'theme' => 'light' ) ) ),
			ar_demo_w( 'ar_marquee', array( 'items' => "Steel\nMetal\nCement\nStone\nWood\nPlastic\nBrick\nAluminum\nComposites\nFabric", 'theme' => 'dark', 'pad' => 'sm' ) ),
			ar_demo_cta(),
		),
	);

	/* ---------------- HOW IT WORKS ---------------- */
	$pages['how-it-works'] = array(
		'title'   => 'How It Works',
		'excerpt' => 'Dry ice cleaning uses solid CO₂ pellets accelerated by compressed air. The pellets vanish on contact, leaving no water, chemicals or residue.',
		'els'     => array(
			ar_demo_hero( 'How it works', 'The science of {{safe, clean.}}', 'Dry ice cleaning uses solid CO₂ pellets accelerated by compressed air. The pellets vanish on contact, leaving no water, chemicals or residue.', 'pellets' ),
			ar_demo_w( 'ar_science', array_merge( ar_demo_h( 'The science', 'Three forces. {{One clean surface.}}', '', 'left' ), array( 'theme' => 'light', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-bolt' ), 'title' => 'Kinetic energy', 'tag' => 'Impact', 'text' => 'Pellets strike the contaminant at high velocity, dislodging loose material.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-thermometer-half' ), 'title' => 'Thermal shock', 'tag' => '−109°F', 'text' => 'The extreme cold embrittles coatings and buildup so they crack and lift.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-wind' ), 'title' => 'Sublimation', 'tag' => '800× gas', 'text' => 'Pellets expand roughly 800× into gas, lifting contaminants cleanly from the surface.' ),
			) ) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Our process', 'From call to {{clean}} in four steps' ), array( 'layout' => 'process', 'cols' => '4', 'theme' => 'void', 'howto' => 'yes', 'items' => ar_demo_process_items() ) ) ),
			ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'The equipment', 'A blasting facility {{on wheels}}', 'Our first van was custom-engineered for safe dry ice storage and high-powered on-site cleaning.', 'left' ), array(
				'checks' => "900 lbs of dry ice across three insulated bins\nMounted industrial compressor system\nProper ventilation for operators and sites\nAdjustable pressure and pellet size", 'image' => ar_demo_img( 'van' ), 'reverse' => 'yes', 'badge_t' => 'Mercedes Sprinter', 'badge_s' => 'Fully outfitted', 'theme' => 'light',
			) ) ),
			ar_demo_w( 'ar_compare', array_merge( ar_demo_h( 'Compare', 'Dry ice vs {{traditional methods}}', '', 'left' ), array( 'items' => ar_demo_compare(), 'theme' => 'dark' ) ) ),
			ar_demo_w( 'ar_faq', array_merge( ar_demo_h( 'FAQ', 'Common {{questions}}' ), array( 'items' => ar_demo_faq_items( array( 0, 1, 2, 3, 4, 5 ) ), 'theme' => 'frost' ) ) ),
			ar_demo_cta(),
		),
	);

	/* ---------------- FRANCHISE ---------------- */
	$pages['franchise'] = array(
		'title'   => 'Franchise Opportunities',
		'excerpt' => 'The industry’s first and only mobile dry ice cleaning franchise. Own your van and equipment 100% with training, marketing and technology support.',
		'els'     => array(
			ar_demo_hero( 'Franchising re-imagined', "The industry's first & only {{mobile dry ice cleaning franchise.}}", 'Start your own Mobile Dry Ice Cleaning Franchise with a fully equipped van and complete support. Get trained and begin working right away with our easy business model.', 'van', 'Apply in the franchise portal', '{portal}', 'Franchise owner login', '{portal-login}' ),
			ar_demo_w( 'ar_answer', array(
				'question' => 'What is the Arctic Resto mobile dry ice cleaning franchise?',
				'answer' => "Arctic Resto is the industry's first and only mobile dry ice cleaning franchise. It is a business-in-a-box model: franchisees own their van and equipment 100%, are trained to run jobs immediately, and receive a call center, done-for-you marketing, lead generation and a proprietary technology platform. Prime territories begin in Connecticut, expanding to Massachusetts and New Jersey.",
				'updated' => 'yes', 'note' => 'Franchise offerings are made only by disclosure document.', 'facts_title' => 'Franchise at a glance',
				'facts' => array(
					array( 'label' => 'Model', 'value' => 'Business-in-a-box mobile franchise' ),
					array( 'label' => 'Ownership', 'value' => 'Franchisee owns the van and equipment 100%' ),
					array( 'label' => 'Financing', 'value' => 'Introductions to financing options are available' ),
					array( 'label' => 'Training', 'value' => 'Extensive training and corporate support; ready for first jobs at the close of training' ),
					array( 'label' => 'Support', 'value' => 'Centralized call center, online marketing, lead generation, technology platform' ),
					array( 'label' => 'Territories', 'value' => 'Beginning in CT; expanding to MA and NJ' ),
				),
				'b1_t' => 'Apply in the franchise portal', 'b1_u' => ar_demo_link( '{portal}' ), 'b2_t' => 'Franchise owner login', 'b2_u' => ar_demo_link( '{portal-login}' ),
				'theme' => 'frost', 'pad' => 'md',
			) ),
			ar_demo_w( 'ar_split', array_merge( ar_demo_h( 'Business in a box', 'Own your van & equipment {{100%}}', 'Arctic Resto offers a “business-in-a-box” franchise where franchisees own their van and equipment outright. Introductions to financing options are available.', 'left' ), array(
				'checks' => implode( "\n", $features ), 'image' => ar_demo_img( 'van' ), 'badge_t' => '100%', 'badge_s' => 'van & equipment ownership', 'theme' => 'light',
			) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Path to ownership', 'From financing to {{first jobs}}', "Once financing is secured, the van is built, training is scheduled, and you're ready for your first jobs immediately at the close of training." ), array( 'layout' => 'process', 'cols' => '4', 'theme' => 'void', 'howto' => 'yes', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-hand-holding-usd' ), 'title' => 'Secure financing', 'text' => 'Introductions to financing options are available so you can own your van and equipment 100%.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'Your van is built', 'text' => 'A fully outfitted Mercedes Sprinter with compressor, insulated dry ice bins and ventilation.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-graduation-cap' ), 'title' => 'Get trained', 'text' => 'Hands-on training covering equipment, safety, sales and operations.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-rocket' ), 'title' => 'First jobs, day one', 'text' => 'You are ready for your first jobs immediately at the close of training.' ),
			) ) ) ),
			ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Franchisor support', 'You run the van. {{We run the back office.}}', 'The franchisor provides services and benefits that let you focus on the work.' ), array( 'layout' => 'cards', 'cols' => '4', 'theme' => 'frost', 'items' => array(
				array( 'icon' => ar_demo_icon( 'fas fa-headset' ), 'title' => 'Centralized call center', 'text' => 'Customer service and appointment booking handled for you.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-bullhorn' ), 'title' => 'Online marketing services', 'text' => 'Websites, local SEO, ads and social — done for you.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-graduation-cap' ), 'title' => 'Continued training', 'text' => 'An always-on library of resources as your business grows.' ),
				array( 'icon' => ar_demo_icon( 'fas fa-chart-line' ), 'title' => 'Custom tech platform', 'text' => 'Customer tracking, email campaigns, invoicing and much more.' ),
			) ) ) ),
			ar_demo_w( 'ar_services', array_merge( ar_demo_h( 'Multiple revenue streams', 'One van. {{Seven markets.}}', 'Residential, commercial, automotive, boat and marine, restaurants, industrial and fire restoration.' ), array( 'layout' => 'grid', 'count' => -1, 'theme' => 'light' ) ) ),
			ar_demo_w( 'ar_calculator', array_merge( ar_demo_h( 'Explore the model', 'Play with the {{numbers}}', 'Adjust the sliders to see how job volume and ticket size could scale a single van.' ), array( 'theme' => 'dark' ) ) ),
			ar_demo_w( 'ar_faq', array_merge( ar_demo_h( 'Franchise FAQ', 'Answers for {{future owners}}' ), array( 'theme' => 'frost', 'items' => array(
				array( 'cat' => 'General', 'q' => 'Do I own the van and equipment?', 'a' => 'Yes. Arctic Resto is a “business-in-a-box” franchise where franchisees own their van and equipment 100%. Introductions to financing options are available.' ),
				array( 'cat' => 'General', 'q' => 'Do I need dry ice cleaning experience?', 'a' => 'No. Training covers equipment operation, safety, sales and operations, so you are ready for your first jobs immediately at the close of training.' ),
				array( 'cat' => 'General', 'q' => 'Who handles marketing and bookings?', 'a' => 'The franchisor provides a centralized call center for customer service and appointment booking, plus online marketing and lead generation services.' ),
				array( 'cat' => 'General', 'q' => 'Which territories are available?', 'a' => 'Prime territories are available now beginning in Connecticut, with New Jersey and Massachusetts opening soon and Southeast expansion planned.' ),
				array( 'cat' => 'General', 'q' => 'What revenue streams are there?', 'a' => 'Residential, commercial, automotive, boat and marine, restaurants, industrial and fire restoration — multiple revenue streams from a single van.' ),
			) ) ) ),
			ar_demo_w( 'ar_portal', array_merge( ar_demo_h( 'Franchise portal', 'Apply and manage your franchise in the {{portal}}', 'Start your application, review documents and track your onboarding in our franchise portal. Already an owner? Sign in to your dashboard.', 'left' ), array(
				'features' => "Start or resume your application\nReview franchise documents securely\nTrack training and van build progress\nOwner dashboard, tools and resources",
				'card_t' => 'Arctic Resto Franchise Portal', 'card_s' => 'Secure access for prospective and current franchise owners.',
				'b1_t' => 'Apply in the franchise portal', 'b1_u' => ar_demo_link( '' ), 'b2_t' => 'Franchise owner login', 'b2_u' => ar_demo_link( '' ),
				'note' => 'Franchise offerings are made only by disclosure document.', 'anchor' => 'apply', 'theme' => 'dark',
			) ) ),
		),
	);

	/* ---------------- TERRITORIES ---------------- */
	$pages['territories'] = array(
		'title'   => 'Territories',
		'excerpt' => 'Mobile dry ice cleaning across New Jersey and Connecticut, with franchise territories opening in Massachusetts and a Southeast expansion planned.',
		'els'     => array(
			ar_demo_hero( 'Territories', 'Serving {{NJ & CT}} — and growing.', 'Mobile dry ice cleaning across New Jersey and Connecticut, with franchise territories opening in Massachusetts and a Southeast expansion planned.', 'hero-blast' ),
			ar_demo_w( 'ar_territories', array( 'b1_t' => 'Get a quote', 'b1_u' => ar_demo_link( '/estimator/' ), 'b2_t' => 'Claim territory', 'b2_u' => ar_demo_link( '{portal}' ), 'items' => ar_demo_territories(), 'theme' => 'void', 'pad' => 'lg' ) ),
			ar_demo_cta( "Don't see your area? Ask us.", 'Franchise territories are being released in phases. Register your interest and we will let you know as new areas open.' ),
		),
	);

	/* ---------------- GALLERY ---------------- */
	$gal = array(
		array( 'Aircraft in maintenance hangar', 'Aerospace & Defense', 'aerospace' ), array( 'Vintage propeller aircraft', 'Aerospace & Defense', 'aerospace-hero' ),
		array( 'Bottling line sanitation', 'Food Processing', 'food' ), array( 'Production line cleaning', 'Food Processing', 'food-hero' ),
		array( 'Factory floor machinery', 'Manufacturing', 'manufacturing' ), array( 'Conveyor system maintenance', 'Manufacturing', 'manufacturing-hero' ),
		array( 'Cooling tower facility', 'Utilities & Power', 'power' ), array( 'Power plant equipment', 'Utilities & Power', 'power-hero' ),
		array( 'Classic coupe engine bay', 'Automotive', 'auto' ), array( 'Vintage engine detail', 'Automotive', 'auto-hero' ),
		array( 'Marina hull cleaning', 'Boats & Marinas', 'marine' ), array( 'Sailboats at the harbor', 'Boats & Marinas', 'marine-hero' ),
		array( 'Fire-damaged interior', 'Fire Restoration', 'fire' ), array( 'Charred structural timber', 'Fire Restoration', 'fire-hero' ),
	);
	$gitems = array();
	foreach ( $gal as $g ) {
		$gitems[] = array( 'title' => $g[0], 'cat' => $g[1], 'image' => ar_demo_img( $g[2] ) );
	}
	$pages['gallery'] = array(
		'title'   => 'Gallery',
		'excerpt' => 'Browse demo project photography across all seven industries and drag the sliders to reveal the clean.',
		'els'     => array(
			ar_demo_hero( 'Project gallery', 'Results that {{speak for themselves.}}', 'Browse demo project photography across all seven industries and drag the sliders to reveal the clean.', 'hero-blast' ),
			ar_demo_w( 'ar_before_after', array_merge( ar_demo_h( 'Before & after', 'Drag to {{reveal}}' ), array( 'items' => array(
				array( 'label' => 'Engine restoration', 'after' => ar_demo_img( 'auto-hero' ) ),
				array( 'label' => 'Industrial machinery', 'after' => ar_demo_img( 'worker' ) ),
				array( 'label' => 'Marine engine & hull', 'after' => ar_demo_img( 'boat-repair' ) ),
			), 'theme' => 'dark' ) ) ),
			ar_demo_w( 'ar_gallery', array( 'items' => $gitems, 'theme' => 'frost' ) ),
			ar_demo_cta(),
		),
	);

	/* ---------------- BLOG ---------------- */
	$pages['blog'] = array(
		'title'   => 'Blog',
		'excerpt' => 'Guides, case notes and industry insights on eco-friendly dry ice cleaning and restoration.',
		'els'     => array(
			ar_demo_hero( 'Blog & insights', 'Dry ice cleaning {{knowledge hub.}}', 'Guides, case notes and industry insights on eco-friendly cleaning and restoration.', 'hero-blast' ),
			ar_demo_w( 'ar_posts', array( 'count' => 7, 'filters' => 'yes', 'featured' => 'yes', 'theme' => 'light' ) ),
			ar_demo_cta(),
		),
	);

	/* ---------------- FAQ ---------------- */
	$pages['faq'] = array(
		'title'   => 'FAQ',
		'excerpt' => 'Everything you need to know about dry ice cleaning, safety, restoration and franchising.',
		'els'     => array(
			ar_demo_hero( 'FAQ', "Got questions? {{We've got answers.}}", 'Everything you need to know about dry ice cleaning, safety, restoration and franchising.', 'hero-blast' ),
			ar_demo_w( 'ar_faq', array( 'search' => 'yes', 'filters' => 'yes', 'items' => ar_demo_faq_items(), 'theme' => 'frost' ) ),
			ar_demo_cta( 'Still have a question?', 'Call us or send a message — a real person will respond within one business day.' ),
		),
	);

	/* ---------------- ESTIMATOR ---------------- */
	$pages['estimator'] = array(
		'title'   => 'Instant Estimator',
		'excerpt' => 'Answer three quick questions for an illustrative dry ice cleaning estimate. Final pricing follows a free assessment.',
		'els'     => array(
			ar_demo_hero( 'Instant estimator', 'Get a ballpark in {{60 seconds.}}', 'Answer three quick questions for an illustrative estimate. Final pricing follows a free assessment.', 'hero-blast' ),
			ar_demo_w( 'ar_estimator', array( 'rate' => 275, 'small' => 3, 'medium' => 6, 'large' => 12, 'm_mod' => 1.35, 'm_hvy' => 1.8, 'theme' => 'frost' ) ),
		),
	);

	/* ---------------- CONTACT ---------------- */
	$pages['contact'] = array(
		'title'   => 'Contact',
		'excerpt' => 'Quotes, questions or franchise inquiries — the Arctic Resto team responds within one business day.',
		'els'     => array(
			ar_demo_hero( 'Get in touch', "Let's talk about {{your project.}}", 'Quotes, questions or franchise inquiries — our team responds within one business day.', 'hero-blast' ),
			ar_demo_w( 'ar_form', array_merge( ar_demo_h( 'Get in touch', 'Tell us about your {{project}}', 'Tell us about your surface, contaminant and timeline. We will come back with a clear recommendation and a no-obligation quote.', 'left' ), array( 'type' => 'contact', 'aside' => 'yes', 'form_t' => 'Send us a message', 'btn' => 'Send message', 'theme' => 'light' ) ) ),
			array(
				'id'       => ar_demo_uid(),
				'elType'   => 'container',
				'isInner'  => false,
				'settings' => array( 'content_width' => 'full', 'padding' => array( 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ), 'css_classes' => 'ar-con' ),
				'elements' => array(
					array( 'id' => ar_demo_uid(), 'elType' => 'widget', 'isInner' => false, 'widgetType' => 'google_maps', 'settings' => array( 'address' => 'Connecticut, USA', 'zoom' => array( 'unit' => 'px', 'size' => 8 ), 'height' => array( 'unit' => 'px', 'size' => 420 ) ), 'elements' => array() ),
				),
			),
		),
	);

	/* ---------------- PRIVACY ---------------- */
	$pages['privacy-policy'] = array(
		'title'   => 'Privacy Policy',
		'excerpt' => 'How Arctic Resto collects, uses and protects your information.',
		'els'     => array(
			ar_demo_hero( 'Legal', 'Privacy {{Policy}}', 'Sample policy text — have your attorney review and replace before launch.', 'hero-blast' ),
			array(
				'id'       => ar_demo_uid(),
				'elType'   => 'container',
				'isInner'  => false,
				'settings' => array( 'content_width' => 'boxed', 'boxed_width' => array( 'unit' => 'px', 'size' => 820 ), 'padding' => array( 'unit' => 'px', 'top' => '80', 'right' => '24', 'bottom' => '80', 'left' => '24', 'isLinked' => false ) ),
				'elements' => array(
					array( 'id' => ar_demo_uid(), 'elType' => 'widget', 'isInner' => false, 'widgetType' => 'text-editor', 'settings' => array( 'editor' => '<h2>Information we collect</h2><p>When you contact us, request a quote or submit a franchise inquiry, we collect the details you provide such as your name, email, phone number and project information.</p><h2>How we use it</h2><p>We use your information to respond to your request, prepare quotes and improve our services. We do not sell your personal information.</p><h2>Cookies & analytics</h2><p>This site may use cookies and analytics tools to understand how visitors use it. You can control cookies through your browser settings.</p><h2>Contact</h2><p>Questions about this policy? Email <a href="mailto:info@arcticresto.com">info@arcticresto.com</a>.</p>' ), 'elements' => array() ),
				),
			),
		),
	);

	// Dedicated builders (they replace the simpler Franchise / Territories definitions above
	// and add one child page per territory).
	$pages['franchise'] = ar_demo_franchise_page();
	$pages              = array_merge( $pages, ar_demo_territory_pages() );

	return $pages;
}
