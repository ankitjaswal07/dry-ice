<?php
/**
 * Extended, answer-first service content used by the demo importer.
 * One entry per service: SEO title/description, a direct answer, quick facts,
 * problems solved, a long-form guide, applications, a comparison, process steps and FAQs.
 * This file only holds demo data; every value ends up as editable Elementor widget content.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_demo_service_extra( $slug ) {
	static $all = null;
	if ( null === $all ) {
		$all = ar_demo_service_extra_data();
	}
	return isset( $all[ $slug ] ) ? $all[ $slug ] : null;
}

/** SEO titles for the standard pages (services carry their own). */
function ar_demo_seo_titles() {
	return array(
		'home'           => 'Mobile Dry Ice Cleaning NJ & CT | No Water, No Chemicals | Arctic Resto',
		'about'          => 'About Arctic Resto | Eco-Friendly Mobile Dry Ice Cleaning',
		'services'       => 'Dry Ice Cleaning Services | Aerospace, Food, Industrial, Marine & Fire | Arctic Resto',
		'how-it-works'   => 'How Dry Ice Cleaning Works | Process, Safety & Benefits | Arctic Resto',
		'franchise'      => 'Mobile Dry Ice Cleaning Franchise | Own Your Van & Equipment | Arctic Resto',
		'territories'    => 'Service Areas & Franchise Territories | NJ, CT, MA | Arctic Resto',
		'gallery'        => 'Dry Ice Cleaning Project Gallery | Before & After | Arctic Resto',
		'blog'           => 'Dry Ice Cleaning Blog & Guides | Arctic Resto',
		'faq'            => 'Dry Ice Cleaning FAQ | Safety, Surfaces & Restoration | Arctic Resto',
		'estimator'      => 'Instant Dry Ice Cleaning Estimate | Arctic Resto',
		'contact'        => 'Contact Arctic Resto | Free Dry Ice Cleaning Quote NJ & CT',
		'privacy-policy' => 'Privacy Policy | Arctic Resto',
	);
}

/**
 * Full service page layout. Falls back to the basic layout when no extended content exists.
 */
function ar_demo_service_elements( $s ) {
	$x = ar_demo_service_extra( $s['slug'] );
	if ( ! $x ) {
		return ar_demo_service_elements_basic( $s );
	}

	$facts = array(
		array( 'label' => 'Best for', 'value' => $x['best'] ),
		array( 'label' => 'Removes', 'value' => $x['removes'] ),
		array( 'label' => 'Surfaces', 'value' => $x['surfaces'] ),
		array( 'label' => 'Water & chemicals', 'value' => 'None — completely dry process' ),
		array( 'label' => 'Secondary waste', 'value' => 'None — pellets sublimate to gas' ),
		array( 'label' => 'Service', 'value' => 'On-site across NJ & CT in a fully equipped Sprinter van' ),
	);

	$caps = array();
	foreach ( $s['body'] as $b ) {
		$caps[] = array( 'icon' => ar_demo_icon( $s['icon'] ), 'title' => $b[0], 'text' => $b[1] );
	}
	$problems = array();
	foreach ( $x['problems'] as $p ) {
		$problems[] = array( 'icon' => ar_demo_icon( 'fas fa-check-circle' ), 'title' => $p[0], 'text' => $p[1] );
	}
	$steps = array();
	foreach ( $x['steps'] as $st ) {
		$steps[] = array( 'icon' => ar_demo_icon( 'fas fa-check-circle' ), 'title' => $st[0], 'text' => $st[1] );
	}
	$rows = array();
	foreach ( $x['compare'] as $r ) {
		$rows[] = array( 'title' => $r[0], 'a' => $r[1], 'b' => $r[2] );
	}
	$faq = array();
	foreach ( $x['faqs'] as $f ) {
		$faq[] = array( 'q' => $f[0], 'a' => $f[1], 'cat' => 'General' );
	}

	return array(
		ar_demo_hero( $s['tagline'], $s['title'] . ' {{dry ice cleaning}}', $s['blurb'], $s['hero'], 'Get instant quote', '/estimator/', 'All services', '/services/' ),
		ar_demo_service_nav(),
		ar_demo_w(
			'ar_icon_boxes',
			array(
				'layout' => 'bar',
				'cols'   => '4',
				'theme'  => 'dark',
				'pad'    => 'sm',
				'items'  => array(
					array( 'icon' => ar_demo_icon( 'fas fa-tint' ), 'title' => 'No water', 'text' => 'Completely dry' ),
					array( 'icon' => ar_demo_icon( 'fas fa-flask' ), 'title' => 'No chemicals', 'text' => 'Recycled CO₂' ),
					array( 'icon' => ar_demo_icon( 'fas fa-recycle' ), 'title' => 'No waste', 'text' => 'Pellets sublimate' ),
					array( 'icon' => ar_demo_icon( 'fas fa-truck' ), 'title' => 'On-site', 'text' => 'Mobile Sprinter van' ),
				),
			)
		),
		ar_demo_w(
			'ar_answer',
			array(
				'question'    => $x['question'],
				'answer'      => $x['intro'],
				'updated'     => 'yes',
				'facts_title' => 'Quick facts: ' . $s['title'],
				'anchor'      => 'overview',
				'facts'       => $facts,
				'b1_t'        => 'Get a free quote',
				'b1_u'        => ar_demo_link( '/estimator/' ),
				'b2_t'        => 'Talk to a specialist',
				'b2_u'        => ar_demo_link( '/contact/' ),
				'theme'       => 'frost',
				'pad'         => 'md',
			)
		),
		ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'What we do', 'Capabilities for {{' . $s['title'] . '}}' ), array( 'layout' => 'numbered', 'cols' => '3', 'theme' => 'light', 'anchor' => 'what', 'items' => $caps ) ) ),
		ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Problems we solve', 'Why {{' . $s['title'] . '}} teams choose dry ice' ), array( 'layout' => 'cards', 'cols' => '4', 'theme' => 'frost', 'items' => $problems ) ) ),
		ar_demo_w(
			'ar_article',
			array_merge(
				ar_demo_h( 'Guide', $x['guide_title'], '', 'left' ),
				array(
					'anchor'     => 'guide',
					'body'       => $x['guide'],
					'aside_t'    => 'Common applications',
					'aside_list' => implode( "\n", $x['apps'] ),
					'b1_t'       => 'Get a free quote',
					'b1_u'       => ar_demo_link( '/estimator/' ),
					'theme'      => 'light',
				)
			)
		),
		ar_demo_w(
			'ar_compare',
			array_merge(
				ar_demo_h( 'Compare', 'Dry ice vs {{traditional methods}}', 'How dry ice cleaning compares for ' . strtolower( $s['title'] ) . '.', 'left' ),
				array(
					'anchor' => 'compare',
					'col_a' => 'Dry ice',
					'col_b' => 'Traditional methods',
					'pills' => '',
					'items' => $rows,
					'theme' => 'dark',
				)
			)
		),
		...ar_demo_service_more_elements( $s ),
		ar_demo_w( 'ar_before_after', array_merge( ar_demo_h( 'See the difference', 'Drag to reveal the {{clean}}' ), array( 'items' => array( array( 'label' => $s['title'], 'after' => ar_demo_img( $s['img'] ) ) ), 'theme' => 'void' ) ) ),
		ar_demo_w( 'ar_icon_boxes', array_merge( ar_demo_h( 'Process', 'How a {{' . $s['title'] . '}} job runs' ), array( 'layout' => 'process', 'cols' => '4', 'theme' => 'light', 'howto' => 'yes', 'anchor' => 'process', 'items' => $steps ) ) ),
		ar_demo_service_areas( $s ),
		ar_demo_w( 'ar_faq', array_merge( ar_demo_h( 'FAQ', 'Questions about {{' . $s['title'] . '}}' ), array( 'items' => $faq, 'anchor' => 'faq', 'theme' => 'frost' ) ) ),
		ar_demo_w( 'ar_services', array_merge( ar_demo_h( 'Related services', 'You may also {{need}}' ), array( 'layout' => 'grid', 'count' => 3, 'exclude' => 'yes', 'theme' => 'light' ) ) ),
		ar_demo_cta(),
	);
}

function ar_demo_service_extra_data() {
	return array(

		/* ------------------------------------------------------------ */
		'aerospace-defense' => array(
			'seo_title'   => 'Aerospace & Defense Dry Ice Cleaning | Mobile Service NJ & CT | Arctic Resto',
			'seo_desc'    => 'Mobile dry ice cleaning for aerospace and defense: tooling, engine components, ground support equipment and coatings cleaned with no water, media or chemical residue. Serving NJ & CT.',
			'question'    => 'How does dry ice cleaning work for aerospace and defense equipment?',
			'intro'       => 'Dry ice cleaning fires solid CO₂ pellets at a surface with compressed air. The pellets lift coatings, grease, carbon and release agents, then sublimate to gas — leaving no water, media or chemical residue. For aerospace and defense teams, that means tooling, parts and ground support equipment can be cleaned in place without foreign object debris or moisture.',
			'best'        => 'Tooling, molds, engine and turbine components, ground support equipment',
			'removes'     => 'Paint and coatings, grease, carbon, adhesives, sealants, release agents',
			'surfaces'    => 'Aluminum, titanium, stainless steel, composites',
			'problems'    => array(
				array( 'Residue and FOD risk', 'Abrasive media and solvents can leave particles or films behind. Dry ice sublimates on contact, so nothing remains to be found later in an assembly.' ),
				array( 'Tight tolerances', 'Aggressive methods can change a surface profile. Pressure and pellet size are set for the substrate, so finishes and dimensions are preserved.' ),
				array( 'Coating and adhesive buildup', 'Old paint, epoxy, sealant and adhesive can be lifted from tooling and fixtures without hand scraping or chemical strippers.' ),
				array( 'Moisture-sensitive components', 'No water means no drying time and no trapped moisture in fasteners, seams or electronics bays.' ),
			),
			'guide_title' => 'Dry ice cleaning in aerospace and defense environments',
			'guide'       => '<p>Hangars, machine shops and depots share one constraint: parts and tooling must stay clean, dry and unchanged. Dry ice blasting suits that constraint because the media disappears. There is no grit to capture, no rinse water to manage and no chemical to document.</p><h3>Where it is used</h3><p>Typical work includes removing release agents and carbon from composite tooling, lifting old coatings from fixtures, degreasing ground support equipment and cleaning components between inspections. Your engineers define what may be cleaned and which parameters apply; we adjust pressure, pellet size and nozzle to match the specification you provide.</p><h3>Working inside your rules</h3><p>We follow your site access, safety and quality procedures and confirm the cleaning plan before any blasting begins. For controlled or specification-driven work, the customer’s requirements always take priority over our defaults.</p>',
			'apps'        => array( 'Composite tooling and molds', 'Ground support equipment', 'Engine and turbine components', 'Fixtures and jigs', 'Panels and brackets before repaint', 'Hangar and machine-shop equipment' ),
			'compare'     => array(
				array( 'Foreign object debris', 'None — pellets sublimate', 'Grit or media can remain' ),
				array( 'Moisture', 'Dry process', 'Rinse water and drying time' ),
				array( 'Effect on surface', 'Non-abrasive, adjustable', 'Can etch or change profile' ),
				array( 'Chemical handling', 'None', 'Solvents and strippers to store and dispose of' ),
			),
			'steps'       => array(
				array( 'Scope & specification', 'We review the part, contaminant and your cleaning specification, then agree parameters and a test area.' ),
				array( 'Mobilize on-site', 'The Sprinter van arrives with dry ice, compressor and PPE; work zones and ventilation are set up.' ),
				array( 'Controlled cleaning', 'Pressure, pellet size and nozzle are tuned on a test area, then work proceeds section by section.' ),
				array( 'Inspect & hand over', 'You inspect the result. Only the dislodged contaminant remains to be vacuumed or swept.' ),
			),
			'faqs'        => array(
				array( 'Will dry ice damage aluminum or composite parts?', 'No. Dry ice is non-abrasive, and we tune pressure and pellet size so critical surface finishes and tolerances are preserved.' ),
				array( 'Is there any foreign object debris (FOD) risk?', 'Pellets sublimate into gas on contact, so there is no blasting media left behind to become FOD.' ),
				array( 'Can you follow our cleaning specification?', 'Yes. Share your specification and acceptance criteria before the job. We agree parameters and a test area with your engineers, and the customer’s requirements govern.' ),
				array( 'Can tooling be cleaned without removing it?', 'In most cases yes. Fixtures and tooling can be cleaned in place or in a designated area, which avoids disassembly and transport.' ),
				array( 'What contaminants can be removed?', 'Grease, carbon, adhesives, release agents, sealants and many coatings. Very hard or thick coatings may need multiple passes or a different method — we will tell you during the assessment.' ),
				array( 'Which areas do you serve?', 'We provide mobile service across New Jersey and Connecticut from fully equipped Sprinter vans.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'food-processing' => array(
			'seo_title'   => 'Food Processing Equipment Cleaning | Dry Ice, FDA-Approved | Arctic Resto NJ & CT',
			'seo_desc'    => 'Waterless dry ice cleaning for bakery ovens, conveyors, mixers and packaging lines. FDA-approved for food processing equipment, no chemicals, no secondary waste. Mobile service in NJ & CT.',
			'question'    => 'Is dry ice cleaning safe for food processing equipment?',
			'intro'       => 'Yes. Dry ice is FDA-approved for use on food processing equipment. Pellets lift grease, carbonized residue and product buildup from ovens, conveyors and mixers, then sublimate to gas. There is no wash-down water, no chemical residue and no secondary waste — so production lines can return to service quickly.',
			'best'        => 'Bakery ovens, conveyors, mixers, slicers, packaging lines, commercial kitchens',
			'removes'     => 'Grease, baked-on carbon, starch, sugar, protein and product buildup',
			'surfaces'    => 'Stainless steel, belts, plastics, welded frames',
			'problems'    => array(
				array( 'Water in the plant', 'Wash-down water spreads contamination, needs drying time and puts electrical equipment at risk. Dry ice adds none.' ),
				array( 'Baked-on carbon and sugar', 'Oven interiors and racks collect carbonized residue that scrubbing struggles to reach. Dry ice reaches crevices and lifts buildup in place.' ),
				array( 'Long changeovers', 'Teardown and drying stretch downtime. Cleaning in place between shifts returns lines to service sooner.' ),
				array( 'Chemical residue and paperwork', 'No detergents or solvents means nothing to rinse away and less chemical paperwork to manage.' ),
			),
			'guide_title' => 'Dry ice cleaning for bakeries, plants and commercial kitchens',
			'guide'       => '<p>Food operations need equipment that is clean without being wet. Dry ice cleaning is dry, non-toxic and leaves no media behind, which is why it is used on ovens, conveyor systems, mixers and packaging equipment.</p><h3>Cleaning in place, around your schedule</h3><p>Most work is planned for off-shifts, weekends or scheduled shutdowns. Equipment is cleaned where it stands, so there is little or no disassembly and no drying time before restart.</p><h3>Supporting your sanitation program</h3><p>Dry ice is a physical cleaning method, not a sanitizer. Many plants use it to remove heavy buildup and then follow with their own approved sanitation steps. We work with your quality team on scope, lockout requirements and any documentation you need.</p>',
			'apps'        => array( 'Bakery ovens, racks and pans', 'Conveyor belts and frames', 'Mixers and blenders', 'Slicers and packaging lines', 'Restaurant hoods and commercial kitchens', 'Fryers and cooking lines' ),
			'compare'     => array(
				array( 'Water use', 'None', 'Gallons of wash-down water' ),
				array( 'Chemical residue', 'None', 'Detergents and sanitizers to rinse' ),
				array( 'Drying time', 'None', 'Required before restart' ),
				array( 'Reach into crevices', 'Pellets reach tight areas', 'Brushes and sprays struggle' ),
			),
			'steps'       => array(
				array( 'Walk-through & scope', 'We review equipment, buildup type, lockout steps and your quality requirements.' ),
				array( 'Prepare the area', 'Product and packaging are cleared or covered, and safe work zones and ventilation are set.' ),
				array( 'Blast in place', 'Pellet size and pressure are set for the equipment, then buildup is lifted section by section.' ),
				array( 'Vacuum & release', 'Loosened residue is vacuumed and equipment is ready for your sanitation team with no drying wait.' ),
			),
			'faqs'        => array(
				array( 'Is dry ice safe for food-related areas?', 'Yes. Dry ice is FDA-approved for food processing equipment, making it ideal for restaurants, commercial kitchens and production plants.' ),
				array( 'Can you clean around a tight production schedule?', 'Yes. With no drying time and no teardown, we can clean during off-shifts and return equipment to service quickly.' ),
				array( 'Does dry ice sanitize equipment?', 'Dry ice cleaning removes physical buildup; it is not a sanitizer. Most customers follow it with their own approved sanitation process.' ),
				array( 'Will it damage stainless steel or belts?', 'No. It is non-abrasive, and pressure and pellet size are matched to the material.' ),
				array( 'Do you need to disassemble equipment?', 'Usually not. Cleaning in place is the main advantage, although guards may need to be opened according to your lockout procedure.' ),
				array( 'Can you clean restaurant hoods and kitchens?', 'Yes. We serve restaurants and commercial kitchens with waterless cleaning of hoods, ovens and equipment.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'manufacturing-machinery' => array(
			'seo_title'   => 'Industrial Machinery & Mold Cleaning | Dry Ice Blasting NJ & CT | Arctic Resto',
			'seo_desc'    => 'On-site dry ice cleaning for presses, injection molds, conveyors and electrical cabinets. Remove grease, oil, adhesives and mold release without water or chemicals. Serving NJ & CT.',
			'question'    => 'Can machinery be cleaned with dry ice while it is installed?',
			'intro'       => 'In most cases, yes. Dry ice is dry and non-abrasive, so presses, molds, motors and conveyors can often be cleaned in place with little or no teardown. Pellets remove grease, oil, adhesives, mold release and carbon, then sublimate — leaving no water or media to clean up. That shortens downtime and protects sensitive components.',
			'best'        => 'Injection molds, presses, extruders, conveyors, motors, control cabinets',
			'removes'     => 'Grease, oil, adhesives, mold release, ink, carbon and scale',
			'surfaces'    => 'Steel, cast iron, aluminum, plastics, concrete floors',
			'problems'    => array(
				array( 'Unplanned downtime', 'Dirty equipment runs hotter and fails sooner. Regular in-place cleaning is a fast preventive-maintenance step.' ),
				array( 'Mold fouling', 'Release agents and carbon build up in vents and fine detail. Dry ice cleans molds without polishing away detail.' ),
				array( 'Hard-to-reach buildup', 'Pellets reach into gaps, threads and cavities that scrapers and brushes cannot.' ),
				array( 'Contaminated waste streams', 'Solvent rags and sludge become hazardous waste. Dry ice leaves only the dislodged material.' ),
			),
			'guide_title' => 'Preventive cleaning that keeps production moving',
			'guide'       => '<p>Manufacturers use dry ice cleaning as a maintenance tool: a fast, dry way to restore equipment without dismantling it. Cleaner motors, bearings and heat-exchange surfaces run cooler, and cleaner tooling produces more consistent parts.</p><h3>Safe around electrical equipment</h3><p>Dry ice is non-conductive and leaves no moisture. Even so, we clean electrical cabinets and motors only under your lockout/tagout and site safety procedures, and we confirm scope before starting.</p><h3>Planned or on-demand</h3><p>Book one-off cleanings around planned shutdowns, or set a recurring schedule for molds, presses and conveyors so cleaning happens before buildup causes downtime.</p>',
			'apps'        => array( 'Injection molds and dies', 'Stamping and hydraulic presses', 'Extruders and conveyors', 'Electric motors and control cabinets', 'Printing and packaging machinery', 'Heat exchangers and ovens' ),
			'compare'     => array(
				array( 'Teardown', 'Usually cleaned in place', 'Often dismantled' ),
				array( 'Abrasion', 'Non-abrasive', 'Can wear tooling detail' ),
				array( 'Waste', 'None added', 'Solvent rags, sludge, spent media' ),
				array( 'Electrical safety', 'Dry and non-conductive', 'Water and solvents near electrics' ),
			),
			'steps'       => array(
				array( 'Assess & plan', 'We review the machine, contaminant and downtime window, and agree scope and safety steps with your maintenance team.' ),
				array( 'Lockout & prepare', 'Equipment is locked out per your procedure, nearby materials are protected and ventilation is set.' ),
				array( 'Clean in place', 'Pellet size and pressure are matched to the surface as buildup is lifted from molds, rollers, frames and cabinets.' ),
				array( 'Inspect & schedule', 'You inspect the results, and we can set a recurring plan so cleaning happens before buildup causes downtime.' ),
			),
			'faqs'        => array(
				array( 'Can machinery be cleaned while installed?', 'In most cases yes. Dry ice is dry and non-conductive, so we clean in place and avoid lengthy teardown.' ),
				array( 'What contaminants do you remove?', 'Grease, oil, adhesives, mold release, ink, carbon and general production buildup from a wide range of surfaces.' ),
				array( 'Is it safe near motors and control cabinets?', 'Dry ice is dry and non-conductive, but we clean electrical equipment only under your lockout and safety procedures.' ),
				array( 'Will dry ice damage molds?', 'No. It is non-abrasive and does not polish or erode mold detail when parameters are set correctly.' ),
				array( 'Can you set up recurring cleaning?', 'Yes. Many customers schedule monthly or quarterly cleaning of presses, molds and conveyors. We recommend a frequency after the first visit.' ),
				array( 'How long does a job take?', 'It depends on size and condition. We give a time estimate during the free assessment, and smaller machines are often completed in a single shift.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'utilities-power' => array(
			'seo_title'   => 'Power Plant & Utility Equipment Cleaning | Dry Ice Blasting | Arctic Resto NJ & CT',
			'seo_desc'    => 'Mobile dry ice cleaning for turbines, generators, switchgear and control equipment. Dry, non-conductive and residue-free, scheduled around outages. Serving NJ & CT.',
			'question'    => 'Is dry ice cleaning safe around electrical equipment in power plants?',
			'intro'       => 'Dry ice is dry, non-conductive and leaves no residue, which makes it well suited to generators, switchgear and control equipment. Pellets lift dust, carbon, oil and scale, then sublimate. Work is performed under the plant’s lockout and electrical safety procedures and scheduled around outages to protect restart dates.',
			'best'        => 'Generators, turbines, switchgear, transformers, bus bars, control cabinets',
			'removes'     => 'Dust, carbon, oil film, scale, fouling and old coatings',
			'surfaces'    => 'Copper windings, insulators, bus bars, turbine components, steel',
			'problems'    => array(
				array( 'Tight outage windows', 'Outages are short and expensive. Vans arrive fully equipped so cleaning starts as soon as access is granted.' ),
				array( 'Insulation contamination', 'Conductive dust and oil film reduce reliability. Dry cleaning removes them without adding moisture.' ),
				array( 'Fouled heat-transfer surfaces', 'Scale and carbon reduce efficiency. Dry ice lifts fouling without wash water or chemical cleaners.' ),
				array( 'Wet-cleaning risk', 'Water near electrical equipment adds drying time and risk. Dry ice adds neither.' ),
			),
			'guide_title' => 'Dry cleaning for energized-environment maintenance',
			'guide'       => '<p>Utilities and generation facilities need cleaning methods that respect electrical safety and outage schedules. Dry ice cleaning adds no water and no abrasive media, so there is nothing to dry, flush or recover from sensitive assemblies.</p><h3>Safety first</h3><p>Dry ice is non-conductive, but cleaning near electrical equipment is only performed where the owner’s procedures permit — including lockout/tagout, approach distances and permit requirements. Technicians also manage ventilation, because CO₂ displaces air in enclosed spaces.</p><h3>Scope and scheduling</h3><p>Share your outage schedule and equipment list. We plan access, staging and cleaning sequence so work fits your window, and we document what was cleaned for your maintenance records.</p>',
			'apps'        => array( 'Generators and rotors', 'Steam and gas turbine components', 'Switchgear and bus bars', 'Transformers and insulators', 'Control and relay cabinets', 'Cooling and heat-exchange surfaces' ),
			'compare'     => array(
				array( 'Moisture', 'None added', 'Water or steam adds drying time' ),
				array( 'Residue', 'None', 'Chemical or media residue possible' ),
				array( 'Outage time', 'Minimal downtime', 'Longer rinse and drying steps' ),
				array( 'Waste', 'Only the removed dirt', 'Contaminated rinse water' ),
			),
			'steps'       => array(
				array( 'Outage planning', 'We review your equipment list, outage window and site requirements, then agree sequence and staging.' ),
				array( 'Safe access & isolation', 'Isolation, permits and lockout are handled per your procedures before our team begins.' ),
				array( 'Dry cleaning', 'Pressure and pellet size are set per component while ventilation is monitored.' ),
				array( 'Record & handover', 'We document what was cleaned and hand equipment back clean and dry for reassembly or testing.' ),
			),
			'faqs'        => array(
				array( 'Is dry ice safe around electrical equipment?', 'Dry ice is non-conductive and leaves no moisture or residue, making it well suited to switchgear, generators and control cabinets when work follows the owner’s safety procedures.' ),
				array( 'Can you work inside an outage window?', 'Yes. Our vans arrive fully equipped so work begins the moment access is granted.' ),
				array( 'Can equipment be cleaned while energized?', 'Only where the equipment owner’s safety procedures explicitly allow it. In most cases we clean de-energized and locked-out equipment.' ),
				array( 'Does CO₂ create a safety issue in enclosed spaces?', 'CO₂ can displace air in confined areas. Our technicians manage ventilation and safe work zones on every job, and we coordinate confined-space rules with your safety team.' ),
				array( 'What can you clean on a turbine?', 'Dry ice can remove carbon, oil film and fouling from many turbine surfaces. Scope depends on the component and the manufacturer’s guidance, which we follow.' ),
				array( 'Do you serve other utility facilities?', 'Yes. We can clean electrical and mechanical equipment at substations, treatment facilities and generation sites across NJ and CT.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'automotive-restoration' => array(
			'seo_title'   => 'Classic Car Restoration Cleaning | Dry Ice Undercoating Removal | Arctic Resto CT & NJ',
			'seo_desc'    => 'Dry ice blasting for automotive restoration: remove undercoating, grease and loose rust from classic cars without damaging paint, chrome or wiring. Chemical-free and water-free. CT & NJ.',
			'question'    => 'Does dry ice cleaning damage car paint, chrome or wiring?',
			'intro'       => 'Not when settings are matched to the surface. Dry ice blasting is non-abrasive and sublimates on contact, leaving no chemical residue on paint, engines or electronics. It removes undercoating, grease, road grime and loose rust from chassis, engine bays and interiors without soaking wiring — which is why restorers use it to reveal what is underneath.',
			'best'        => 'Classic and collector cars, undercarriages, engine bays, suspension, interiors',
			'removes'     => 'Undercoating, grease, road grime, old sealant, loose rust, surface contamination',
			'surfaces'    => 'Steel, aluminum, rubber, chrome, fabric',
			'problems'    => array(
				array( 'Media-blasting damage', 'Sand and soda blasting can warp panels and pit metal. Dry ice does not embed media or heat-warp thin steel.' ),
				array( 'Water and electrics', 'Pressure washing drives water into wiring and cavities. Dry ice adds none.' ),
				array( 'Hidden rust and seams', 'Undercoating can hide corrosion. Removing it shows the true condition before you commit to repairs.' ),
				array( 'Preserving originality', 'Markings, numbers and patina survive when parameters are matched to the surface.' ),
			),
			'guide_title' => 'Reveal the original — without stripping it away',
			'guide'       => '<p>Restoration projects turn on what is under decades of grime. Dry ice cleaning lifts undercoating, grease and road film so you can assess metal, welds and hardware before deciding what to repair.</p><h3>Undercarriage, engine bay and interior</h3><p>Undercarriages and suspension are cleaned in place, engine bays are degreased without soaking wiring, and chrome details and fabric interiors can be refreshed with gentler settings.</p><h3>Aftercare</h3><p>Bare metal can begin to oxidize quickly. Plan primer, rust-preventive coatings or undercoating right after cleaning — we are happy to coordinate timing with your restorer or paint shop.</p>',
			'apps'        => array( 'Undercoating removal', 'Frame and suspension cleaning', 'Engine-bay degreasing', 'Wheel wells and underbody', 'Interior and headliner refresh', 'Pre-paint surface preparation' ),
			'compare'     => array(
				array( 'Panel warping', 'No heat warping or embedded media', 'Sanding and media blasting can warp or pit' ),
				array( 'Wiring & electronics', 'Dry — nothing soaked', 'Water can enter connectors and cavities' ),
				array( 'Chemicals', 'None', 'Strippers and degreasers' ),
				array( 'Cleanup', 'Only removed debris', 'Media everywhere, plus rinse water' ),
			),
			'steps'       => array(
				array( 'Inspect & plan', 'We assess the vehicle, coatings and goals — from light degreasing to full undercoating removal.' ),
				array( 'Protect & prep', 'Glass, trim and sensitive parts are masked, and settings are tested in an inconspicuous area.' ),
				array( 'Clean by section', 'Undercarriage, engine bay and interior are cleaned with pressure and pellet size matched to each surface.' ),
				array( 'Protect the metal', 'We hand the car back clean and dry so you can apply primer, paint or rust-preventive coatings right away.' ),
			),
			'faqs'        => array(
				array( 'Will it harm paint, chrome or wiring?', 'No. Dry ice sublimates on contact and leaves no chemical residue, making it ideal for sensitive areas like paint, engines and electronic components when settings are matched to the surface.' ),
				array( 'Can it clean interiors?', 'Yes. Dry ice can restore chrome details and fabric interiors without the abrasiveness of other cleaning methods.' ),
				array( 'Can dry ice remove undercoating and rust?', 'It removes undercoating, grease and loose rust scale. Heavy, bonded rust may require additional treatment, which we flag during the assessment.' ),
				array( 'Do I need to disassemble the car?', 'Not for most jobs. Cleaning happens in place, although removing bolt-on parts can improve access for full restorations.' ),
				array( 'What should I do after cleaning?', 'Protect exposed metal quickly with primer, paint or an appropriate rust-preventive coating.' ),
				array( 'Can you come to my shop or garage?', 'Yes. We are mobile and can work at a restoration shop, garage or private property in CT and NJ.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'boats-marinas' => array(
			'seo_title'   => 'Boat Hull & Engine Cleaning | Dry Ice Blasting for Marinas | Arctic Resto CT & NJ',
			'seo_desc'    => 'Mobile dry ice cleaning for boats and marinas: remove salt, barnacles, growth, bottom paint and oil with zero moisture and nothing entering the water. Serving CT & NJ.',
			'question'    => 'Does dry ice cleaning keep contaminants out of the water at a marina?',
			'intro'       => 'Yes. Dry ice pellets turn to CO₂ gas on contact, so there is no blasting media, wash water or chemical runoff to enter the harbor. Only the removed material — such as marine growth or old paint — remains to be collected. It cleans salt, barnacles, oil and grime from hulls, engines and bilges with zero moisture.',
			'best'        => 'Boat owners, boatyards and marinas; hulls, engines, outdrives and bilges',
			'removes'     => 'Salt, barnacles and marine growth, old bottom paint, oil and grime',
			'surfaces'    => 'Fiberglass, aluminum, steel, engines and outdrives',
			'problems'    => array(
				array( 'Runoff into the water', 'Pressure washing and abrasive blasting send debris and contaminants toward the water. Dry ice adds none.' ),
				array( 'Bottom-paint removal', 'Old antifouling layers can be lifted without gouging gelcoat when parameters are set correctly.' ),
				array( 'Oily bilges and engine bays', 'Grease and oil can be lifted without flooding the bilge with cleaners.' ),
				array( 'A short haul-out season', 'Mobile service means work happens at your yard, stand or slip with no extra transport.' ),
			),
			'guide_title' => 'Dry ice cleaning for boats, boatyards and marinas',
			'guide'       => '<p>Boatyards and marinas face tight environmental scrutiny and short seasons. Dry ice cleaning helps because the blasting medium vanishes — only the removed material needs to be collected.</p><h3>Hulls, engines and bilges</h3><p>Hulls hauled out on stands can be cleaned of marine growth and salt; engines, outdrives and bilges are degreased without cleaners entering the water; interiors and lockers can be refreshed without moisture.</p><h3>Containment and disposal</h3><p>Removed bottom paint may contain biocides. We plan containment with your yard, and the collected debris must be handled and disposed of according to local rules.</p>',
			'apps'        => array( 'Hull cleaning on the hard', 'Bottom-paint removal', 'Engine and bilge degreasing', 'Outdrives and lower units', 'Decks, lockers and interiors', 'Marine equipment and trailers' ),
			'compare'     => array(
				array( 'Runoff', 'None — no water or media', 'Wash water and debris' ),
				array( 'Moisture', 'Zero', 'Soaks surfaces and cavities' ),
				array( 'Gelcoat', 'Non-abrasive, adjustable', 'Sanding and grit can gouge' ),
				array( 'Chemicals', 'None', 'Strippers and degreasers' ),
			),
			'steps'       => array(
				array( 'Assess & book', 'We review the vessel, coatings and haul-out schedule, then plan containment with the yard.' ),
				array( 'Stage at your yard', 'The van arrives with dry ice, compressor and PPE, and work zones are set up around the boat.' ),
				array( 'Clean', 'Growth, paint, oil and grime are lifted with settings matched to gelcoat, aluminum or steel.' ),
				array( 'Collect & finish', 'Removed debris is collected for proper disposal and the boat is ready for paint or launch.' ),
			),
			'faqs'        => array(
				array( 'Does anything enter the water?', 'No. Pellets turn to CO₂ gas on contact, so no media, chemicals or wash water reach the harbor.' ),
				array( 'What does marine cleaning remove?', 'Salt, barnacles, marine growth, old bottom paint, oil and grime — with zero moisture.' ),
				array( 'Can you clean while the boat is in the water?', 'Above-waterline areas such as engines, decks and interiors can be cleaned afloat. Hull-bottom work is done with the boat out of the water.' ),
				array( 'Will it damage fiberglass gelcoat?', 'Not when settings are matched to the surface — dry ice is non-abrasive compared with sanding or grit blasting.' ),
				array( 'How is removed bottom paint handled?', 'Removed material can contain biocides and must be collected and disposed of according to local regulations. We plan containment with your yard.' ),
				array( 'Do you work with marinas and boatyards?', 'Yes. We serve individual boat owners, boatyards and marinas across CT and NJ.' ),
			),
		),

		/* ------------------------------------------------------------ */
		'fire-restoration' => array(
			'seo_title'   => 'Fire Damage Restoration | Dry Ice Soot & Smoke Odor Removal | Arctic Resto CT & NJ',
			'seo_desc'    => 'Dry ice blasting for fire restoration: remove soot, char, smoke odor and mold from wood, brick and joists without water or chemicals. Fast and eco-friendly. Serving CT & NJ.',
			'question'    => 'Does dry ice cleaning remove smoke odor and soot after a fire?',
			'intro'       => 'Yes. Dry ice cleaning removes soot, char and smoke residue from wood, brick and structural joists, which helps eliminate lingering odors. It adds no water or chemicals, so it does not introduce new moisture to fire-damaged structures, and it sublimates on contact so there is no secondary waste — only the removed debris remains.',
			'best'        => 'Fire, smoke, water and mold damage in homes and commercial buildings',
			'removes'     => 'Soot, char, smoke residue, mold, water stains and odor-trapping deposits',
			'surfaces'    => 'Wood framing and joists, brick, concrete, structural steel',
			'problems'    => array(
				array( 'Smoke odor that will not leave', 'Odor lives in char and residue on framing. Removing the deposit works better than masking it.' ),
				array( 'Added moisture', 'Water-based cleaning adds moisture to already-wet structures and can encourage mold. Dry ice adds none.' ),
				array( 'Damaged surfaces', 'Sanding and scrubbing remove material. Dry ice cleans wood and brick with a non-abrasive process.' ),
				array( 'Slow rebuild schedules', 'No drying, rinse or chemical neutralizing means restoration can move to rebuild sooner.' ),
			),
			'guide_title' => 'Restoring fire-damaged structures with dry ice',
			'guide'       => '<p>After a fire, the priority is a clean, dry, safe structure. Dry ice cleaning tackles soot, char and mold without adding water, which makes it a strong option for restoration contractors and homeowners alike.</p><h3>Wood, brick and joists</h3><p>Exposed framing, joists, masonry and structural steel can be cleaned back to sound material. Charred surface layers are removed; deeply burned or structurally compromised members remain a job for engineers and rebuild crews.</p><h3>Working with restoration teams</h3><p>We coordinate with your restoration contractor on scope, containment and sequencing so cleaning fits your project plan. Where required, air-quality and containment procedures follow your project protocols.</p>',
			'apps'        => array( 'Exposed joists and framing', 'Brick and masonry', 'Attics and crawl spaces', 'Basements after water damage', 'Mold-affected wood and surfaces', 'Commercial kitchen fire damage' ),
			'compare'     => array(
				array( 'Added moisture', 'None', 'Water and wet chemicals' ),
				array( 'Odor removal', 'Removes odor-trapping deposits', 'Often masks with deodorizers' ),
				array( 'Surface damage', 'Non-abrasive', 'Sanding or scrubbing removes material' ),
				array( 'Secondary waste', 'Only removed debris', 'Contaminated water and sludge' ),
			),
			'steps'       => array(
				array( 'Assess damage & scope', 'We inspect the affected areas and coordinate scope with your restoration contractor or owner.' ),
				array( 'Contain & protect', 'Areas are contained and protected, and ventilation and safe work zones are set.' ),
				array( 'Dry ice clean', 'Soot, char and mold are lifted from framing and masonry with no water added.' ),
				array( 'Vacuum & hand over', 'Debris is vacuumed and the structure is ready for sealing, repair or rebuild.' ),
			),
			'faqs'        => array(
				array( 'Does dry ice cleaning remove smoke odors?', 'Absolutely. It effectively eliminates smoke residue and lingering odors, restoring air quality in fire-damaged spaces.' ),
				array( 'Is it safe for wood, brick and metal?', 'Yes. Dry ice cleaning is gentle yet powerful, safe for materials like wood, brick and metal without causing additional damage.' ),
				array( 'Can it remove mold?', 'Yes. It removes mold from surfaces without introducing moisture, reducing the risk of regrowth.' ),
				array( 'How does it compare with traditional restoration methods?', 'Unlike pressure washing or abrasive cleaning, dry ice cleaning is non-destructive and leaves no secondary waste, making it a cleaner and more efficient solution.' ),
				array( 'How quickly can fire-damaged surfaces be restored?', 'The process is fast and requires minimal downtime, allowing restoration work to proceed efficiently.' ),
				array( 'Does it replace structural repair?', 'No. Dry ice cleans surfaces; structurally compromised material still needs assessment and repair by qualified professionals.' ),
			),
		),
	);
}
