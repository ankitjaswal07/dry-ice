<?php
/**
 * Demo content for the main Franchise page.
 * Structured so a first-time visitor always knows the next step: overview, choose your path,
 * what is included, how it compares, whether it fits, how to start, territories, FAQ.
 * Nothing here states fees, earnings or guarantees.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_demo_franchise_page() {
	$features = array( 'A proven business model', 'Low initial investment', 'Access to a world-class executive team', 'Unique, differentiated branding', 'Multiple revenue streams', 'Comprehensive “done for you” marketing', 'Lead generation & appointment setting', 'Extensive training & corporate support', 'Industry-leading proprietary technology suite' );

	return array(
		'title'     => 'Franchise Opportunities',
		'excerpt'   => 'The industry’s first and only mobile dry ice cleaning franchise. Own your van and equipment 100% with training, marketing and technology support.',
		'seo_title' => 'Mobile Dry Ice Cleaning Franchise | Own Your Van & Equipment | Arctic Resto',
		'seo_desc'  => 'Own the industry’s first mobile dry ice cleaning franchise: your own van and equipment, training, done-for-you marketing and a technology platform. Register in the franchise portal.',
		'els'       => array(
			ar_demo_hero( 'Franchising re-imagined', "The industry's first & only {{mobile dry ice cleaning franchise.}}", 'Start your own Mobile Dry Ice Cleaning Franchise with a fully equipped van and complete support. Get trained and begin working right away with our easy business model.', 'van', 'Register for the franchise portal', '{portal-register}', 'Franchise owner login', '{portal-login}' ),
			ar_demo_w(
				'ar_page_nav',
				array(
					'label' => 'On this page',
					'items' => array(
						array( 'label' => 'Overview', 'anchor' => 'overview' ),
						array( 'label' => 'Where to start', 'anchor' => 'start' ),
						array( 'label' => 'What’s included', 'anchor' => 'included' ),
						array( 'label' => 'Compare', 'anchor' => 'compare' ),
						array( 'label' => 'Is it for you?', 'anchor' => 'fit' ),
						array( 'label' => 'Path to ownership', 'anchor' => 'path' ),
						array( 'label' => 'Territories', 'anchor' => 'territories' ),
						array( 'label' => 'FAQ', 'anchor' => 'faq' ),
					),
					'b1_t'  => 'Register',
					'b1_u'  => ar_demo_link( '{portal-register}' ),
				)
			),
			ar_demo_w(
				'ar_answer',
				array(
					'question'    => 'What is the Arctic Resto mobile dry ice cleaning franchise?',
					'answer'      => "Arctic Resto is the industry's first and only mobile dry ice cleaning franchise. It is a business-in-a-box model: franchisees own their van and equipment 100%, are trained to run jobs immediately, and receive a call center, done-for-you marketing, lead generation and a proprietary technology platform. Prime territories begin in Connecticut, expanding to Massachusetts and New Jersey.",
					'updated'     => 'yes',
					'note'        => 'Franchise offerings are made only by disclosure document.',
					'facts_title' => 'Franchise at a glance',
					'facts'       => array(
						array( 'label' => 'Model', 'value' => 'Business-in-a-box mobile franchise' ),
						array( 'label' => 'Ownership', 'value' => 'Franchisee owns the van and equipment 100%' ),
						array( 'label' => 'Financing', 'value' => 'Introductions to financing options are available' ),
						array( 'label' => 'Training', 'value' => 'Extensive training and corporate support; ready for first jobs at the close of training' ),
						array( 'label' => 'Support', 'value' => 'Centralized call center, online marketing, lead generation, technology platform' ),
						array( 'label' => 'Territories', 'value' => 'Beginning in CT; expanding to MA and NJ' ),
					),
					'b1_t'        => 'Register for the franchise portal',
					'b1_u'        => ar_demo_link( '{portal-register}' ),
					'b2_t'        => 'Franchise owner login',
					'b2_u'        => ar_demo_link( '{portal-login}' ),
					'anchor'      => 'overview',
					'theme'       => 'frost',
					'pad'         => 'md',
				)
			),
			ar_demo_w(
				'ar_icon_boxes',
				array_merge(
					ar_demo_h( 'Not sure where to start?', 'Pick the {{option that fits you}}', 'Three simple next steps — choose one and you will be in the right place.' ),
					array(
						'layout' => 'cards',
						'cols'   => '3',
						'theme'  => 'light',
						'anchor' => 'start',
						'items'  => array(
							array( 'icon' => ar_demo_icon( 'fas fa-user-plus' ), 'title' => 'New here? Register', 'text' => 'Create your franchise portal account to review the opportunity, see available territories and begin your application.', 'link' => ar_demo_link( '{portal-register}' ) ),
							array( 'icon' => ar_demo_icon( 'fas fa-sign-in-alt' ), 'title' => 'Already registered? Log in', 'text' => 'Sign in to continue your application, review documents and track your onboarding progress.', 'link' => ar_demo_link( '{portal-login}' ) ),
							array( 'icon' => ar_demo_icon( 'fas fa-comments' ), 'title' => 'Have questions first?', 'text' => 'Talk to our team before you register. We will answer questions about the model, territories and next steps.', 'link' => ar_demo_link( '/contact/' ) ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_split',
				array_merge(
					ar_demo_h( 'Business in a box', 'Own your van & equipment {{100%}}', 'Arctic Resto offers a “business-in-a-box” franchise where franchisees own their van and equipment outright. Introductions to financing options are available.', 'left' ),
					array(
						'checks'  => implode( "\n", $features ),
						'image'   => ar_demo_img( 'van' ),
						'badge_t' => '100%',
						'badge_s' => 'van & equipment ownership',
						'anchor'  => 'included',
						'theme'   => 'frost',
					)
				)
			),
			ar_demo_w(
				'ar_compare',
				array_merge(
					ar_demo_h( 'Compare', 'Franchise vs {{starting on your own}}', 'What you get with Arctic Resto compared with building a mobile dry ice cleaning business from scratch.', 'left' ),
					array(
						'col_a'  => 'Arctic Resto franchise',
						'col_b'  => 'Starting on your own',
						'pills'  => '',
						'anchor' => 'compare',
						'theme'  => 'dark',
						'items'  => array(
							array( 'title' => 'Van and equipment', 'a' => 'Fully outfitted van built for you, owned 100%', 'b' => 'Design, source and build it yourself' ),
							array( 'title' => 'Training', 'a' => 'Extensive training; ready for first jobs at the close of training', 'b' => 'Learn through trial and error' ),
							array( 'title' => 'Getting customers', 'a' => 'Lead generation and appointment setting', 'b' => 'Build your own marketing and sales' ),
							array( 'title' => 'Booking and service', 'a' => 'Centralized call center', 'b' => 'Answer every call yourself' ),
							array( 'title' => 'Software', 'a' => 'Proprietary tech suite: tracking, email, invoicing', 'b' => 'Assemble and pay for separate tools' ),
							array( 'title' => 'Brand', 'a' => 'Unique, differentiated branding', 'b' => 'Start with no recognition' ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_fit',
				array_merge(
					ar_demo_h( 'Is it right for you?', 'An honest look at {{who succeeds}}', 'Franchising is a serious commitment. This helps you decide before you register.' ),
					array(
						'good_t' => 'Typically a good fit',
						'good'   => "You are comfortable running an on-site, hands-on service business\nYou enjoy building relationships with business and homeowner customers\nYou want to follow a proven system rather than invent one\nYou like the idea of an eco-friendly, water-free, chemical-free service",
						'bad_t'  => 'Probably not the best fit',
						'bad'    => "You want a passive investment with no day-to-day involvement\nYou are not comfortable with physical, on-site work\nYou are looking for guaranteed income — no franchise can promise that",
						'note'   => 'Fees, obligations, territories and any earnings information are described only in the Franchise Disclosure Document. Review it with your own advisors.',
						'anchor' => 'fit',
						'theme'  => 'light',
					)
				)
			),
			ar_demo_w(
				'ar_icon_boxes',
				array_merge(
					ar_demo_h( 'Path to ownership', 'From financing to {{first jobs}}', "Once financing is secured, the van is built, training is scheduled, and you're ready for your first jobs immediately at the close of training." ),
					array(
						'layout' => 'process',
						'cols'   => '4',
						'theme'  => 'void',
						'howto'  => 'yes',
						'anchor' => 'path',
						'items'  => array(
							array( 'icon' => ar_demo_icon( 'fas fa-user-plus' ), 'title' => 'Register in the portal', 'text' => 'Create your portal account to review the opportunity and begin your application.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-hand-holding-usd' ), 'title' => 'Secure financing', 'text' => 'Introductions to financing options are available so you can own your van and equipment 100%.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-graduation-cap' ), 'title' => 'Your van is built and you train', 'text' => 'A fully outfitted Sprinter is built while hands-on training covers equipment, safety, sales and operations.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-rocket' ), 'title' => 'First jobs, day one', 'text' => 'You are ready for your first jobs immediately at the close of training.' ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_icon_boxes',
				array_merge(
					ar_demo_h( 'Franchisor support', 'You run the van. {{We run the back office.}}', 'The franchisor provides services and benefits that let you focus on the work.' ),
					array(
						'layout' => 'cards',
						'cols'   => '4',
						'theme'  => 'frost',
						'items'  => array(
							array( 'icon' => ar_demo_icon( 'fas fa-headset' ), 'title' => 'Centralized call center', 'text' => 'Customer service and appointment booking handled for you.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-bullhorn' ), 'title' => 'Online marketing services', 'text' => 'Websites, local SEO, ads and social — done for you.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-graduation-cap' ), 'title' => 'Continued training', 'text' => 'An always-on library of resources as your business grows.' ),
							array( 'icon' => ar_demo_icon( 'fas fa-chart-line' ), 'title' => 'Custom tech platform', 'text' => 'Customer tracking, email campaigns, invoicing and much more.' ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_services',
				array_merge(
					ar_demo_h( 'Multiple revenue streams', 'One van. {{Seven markets.}}', 'Residential, commercial, automotive, boat and marine, restaurants, industrial and fire restoration.' ),
					array( 'layout' => 'grid', 'count' => -1, 'theme' => 'light' )
				)
			),
			ar_demo_w(
				'ar_terr_cards',
				array_merge(
					ar_demo_h( 'Territories', 'Where you could {{own a territory}}', 'Prime territories are available beginning in Connecticut, with New Jersey and Massachusetts opening and Southeast expansion planned.' ),
					array( 'count' => -1, 'anchor' => 'territories', 'theme' => 'frost' )
				)
			),
			ar_demo_w(
				'ar_calculator',
				array_merge(
					ar_demo_h( 'Explore the model', 'Play with the {{numbers}}', 'Adjust the sliders to see how job volume and ticket size could scale a single van.' ),
					array( 'theme' => 'dark' )
				)
			),
			ar_demo_w(
				'ar_portal',
				array_merge(
					ar_demo_h( 'Franchise portal', 'Register or log in to the {{franchise portal}}', 'New to Arctic Resto? Register to start. Already have an account? Log in to your dashboard.', 'left' ),
					array(
						'features' => "Register in minutes\nReview the opportunity and documents securely\nTrack your application, training and van build\nOwner dashboard, tools and resources",
						'card_t'   => 'Arctic Resto Franchise Portal',
						'card_s'   => 'Secure access for prospective and current franchise owners.',
						'b1_t'     => 'Register for the franchise portal',
						'b1_u'     => ar_demo_link( '' ),
						'b2_t'     => 'Franchise owner login',
						'b2_u'     => ar_demo_link( '' ),
						'note'     => 'Registering is not an offer or a commitment to purchase a franchise. Franchise offerings are made only by disclosure document.',
						'anchor'   => 'register',
						'theme'    => 'dark',
					)
				)
			),
			ar_demo_w(
				'ar_faq',
				array_merge(
					ar_demo_h( 'Franchise FAQ', 'Answers for {{future owners}}' ),
					array(
						'anchor' => 'faq',
						'theme'  => 'frost',
						'items'  => array(
							array( 'cat' => 'Getting started', 'q' => 'How do I register for the franchise portal?', 'a' => 'Use the Register button on this page. It takes you to the franchise portal where you create an account to review the opportunity and begin your application.' ),
							array( 'cat' => 'Getting started', 'q' => 'I already have an account. Where do I log in?', 'a' => 'Use the Franchise owner login button at the top of this page, in the header, or in the footer. It takes you straight to the portal sign-in.' ),
							array( 'cat' => 'Getting started', 'q' => 'Is registering a commitment to buy a franchise?', 'a' => 'No. Registering is not an offer or a commitment to purchase a franchise. Franchise offerings are made only by disclosure document.' ),
							array( 'cat' => 'The model', 'q' => 'Do I own the van and equipment?', 'a' => 'Yes. Arctic Resto is a “business-in-a-box” franchise where franchisees own their van and equipment 100%. Introductions to financing options are available.' ),
							array( 'cat' => 'The model', 'q' => 'Do I need dry ice cleaning experience?', 'a' => 'No. Training covers equipment operation, safety, sales and operations, so you are ready for your first jobs immediately at the close of training.' ),
							array( 'cat' => 'The model', 'q' => 'Who handles marketing and bookings?', 'a' => 'The franchisor provides a centralized call center for customer service and appointment booking, plus online marketing and lead generation services.' ),
							array( 'cat' => 'The model', 'q' => 'What revenue streams are there?', 'a' => 'Residential, commercial, automotive, boat and marine, restaurants, industrial and fire restoration — multiple revenue streams from a single van.' ),
							array( 'cat' => 'Territories', 'q' => 'Which territories are available?', 'a' => 'Prime territories are available now beginning in Connecticut, with New Jersey and Massachusetts opening soon and Southeast expansion planned. Each has its own page.' ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_cta',
				array(
					'title' => 'Ready to take the first step?',
					'text'  => 'Register in the franchise portal, or log in to continue where you left off.',
					'b1_t'  => 'Register for the franchise portal',
					'b1_u'  => ar_demo_link( '{portal-register}' ),
					'b2_t'  => 'Franchise owner login',
					'b2_u'  => ar_demo_link( '{portal-login}' ),
					'theme' => 'gradient',
				)
			),
		),
	);
}
