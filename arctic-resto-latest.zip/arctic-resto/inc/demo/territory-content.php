<?php
/**
 * Demo content for the Territories section: one main page plus one child page per territory.
 * All values are demo data that end up as editable Elementor widgets and page fields.
 * Coverage lists are examples — edit them to match where you really operate.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_demo_territory_data() {
	return array(
		array(
			'slug'        => 'connecticut',
			'name'        => 'Connecticut',
			'code'        => 'CT',
			'tone'        => 'live',
			'status'      => 'Serving now — home base',
			'blurb'       => 'Home base. Our first corporate van hits the road weekly across Connecticut.',
			'areas'       => array( 'Fairfield County', 'New Haven County', 'Hartford County', 'Litchfield County', 'Middlesex County', 'New London County', 'Tolland County', 'Windham County' ),
			'x'           => 62,
			'y'           => 42,
			'img'         => 'territory-ct',
			'seo_title'   => 'Dry Ice Cleaning in Connecticut | Mobile Service, All 8 Counties | Arctic Resto',
			'seo_desc'    => 'Mobile dry ice cleaning across Connecticut for marinas, classic cars, fire restoration, food plants and industrial equipment. No water, no chemicals. Free quotes from Arctic Resto.',
			'question'    => 'Does Arctic Resto offer mobile dry ice cleaning in Connecticut?',
			'intro'       => 'Yes. Connecticut is Arctic Resto’s home base. Our fully equipped Mercedes Sprinter vans carry 900 lbs of dry ice and industrial blasting equipment to homes, businesses, marinas and industrial sites across the state. We clean with no water, no chemicals and no secondary waste, and prime franchise territory locations are available in Connecticut now.',
			'facts'       => array(
				array( 'Status', 'Serving now — home base' ),
				array( 'Coverage', 'Connecticut, county by county — see the coverage list below' ),
				array( 'Services', 'All seven service lines' ),
				array( 'Delivery', 'On-site in a fully equipped Sprinter van' ),
				array( 'Environment', 'No water, no chemicals, no secondary waste' ),
				array( 'Franchise', 'Prime territory locations available now' ),
			),
			'guide_title' => 'Dry ice cleaning from the Connecticut shoreline to its factory floors',
			'guide'       => '<p>Connecticut combines a long shoreline, historic homes and buildings, food businesses and manufacturers — all places where water, chemicals and abrasive media create problems. Dry ice cleaning avoids all three, which is why mobile service fits the state well.</p><h3>Coastal and marine</h3><p>Boat owners and marinas along Long Island Sound can have hulls, engines and bilges cleaned at the yard or slip without runoff entering the water.</p><h3>Restoration and historic buildings</h3><p>Dry ice lifts soot, char, mold and old coatings from wood and brick without adding moisture, which suits both fire restoration and older buildings.</p><h3>Industry and commercial kitchens</h3><p>Manufacturing equipment, bakeries and restaurant kitchens can be cleaned in place, with no drying time before restart.</p>',
			'apps'        => array( 'Marina and boatyard cleaning', 'Classic car and undercoating restoration', 'Fire, smoke and mold restoration', 'Food plants, bakeries and restaurants', 'Manufacturing and machinery maintenance', 'Historic building restoration' ),
			'fr_text'     => 'Connecticut is where Arctic Resto started. Prime franchise territory locations are available here now — with your own fully equipped van, training and franchisor support.',
			'fr_answer'   => 'Yes. Prime territory locations are available now, beginning in Connecticut. Register in the franchise portal to review current availability.',
		),
		array(
			'slug'        => 'new-jersey',
			'name'        => 'New Jersey',
			'code'        => 'NJ',
			'tone'        => 'live',
			'status'      => 'Serving now',
			'blurb'       => 'Industrial and commercial customers across northern and central New Jersey.',
			'areas'       => array( 'Bergen County', 'Essex County', 'Hudson County', 'Middlesex County', 'Monmouth County', 'Morris County', 'Passaic County', 'Union County' ),
			'x'           => 38,
			'y'           => 68,
			'img'         => 'territory-nj',
			'seo_title'   => 'Dry Ice Cleaning in New Jersey | Industrial & Commercial Mobile Service | Arctic Resto',
			'seo_desc'    => 'Mobile dry ice cleaning in northern and central New Jersey for manufacturing, food processing, utilities, automotive and marine equipment. No water, no chemicals. Get a free quote.',
			'question'    => 'Does Arctic Resto offer dry ice cleaning in New Jersey?',
			'intro'       => 'Yes. Arctic Resto serves industrial and commercial customers across northern and central New Jersey with fully equipped mobile dry ice cleaning vans. We clean manufacturing equipment, food processing lines, utility assets, vehicles and marine equipment on-site — with no water, no chemicals and no secondary waste. Franchise territories in New Jersey are opening soon.',
			'facts'       => array(
				array( 'Status', 'Serving now' ),
				array( 'Focus', 'Industrial and commercial customers' ),
				array( 'Services', 'All seven service lines' ),
				array( 'Delivery', 'On-site in a fully equipped Sprinter van' ),
				array( 'Environment', 'No water, no chemicals, no secondary waste' ),
				array( 'Franchise', 'Territories opening soon' ),
			),
			'guide_title' => 'Mobile dry ice cleaning for New Jersey industry',
			'guide'       => '<p>New Jersey is home to a dense mix of manufacturers, food producers, logistics operations and utilities. For these facilities, downtime is expensive and wet cleaning is often impractical.</p><h3>Cleaning that fits your shutdown</h3><p>Because dry ice leaves no water or media to remove, equipment can be cleaned during an off-shift or a short planned stop and returned to service without a drying wait.</p><h3>Plants, power and the shore</h3><p>The same mobile van serves food processing lines, switchgear and generators, vehicles and fleets, and boats along the coast — one method, no runoff, no chemical storage.</p>',
			'apps'        => array( 'Manufacturing and machinery maintenance', 'Food processing lines and bakery ovens', 'Utility and power equipment', 'Aerospace and defense tooling', 'Automotive and fleet restoration', 'Boats, marinas and marine equipment' ),
			'fr_text'     => 'New Jersey franchise territories are opening soon. Register in the franchise portal to be considered as they are released.',
			'fr_answer'   => 'New Jersey franchise territories are opening soon. Register in the franchise portal to be considered as they are released.',
		),
		array(
			'slug'        => 'massachusetts',
			'name'        => 'Massachusetts',
			'code'        => 'MA',
			'tone'        => 'soon',
			'status'      => 'Franchise territories opening',
			'blurb'       => 'Prime territories are opening to franchise owners. Register your interest.',
			'areas'       => array( 'Suffolk County', 'Middlesex County', 'Norfolk County', 'Worcester County', 'Hampden County', 'Essex County' ),
			'x'           => 66,
			'y'           => 20,
			'img'         => 'territory-ma',
			'seo_title'   => 'Dry Ice Cleaning Franchise Territories in Massachusetts | Arctic Resto',
			'seo_desc'    => 'Massachusetts is one of Arctic Resto’s next franchise territories for mobile dry ice cleaning. See planned coverage, services and how to register your interest.',
			'question'    => 'Is Arctic Resto available in Massachusetts?',
			'intro'       => 'Massachusetts is one of Arctic Resto’s next franchise territories. Local owner-operators will bring mobile dry ice cleaning — no water, no chemicals, no secondary waste — to the state as territories open. If you need cleaning now, contact us and we will confirm the nearest available service.',
			'facts'       => array(
				array( 'Status', 'Franchise territories opening' ),
				array( 'Planned coverage', 'Six counties — see the list below' ),
				array( 'Services (at launch)', 'All seven service lines' ),
				array( 'Delivery', 'Mobile Sprinter van run by a local owner-operator' ),
				array( 'Need service now?', 'Contact us to confirm the nearest available service' ),
				array( 'Franchise', 'Register in the portal to be considered' ),
			),
			'guide_title' => 'What mobile dry ice cleaning will bring to Massachusetts',
			'guide'       => '<p>Massachusetts has a long coastline, working harbors, historic buildings and a broad base of manufacturers and food businesses — the same mix of customers that benefit most from water-free, chemical-free cleaning.</p><h3>Owner-operators, local service</h3><p>Arctic Resto grows through franchise owners who run their own fully equipped van. Each territory is served by a local owner, so customers deal with someone who works in their area.</p><h3>Want to be that owner?</h3><p>Registering in the franchise portal lets you review the opportunity and see how territories are released. Franchise offerings are made only by disclosure document.</p>',
			'apps'        => array( 'Marine and harbor equipment', 'Historic building restoration', 'Fire and mold restoration', 'Food processing and restaurants', 'Manufacturing maintenance', 'Classic and collector vehicles' ),
			'fr_text'     => 'Prime Massachusetts territories are opening to franchise owners. Register in the franchise portal to review the opportunity and be considered.',
			'fr_answer'   => 'Massachusetts franchise territories are opening. Register in the franchise portal to be considered as they are released.',
		),
		array(
			'slug'        => 'southeast-usa',
			'name'        => 'Southeast USA',
			'code'        => 'SE',
			'tone'        => 'plan',
			'status'      => 'Planned expansion',
			'blurb'       => 'Expansion into the Southeast is planned. Register your interest early.',
			'areas'       => array( 'Georgia', 'Florida', 'The Carolinas', 'Tennessee' ),
			'x'           => 22,
			'y'           => 88,
			'img'         => 'territory-se',
			'seo_title'   => 'Mobile Dry Ice Cleaning in the Southeast | Planned Expansion | Arctic Resto',
			'seo_desc'    => 'Arctic Resto plans to expand mobile dry ice cleaning into the Southeast USA. See planned regions and register your interest in a franchise territory.',
			'question'    => 'Will Arctic Resto expand to the Southeast?',
			'intro'       => 'Yes, expansion into the Southeast is planned. Arctic Resto serves industrial and commercial customers across the Northeast today and plans to expand shortly into the Southeast. Register in the franchise portal to be kept informed as territories are released.',
			'facts'       => array(
				array( 'Status', 'Planned expansion' ),
				array( 'Planned regions', 'Georgia, Florida, the Carolinas and Tennessee' ),
				array( 'Available today in', 'New Jersey and Connecticut' ),
				array( 'Delivery model', 'Mobile Sprinter vans run by franchise owners' ),
				array( 'Timing', 'Territories have not been released yet' ),
				array( 'Franchise', 'Register in the portal to be kept informed' ),
			),
			'guide_title' => 'Planning for mobile dry ice cleaning in the Southeast',
			'guide'       => '<p>Ports, marinas, restaurants, manufacturers and warm-climate restoration work all create demand for cleaning that uses no water and no chemicals. The Southeast is a natural next region for the mobile franchise model.</p><h3>What happens next</h3><p>Expansion follows the Northeast rollout. Regions and timing will be announced as territories are released.</p><h3>Stay informed</h3><p>Registering in the franchise portal is the simplest way to hear first. Registering is not an offer or a commitment to buy a franchise.</p>',
			'apps'        => array( 'Ports, boats and marinas', 'Restaurants and commercial kitchens', 'Food processing', 'Manufacturing and machinery', 'Fire, smoke and mold restoration', 'Automotive restoration' ),
			'fr_text'     => 'Southeast territories have not been released yet. Register in the franchise portal to be kept informed and considered early.',
			'fr_answer'   => 'Southeast territories have not been released yet. Register in the franchise portal to be kept informed.',
		),
	);
}

function ar_demo_territory_faqs( $t ) {
	$n    = $t['name'];
	$live = 'live' === $t['tone'];
	if ( $live ) {
		$serve = 'Yes. We provide mobile dry ice cleaning in ' . $n . ' from fully equipped Sprinter vans.';
	} elseif ( 'soon' === $t['tone'] ) {
		$serve = 'Not yet as a corporate service area. ' . $n . ' is one of our next franchise territories — contact us and we will confirm the nearest available service.';
	} else {
		$serve = 'Not yet. ' . $n . ' is part of our planned expansion — contact us to discuss availability.';
	}
	$lines = 'aerospace and defense, food processing, manufacturing, utilities and power plants, automotive restoration, boats and marinas, and fire restoration';
	return array(
		array( 'cat' => 'General', 'q' => 'Does Arctic Resto serve ' . $n . '?', 'a' => $serve ),
		array( 'cat' => 'General', 'q' => 'What services are available in ' . $n . '?', 'a' => ( $live ? 'All seven service lines: ' : 'When service begins, the same seven service lines will be available: ' ) . $lines . '.' ),
		array( 'cat' => 'General', 'q' => 'Is the service mobile?', 'a' => 'Yes. Our Mercedes Sprinter vans carry 900 lbs of dry ice, a compressor and industrial blasting equipment, so cleaning happens at your site and equipment rarely needs to move.' ),
		array( 'cat' => 'General', 'q' => 'How do I get a quote for ' . $n . '?', 'a' => 'Use the instant estimator for a ballpark in about a minute, or call or message us. Every job is quoted after a free assessment.' ),
		array( 'cat' => 'Franchise', 'q' => 'Can I own a franchise territory in ' . $n . '?', 'a' => $t['fr_answer'] . ' Franchise offerings are made only by disclosure document.' ),
	);
}

/** Widgets for one territory child page. */
function ar_demo_territory_child( $t, $i ) {
	$n    = $t['name'];
	$live = 'live' === $t['tone'];

	$portal = ar_demo_w(
		'ar_portal',
		array_merge(
			ar_demo_h( 'Franchise territory', 'Own the {{' . $n . '}} territory', $t['fr_text'], 'left' ),
			array(
				'features' => "Register for the franchise portal\nReview the opportunity and documents\nTrack your application and onboarding\nOwn your van and equipment 100%",
				'card_t'   => 'Arctic Resto Franchise Portal',
				'card_s'   => 'New here? Register. Already registered? Log in.',
				'b1_t'     => 'Register for the franchise portal',
				'b1_u'     => ar_demo_link( '' ),
				'b2_t'     => 'Franchise owner login',
				'b2_u'     => ar_demo_link( '' ),
				'note'     => 'Franchise offerings are made only by disclosure document.',
				'anchor'   => 'franchise',
				'theme'    => 'dark',
			)
		)
	);

	return array(
		'title'     => $n,
		'excerpt'   => $t['blurb'],
		'order'     => $i + 1,
		'thumb'     => $t['img'],
		'seo_title' => $t['seo_title'],
		'seo_desc'  => $t['seo_desc'],
		'meta'      => array(
			'_ar_terr_code'   => $t['code'],
			'_ar_terr_tone'   => $t['tone'],
			'_ar_terr_status' => $t['status'],
			'_ar_terr_blurb'  => $t['blurb'],
			'_ar_terr_areas'  => implode( "\n", $t['areas'] ),
			'_ar_terr_x'      => $t['x'],
			'_ar_terr_y'      => $t['y'],
		),
		'els'       => array(
			ar_demo_w(
				'ar_terr_hero',
				array(
					'title'    => '{{Mobile dry ice cleaning}} in [state]',
					'subtitle' => '[blurb]',
					'crumbs'   => 'yes',
					'b1_t'     => 'Get a free quote',
					'b1_u'     => ar_demo_link( '/estimator/' ),
				)
			),
			ar_demo_w(
				'ar_page_nav',
				array(
					'label' => 'On this page',
					'items' => array(
						array( 'label' => 'Overview', 'anchor' => 'overview' ),
						array( 'label' => $live ? 'Coverage' : 'Planned coverage', 'anchor' => 'coverage' ),
						array( 'label' => 'Services', 'anchor' => 'services' ),
						array( 'label' => 'Local guide', 'anchor' => 'guide' ),
						array( 'label' => 'Franchise', 'anchor' => 'franchise' ),
						array( 'label' => 'FAQ', 'anchor' => 'faq' ),
					),
					'b1_t'  => 'Get a quote',
					'b1_u'  => ar_demo_link( '/estimator/' ),
				)
			),
			ar_demo_w(
				'ar_answer',
				array(
					'question'    => $t['question'],
					'answer'      => $t['intro'],
					'updated'     => 'yes',
					'facts_title' => $n . ' at a glance',
					'facts'       => array_map(
						function ( $f ) {
							return array( 'label' => $f[0], 'value' => $f[1] );
						},
						$t['facts']
					),
					'b1_t'        => 'Get a free quote',
					'b1_u'        => ar_demo_link( '/estimator/' ),
					'b2_t'        => 'Contact us',
					'b2_u'        => ar_demo_link( '/contact/' ),
					'anchor'      => 'overview',
					'theme'       => 'frost',
					'pad'         => 'md',
				)
			),
			ar_demo_w(
				'ar_coverage',
				array(
					'eyebrow' => $live ? 'Coverage' : 'Planned coverage',
					'title'   => ( $live ? 'Where we work in ' : 'Planned coverage in ' ) . '{{[state]}}',
					'anchor'  => 'coverage',
					'theme'   => 'light',
				)
			),
			ar_demo_w(
				'ar_services',
				array_merge(
					ar_demo_h( 'Services', ( $live ? 'Dry ice cleaning services in ' : 'Services planned for ' ) . '{{' . $n . '}}', 'One method, seven service lines — no water, no chemicals, no secondary waste.' ),
					array( 'layout' => 'grid', 'count' => -1, 'anchor' => 'services', 'theme' => 'frost' )
				)
			),
			ar_demo_w(
				'ar_article',
				array_merge(
					ar_demo_h( 'Local guide', $t['guide_title'], '', 'left' ),
					array(
						'body'       => $t['guide'],
						'aside_t'    => 'Common jobs in ' . $n,
						'aside_list' => implode( "\n", $t['apps'] ),
						'b1_t'       => 'Get a free quote',
						'b1_u'       => ar_demo_link( '/estimator/' ),
						'anchor'     => 'guide',
						'theme'      => 'light',
					)
				)
			),
			$portal,
			ar_demo_w(
				'ar_faq',
				array_merge(
					ar_demo_h( 'FAQ', 'Questions about dry ice cleaning in {{' . $n . '}}' ),
					array( 'items' => ar_demo_territory_faqs( $t ), 'anchor' => 'faq', 'theme' => 'frost' )
				)
			),
			ar_demo_w(
				'ar_terr_cards',
				array_merge(
					ar_demo_h( 'Other territories', 'Explore our other {{territories}}' ),
					array( 'exclude' => 'yes', 'count' => -1, 'theme' => 'light' )
				)
			),
			ar_demo_cta( 'Ready to talk about ' . $n . '?', 'Get an instant estimate for a cleaning project, or register in the franchise portal to explore owning a territory.' ),
		),
	);
}

/** Main Territories page + all child pages, keyed by page path. */
function ar_demo_territory_pages() {
	$pages = array();

	$pages['territories'] = array(
		'title'     => 'Territories',
		'excerpt'   => 'Mobile dry ice cleaning across New Jersey and Connecticut, with franchise territories opening in Massachusetts and expansion into the Southeast planned.',
		'seo_title' => 'Service Areas & Franchise Territories | NJ, CT, MA & Southeast | Arctic Resto',
		'seo_desc'  => 'Arctic Resto serves New Jersey and Connecticut today, with franchise territories opening in Massachusetts and Southeast expansion planned. Explore each territory.',
		'els'       => array(
			ar_demo_hero( 'Territories', 'Serving {{NJ & CT}} — and growing.', 'Mobile dry ice cleaning across New Jersey and Connecticut, with franchise territories opening in Massachusetts and expansion into the Southeast planned.', 'hero-blast', 'Get a free quote', '/estimator/', 'Own a territory', '{portal-register}' ),
			ar_demo_w(
				'ar_page_nav',
				array(
					'label' => 'On this page',
					'items' => array(
						array( 'label' => 'Overview', 'anchor' => 'overview' ),
						array( 'label' => 'Interactive map', 'anchor' => 'map' ),
						array( 'label' => 'All territories', 'anchor' => 'territories' ),
						array( 'label' => 'Customers & owners', 'anchor' => 'paths' ),
						array( 'label' => 'FAQ', 'anchor' => 'faq' ),
					),
					'b1_t'  => 'Get a quote',
					'b1_u'  => ar_demo_link( '/estimator/' ),
				)
			),
			ar_demo_w(
				'ar_answer',
				array(
					'question'    => 'Where does Arctic Resto provide mobile dry ice cleaning?',
					'answer'      => 'Arctic Resto provides mobile dry ice cleaning across New Jersey and Connecticut today, with franchise territories opening in Massachusetts and expansion into the Southeast planned. Each territory below has its own page with coverage areas, services and next steps.',
					'updated'     => 'yes',
					'facts_title' => 'Territories at a glance',
					'facts'       => array(
						array( 'label' => 'Serving now', 'value' => 'Connecticut and New Jersey' ),
						array( 'label' => 'Opening', 'value' => 'Massachusetts franchise territories' ),
						array( 'label' => 'Planned', 'value' => 'Southeast USA' ),
						array( 'label' => 'Service type', 'value' => 'Mobile — the van comes to your site' ),
						array( 'label' => 'For owners', 'value' => 'Prime territories available beginning in Connecticut' ),
						array( 'label' => 'Not sure?', 'value' => 'Contact us and we will confirm coverage for your address' ),
					),
					'b1_t'        => 'Get a free quote',
					'b1_u'        => ar_demo_link( '/estimator/' ),
					'b2_t'        => 'Contact us',
					'b2_u'        => ar_demo_link( '/contact/' ),
					'anchor'      => 'overview',
					'theme'       => 'frost',
					'pad'         => 'md',
				)
			),
			ar_demo_w(
				'ar_territories',
				array_merge(
					ar_demo_h( 'Interactive map', 'Find your {{territory}}', 'Select a territory to see its status, coverage and next steps.' ),
					array( 'source' => 'pages', 'b1_t' => 'Get a quote', 'b1_u' => ar_demo_link( '/estimator/' ), 'b2_t' => 'Register for this territory', 'b2_u' => ar_demo_link( '{portal-register}' ), 'anchor' => 'map', 'theme' => 'void', 'pad' => 'lg' )
				)
			),
			ar_demo_w(
				'ar_terr_cards',
				array_merge(
					ar_demo_h( 'All territories', 'Choose a {{territory}} to learn more', 'Every territory has its own page with coverage areas, services, a local guide and FAQs.' ),
					array( 'count' => -1, 'anchor' => 'territories', 'theme' => 'frost' )
				)
			),
			ar_demo_w(
				'ar_icon_boxes',
				array_merge(
					ar_demo_h( 'Two ways to work with us', 'Which describes {{you}}?', 'Pick your path and we will take you straight to the right place.' ),
					array(
						'layout' => 'cards',
						'cols'   => '2',
						'theme'  => 'light',
						'anchor' => 'paths',
						'items'  => array(
							array( 'icon' => ar_demo_icon( 'fas fa-snowflake' ), 'title' => 'I need something cleaned', 'text' => 'Get an instant estimate, or contact us and we will confirm service for your address and schedule a free assessment.', 'link' => ar_demo_link( '/estimator/' ) ),
							array( 'icon' => ar_demo_icon( 'fas fa-handshake' ), 'title' => 'I want to own a territory', 'text' => 'Register in the franchise portal to review the opportunity, see available territories and start your application.', 'link' => ar_demo_link( '{portal-register}' ) ),
						),
					)
				)
			),
			ar_demo_w(
				'ar_faq',
				array_merge(
					ar_demo_h( 'FAQ', 'Territory {{questions}}' ),
					array(
						'anchor' => 'faq',
						'theme'  => 'frost',
						'items'  => array(
							array( 'cat' => 'General', 'q' => 'Where do you operate?', 'a' => 'We serve New Jersey and Connecticut today. Massachusetts franchise territories are opening and expansion into the Southeast is planned.' ),
							array( 'cat' => 'General', 'q' => 'Can I get service outside the listed areas?', 'a' => 'Contact us with your location. Availability depends on where our vans and franchise owners currently operate, and we will tell you the nearest option.' ),
							array( 'cat' => 'General', 'q' => 'What do the territory statuses mean?', 'a' => 'Serving now means active service today. Opening means franchise territories are being released. Planned means expansion is intended but territories have not been released.' ),
							array( 'cat' => 'Franchise', 'q' => 'How do I become an owner in a territory?', 'a' => 'Register in the franchise portal to review the opportunity and available territories. Franchise offerings are made only by disclosure document.' ),
						),
					)
				)
			),
			ar_demo_cta( 'Not sure which territory covers you?', 'Tell us your location and we will confirm coverage, availability and the best next step.' ),
		),
	);

	foreach ( ar_demo_territory_data() as $i => $t ) {
		$pages[ 'territories/' . $t['slug'] ] = ar_demo_territory_child( $t, $i );
	}
	return $pages;
}
