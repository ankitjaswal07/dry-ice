<?php
/**
 * Franchise portal integration.
 *
 * The portal itself is provided by your portal plugin. This theme only links to it:
 *   - Customizer fields for the Login, Register and Dashboard URLs
 *   - "Log in / Register" links in the top bar and the mobile menu
 *   - the [ar_portal_links] shortcode for use anywhere (widgets, posts, Elementor)
 *
 * Works with any plugin. Developers can also override every URL with filters:
 *   ar_portal_login_url, ar_portal_register_url, ar_portal_dashboard_url, ar_portal_links_html
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'customize_register',
	function ( $wp ) {
		$defs = array(
			'ar_portal_register' => array( __( 'Franchise portal – Register URL', 'arctic-resto' ), 'url', '', __( 'Where "Register" buttons go. Leave blank to use the portal URL above.', 'arctic-resto' ) ),
			'ar_portal_dash'     => array( __( 'Franchise portal – Dashboard URL', 'arctic-resto' ), 'url', '', __( 'Shown as "Dashboard" once a visitor is logged in.', 'arctic-resto' ) ),
			'ar_portal_label'    => array( __( 'Portal label in the top bar', 'arctic-resto' ), 'text', 'Franchise Portal', '' ),
		);
		foreach ( $defs as $id => $d ) {
			$wp->add_setting(
				$id,
				array(
					'default'           => $d[2],
					'sanitize_callback' => 'url' === $d[1] ? 'esc_url_raw' : 'sanitize_text_field',
				)
			);
			$wp->add_control(
				$id,
				array(
					'label'       => $d[0],
					'description' => $d[3],
					'section'     => 'ar_site',
					'type'        => $d[1],
				)
			);
		}

		$wp->add_setting(
			'ar_portal_state',
			array(
				'default'           => 'yes',
				'sanitize_callback' => function ( $v ) {
					return 'no' === $v ? 'no' : 'yes';
				},
			)
		);
		$wp->add_control(
			'ar_portal_state',
			array(
				'label'       => __( 'When a visitor is logged in', 'arctic-resto' ),
				'description' => __( 'Applies when a Dashboard URL is set. Note: administrators are logged in too, so they will see Dashboard / Log out.', 'arctic-resto' ),
				'section'     => 'ar_site',
				'type'        => 'select',
				'choices'     => array(
					'yes' => __( 'Show Dashboard + Log out', 'arctic-resto' ),
					'no'  => __( 'Always show Log in + Register', 'arctic-resto' ),
				),
			)
		);
	},
	20
);

/** True when a visitor is logged in and a dashboard destination exists. */
function ar_portal_state() {
	return is_user_logged_in() && 'no' !== get_theme_mod( 'ar_portal_state', 'yes' ) && '' !== ar_portal_dashboard_url();
}

/**
 * Portal links markup.
 *
 * @param string $ctx top (top bar) | drawer (mobile menu) | inline (shortcode / content).
 */
function ar_portal_links_html( $ctx = 'top' ) {
	$label = ar_mod( 'ar_portal_label', 'Franchise Portal' );
	if ( ar_portal_state() ) {
		$links = array(
			array( __( 'Dashboard', 'arctic-resto' ), ar_portal_dashboard_url(), true ),
			array( __( 'Log out', 'arctic-resto' ), wp_logout_url( home_url( '/' ) ), false ),
		);
	} else {
		$links = array(
			array( __( 'Log in', 'arctic-resto' ), ar_portal_login_url(), false ),
			array( __( 'Register', 'arctic-resto' ), ar_portal_register_url(), true ),
		);
	}

	$o = '<div class="ar-plinks ar-plinks--' . esc_attr( $ctx ) . '">';
	if ( 'drawer' === $ctx ) {
		$o .= '<p>' . ar_svg( 'lock' ) . esc_html( $label ) . '</p><div class="ar-plinks__btns">';
		foreach ( $links as $l ) {
			$o .= '<a class="ar-btn ar-btn--' . ( $l[2] ? 'primary' : 'ghost' ) . '" href="' . esc_url( $l[1] ) . '"><span>' . esc_html( $l[0] ) . '</span></a>';
		}
		$o .= '</div>';
	} else {
		$o .= '<span class="ar-plinks__lab">' . ar_svg( 'lock' ) . esc_html( $label ) . '</span>';
		foreach ( $links as $l ) {
			$o .= '<a class="ar-plinks__a' . ( $l[2] ? ' ar-plinks__a--reg' : '' ) . '" href="' . esc_url( $l[1] ) . '">' . esc_html( $l[0] ) . '</a>';
		}
	}
	$o .= '</div>';

	return apply_filters( 'ar_portal_links_html', $o, $ctx );
}

add_shortcode(
	'ar_portal_links',
	function ( $atts ) {
		$a = shortcode_atts( array( 'style' => 'inline' ), $atts, 'ar_portal_links' );
		return ar_portal_links_html( in_array( $a['style'], array( 'top', 'drawer', 'inline' ), true ) ? $a['style'] : 'inline' );
	}
);
