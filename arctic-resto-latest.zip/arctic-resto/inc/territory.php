<?php
/**
 * Territories = child pages of the "Territories" page.
 *
 * Each child page (Connecticut, New Jersey, …) is a normal WordPress page you edit with Elementor.
 * A "Territory details" box on the page holds the data used by the map, the cards and the
 * coverage widget, so it is entered once and shown everywhere.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_territory_parent_id() {
	$p = get_page_by_path( 'territories' );
	return $p ? (int) $p->ID : 0;
}

/** Published child pages of Territories, in menu order. */
function ar_get_territories( $args = array() ) {
	$pid = ar_territory_parent_id();
	if ( ! $pid ) {
		return array();
	}
	return get_posts(
		wp_parse_args(
			$args,
			array(
				'post_type'        => 'page',
				'post_parent'      => $pid,
				'post_status'      => 'publish',
				'posts_per_page'   => -1,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'suppress_filters' => false,
			)
		)
	);
}

function ar_is_territory( $id ) {
	$p   = get_post( $id );
	$par = ar_territory_parent_id();
	return $p && $par && 'page' === $p->post_type && (int) $p->post_parent === $par;
}

/** Normalised territory data for one page. */
function ar_terr_meta( $id ) {
	$get  = function ( $k, $d = '' ) use ( $id ) {
		$v = get_post_meta( $id, $k, true );
		return ( '' === $v || false === $v ) ? $d : $v;
	};
	$tone = $get( '_ar_terr_tone', 'live' );
	if ( ! in_array( $tone, array( 'live', 'soon', 'plan' ), true ) ) {
		$tone = 'live';
	}
	$default = array(
		'live' => __( 'Serving now', 'arctic-resto' ),
		'soon' => __( 'Opening soon', 'arctic-resto' ),
		'plan' => __( 'Planned expansion', 'arctic-resto' ),
	);
	$name    = get_the_title( $id );
	return array(
		'id'     => (int) $id,
		'name'   => $name,
		'code'   => strtoupper( (string) $get( '_ar_terr_code', substr( $name, 0, 2 ) ) ),
		'tone'   => $tone,
		'status' => $get( '_ar_terr_status', $default[ $tone ] ),
		'blurb'  => $get( '_ar_terr_blurb', '' ),
		'areas'  => ar_lines( $get( '_ar_terr_areas', '' ) ),
		'x'      => max( 5, min( 95, (float) $get( '_ar_terr_x', 50 ) ) ),
		'y'      => max( 8, min( 92, (float) $get( '_ar_terr_y', 50 ) ) ),
		'link'   => get_permalink( $id ),
	);
}

/**
 * Original vector graphic for a territory: a coordinate grid, coverage rings and a pulsing pin
 * positioned from the territory's map coordinates. Pure SVG — no image files, sharp at any size.
 */
function ar_territory_art( $m, $class = '' ) {
	static $n = 0;
	++$n;
	$cols = array(
		'live' => '#34d399',
		'soon' => '#fbbf24',
		'plan' => '#94a3b8',
	);
	$c    = isset( $cols[ $m['tone'] ] ) ? $cols[ $m['tone'] ] : '#45d6ff';
	$cx   = (int) round( $m['x'] * 4 );
	$cy   = (int) round( $m['y'] * 3 );
	$id   = 'artr' . $n;
	$seed = abs( crc32( $m['code'] . $m['name'] ) ) % 65537;
	$dots = '';
	for ( $i = 0; $i < 30; $i++ ) {
		$seed  = ( $seed * 75 + 74 ) % 65537;
		$dx    = $seed % 400;
		$seed  = ( $seed * 75 + 74 ) % 65537;
		$dy    = $seed % 300;
		$dots .= '<circle cx="' . $dx . '" cy="' . $dy . '" r="' . ( 1 + ( $i % 3 ) * 0.5 ) . '" fill="#fff" fill-opacity=".22"/>';
	}

	$svg  = '<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" focusable="false" aria-hidden="true">';
	$svg .= '<defs><pattern id="' . $id . 'g" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0V24" fill="none" stroke="#45d6ff" stroke-opacity=".12"/></pattern>';
	$svg .= '<radialGradient id="' . $id . 'r" cx="' . $cx . '" cy="' . $cy . '" r="230" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="' . $c . '" stop-opacity=".4"/><stop offset="1" stop-color="' . $c . '" stop-opacity="0"/></radialGradient></defs>';
	$svg .= '<rect width="400" height="300" fill="url(#' . $id . 'g)"/><rect width="400" height="300" fill="url(#' . $id . 'r)"/>';
	$svg .= '<text x="392" y="288" text-anchor="end" font-family="Sora,sans-serif" font-size="150" font-weight="800" fill="#fff" fill-opacity=".07">' . esc_html( $m['code'] ) . '</text>';
	$svg .= $dots;
	$svg .= '<g fill="none" stroke="' . $c . '">';
	$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="30" stroke-opacity=".55"/>';
	$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="64" stroke-opacity=".36"/>';
	$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="102" stroke-opacity=".24" stroke-dasharray="4 6"/>';
	$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="148" stroke-opacity=".13"/></g>';
	$svg .= '<circle class="ar-tart__pulse" cx="' . $cx . '" cy="' . $cy . '" r="13" fill="' . $c . '" fill-opacity=".45"/>';
	$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="7" fill="' . $c . '"/><circle cx="' . $cx . '" cy="' . $cy . '" r="3" fill="#061325"/>';
	$svg .= '</svg>';

	return '<span class="ar-tart ' . esc_attr( $class ) . '">' . $svg . '</span>';
}

/** Local-service schema node for a territory page. */
function ar_territory_node( $p, $url, $desc ) {
	$m     = ar_terr_meta( $p->ID );
	$areas = array( array( '@type' => 'AdministrativeArea', 'name' => $m['name'] ) );
	foreach ( $m['areas'] as $a ) {
		$areas[] = array( '@type' => 'AdministrativeArea', 'name' => $a );
	}
	return array(
		'@type'       => 'Service',
		'@id'         => $url . '#service',
		'name'        => sprintf( /* translators: %s territory name */ __( 'Mobile dry ice cleaning in %s', 'arctic-resto' ), $m['name'] ),
		'serviceType' => 'Dry ice cleaning',
		'description' => $desc,
		'url'         => $url,
		'provider'    => array( '@id' => home_url( '/#organization' ) ),
		'areaServed'  => $areas,
	);
}

/* ------------------------------------------------------------------ */
/* Meta box                                                            */
/* ------------------------------------------------------------------ */
add_action(
	'add_meta_boxes_page',
	function ( $post ) {
		if ( ar_is_territory( $post->ID ) || get_post_meta( $post->ID, '_ar_terr_code', true ) ) {
			add_meta_box( 'ar_terr', __( 'Territory details', 'arctic-resto' ), 'ar_terr_metabox', 'page', 'normal', 'high' );
		}
	}
);

function ar_terr_metabox( $post ) {
	wp_nonce_field( 'ar_terr', 'ar_terr_nonce' );
	$m = ar_terr_meta( $post->ID );
	echo '<p class="description">' . esc_html__( 'These details feed the territory map, the territory cards and the coverage list. Design the rest of the page with Elementor.', 'arctic-resto' ) . '</p>';
	echo '<table class="form-table" role="presentation"><tbody>';
	echo '<tr><th><label for="ar_terr_code">' . esc_html__( 'Short code', 'arctic-resto' ) . '</label></th><td><input id="ar_terr_code" class="small-text" type="text" maxlength="3" name="ar_terr_code" value="' . esc_attr( $m['code'] ) . '"> <span class="description">' . esc_html__( 'e.g. CT, NJ, MA', 'arctic-resto' ) . '</span></td></tr>';
	echo '<tr><th><label for="ar_terr_tone">' . esc_html__( 'Status colour', 'arctic-resto' ) . '</label></th><td><select id="ar_terr_tone" name="ar_terr_tone">';
	foreach ( array( 'live' => __( 'Serving now (green)', 'arctic-resto' ), 'soon' => __( 'Opening soon (amber)', 'arctic-resto' ), 'plan' => __( 'Planned (grey)', 'arctic-resto' ) ) as $k => $l ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( $m['tone'], $k, false ) . '>' . esc_html( $l ) . '</option>';
	}
	echo '</select></td></tr>';
	echo '<tr><th><label for="ar_terr_status">' . esc_html__( 'Status text', 'arctic-resto' ) . '</label></th><td><input id="ar_terr_status" class="regular-text" type="text" name="ar_terr_status" value="' . esc_attr( $m['status'] ) . '"></td></tr>';
	echo '<tr><th><label for="ar_terr_blurb">' . esc_html__( 'Short description', 'arctic-resto' ) . '</label></th><td><textarea id="ar_terr_blurb" class="large-text" rows="2" name="ar_terr_blurb">' . esc_textarea( $m['blurb'] ) . '</textarea></td></tr>';
	echo '<tr><th><label for="ar_terr_areas">' . esc_html__( 'Coverage areas', 'arctic-resto' ) . '</label></th><td><textarea id="ar_terr_areas" class="large-text" rows="6" name="ar_terr_areas">' . esc_textarea( implode( "\n", $m['areas'] ) ) . '</textarea><p class="description">' . esc_html__( 'One per line — counties, cities or regions.', 'arctic-resto' ) . '</p></td></tr>';
	echo '<tr><th>' . esc_html__( 'Map position (%)', 'arctic-resto' ) . '</th><td>X <input class="small-text" type="number" min="5" max="95" step="1" name="ar_terr_x" value="' . esc_attr( $m['x'] ) . '"> &nbsp; Y <input class="small-text" type="number" min="8" max="92" step="1" name="ar_terr_y" value="' . esc_attr( $m['y'] ) . '"> <span class="description">' . esc_html__( '0 = left/top, 100 = right/bottom of the stylised map.', 'arctic-resto' ) . '</span></td></tr>';
	echo '</tbody></table>';
	echo '<p class="description">' . esc_html__( 'The featured image is used as the territory photo on cards and in the page hero.', 'arctic-resto' ) . '</p>';
}

add_action(
	'save_post_page',
	function ( $post_id ) {
		if ( ! isset( $_POST['ar_terr_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ar_terr_nonce'] ) ), 'ar_terr' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$tone = isset( $_POST['ar_terr_tone'] ) ? sanitize_key( wp_unslash( $_POST['ar_terr_tone'] ) ) : 'live';
		update_post_meta( $post_id, '_ar_terr_tone', in_array( $tone, array( 'live', 'soon', 'plan' ), true ) ? $tone : 'live' );
		update_post_meta( $post_id, '_ar_terr_code', isset( $_POST['ar_terr_code'] ) ? strtoupper( substr( sanitize_text_field( wp_unslash( $_POST['ar_terr_code'] ) ), 0, 3 ) ) : '' );
		update_post_meta( $post_id, '_ar_terr_status', isset( $_POST['ar_terr_status'] ) ? sanitize_text_field( wp_unslash( $_POST['ar_terr_status'] ) ) : '' );
		update_post_meta( $post_id, '_ar_terr_blurb', isset( $_POST['ar_terr_blurb'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ar_terr_blurb'] ) ) : '' );
		update_post_meta( $post_id, '_ar_terr_areas', isset( $_POST['ar_terr_areas'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ar_terr_areas'] ) ) : '' );
		update_post_meta( $post_id, '_ar_terr_x', isset( $_POST['ar_terr_x'] ) ? max( 5, min( 95, (float) $_POST['ar_terr_x'] ) ) : 50 );
		update_post_meta( $post_id, '_ar_terr_y', isset( $_POST['ar_terr_y'] ) ? max( 8, min( 92, (float) $_POST['ar_terr_y'] ) ) : 50 );
	}
);
