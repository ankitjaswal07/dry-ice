<?php
/**
 * Territory widgets: hero, coverage list and territory cards.
 * They read the "Territory details" of the page they are placed on (or of the child pages).
 * Placeholders usable in text fields: [state] [code] [status] [blurb]
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_terr_fill( $text, $m ) {
	return strtr(
		(string) $text,
		array(
			'[state]'  => $m['name'],
			'[code]'   => $m['code'],
			'[status]' => $m['status'],
			'[blurb]'  => $m['blurb'],
		)
	);
}

function ar_terr_current() {
	$id = get_the_ID();
	if ( ! $id ) {
		$id = get_queried_object_id();
	}
	return \ar_terr_meta( $id );
}

/* ------------------------------------------------------------------ */
class W_TerrHero extends Base {
	protected $ico = 'eicon-banner';

	public function get_name() {
		return 'ar_terr_hero';
	}
	public function get_title() {
		return __( 'AR Territory Hero', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Content',
			array(
				'title'    => array( 'l' => 'Title', 't' => 'area', 'rows' => 2, 'd' => '{{Mobile dry ice cleaning}} in [state]', 'desc' => 'Placeholders: [state] [code] [status] [blurb]. Wrap words in {{double braces}} for gradient text.' ),
				'subtitle' => array( 'l' => 'Subtitle', 't' => 'area', 'd' => '[blurb]' ),
				'crumbs'   => array( 'l' => 'Show breadcrumbs', 't' => 'switch', 'd' => 'yes' ),
				'b1_t'     => array( 'l' => 'Primary button text', 'd' => 'Get a free quote' ),
				'b1_u'     => array( 'l' => 'Primary button link (blank = estimator)', 't' => 'url' ),
				'b2_t'     => array( 'l' => 'Secondary button text (blank = automatic)', 'd' => '' ),
				'b2_u'     => array( 'l' => 'Secondary button link (blank = automatic)', 't' => 'url' ),
				'bg'       => array( 'l' => 'Background image (blank = featured image)', 't' => 'media' ),
			)
		);
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$m    = ar_terr_current();
		$live = 'live' === $m['tone'];
		$l1   = ! empty( $s['b1_u']['url'] ) ? $s['b1_u'] : array( 'url' => '/estimator/' );
		$l2   = ! empty( $s['b2_u']['url'] ) ? $s['b2_u'] : array( 'url' => $live ? '/services/' : '{portal-register}' );
		$t2   = $s['b2_t'] ? $s['b2_t'] : ( $live ? __( 'Explore services', 'arctic-resto' ) : __( 'Register for this territory', 'arctic-resto' ) );
		$attr = array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => '' );
		$bg   = '';
		if ( ! empty( $s['bg']['url'] ) ) {
			$bg = ar_media( $s['bg'], 'ar-hero', $attr );
		} elseif ( has_post_thumbnail( $m['id'] ) ) {
			$bg = get_the_post_thumbnail( $m['id'], 'ar-hero', $attr );
		}
		?>
		<section class="ar-sec ar-phero ar-thero ar-t-void">
			<?php if ( $bg ) : ?><div class="ar-hero__bg"><?php echo $bg; // phpcs:ignore ?></div><?php endif; ?>
			<div class="ar-hero__shade"></div><div class="ar-hero__grid"></div>
			<i class="ar-fog ar-fog--1" aria-hidden="true"></i><i class="ar-fog ar-fog--2" aria-hidden="true"></i>
			<div class="ar-particles" data-ar-particles></div>
			<div class="ar-wrap ar-thero__inner">
				<div class="ar-thero__copy">
					<?php if ( 'yes' === $s['crumbs'] ) { echo ar_breadcrumbs(); } // phpcs:ignore ?>
					<span class="ar-status ar-status--<?php echo esc_attr( $m['tone'] ); ?>"><?php echo esc_html( $m['status'] ); ?></span>
					<h1 class="ar-phero__title"><?php echo ar_title( ar_terr_fill( $s['title'], $m ) ); // phpcs:ignore ?></h1>
					<?php if ( $s['subtitle'] ) : ?><p class="ar-phero__sub"><?php echo esc_html( ar_terr_fill( $s['subtitle'], $m ) ); ?></p><?php endif; ?>
					<div class="ar-actions"><?php echo ar_btn( $l1, $s['b1_t'], 'primary' ); // phpcs:ignore ?><?php echo ar_btn( $l2, $t2, 'ghost', false ); // phpcs:ignore ?></div>
				</div>
				<div class="ar-thero__art ar-glass">
					<?php echo ar_territory_art( $m ); // phpcs:ignore ?>
					<div class="ar-thero__meta">
						<div><b><?php echo esc_html( $m['code'] ); ?></b><small><?php esc_html_e( 'Territory', 'arctic-resto' ); ?></small></div>
						<div><b><?php echo (int) count( $m['areas'] ); ?></b><small><?php echo $live ? esc_html__( 'Coverage areas', 'arctic-resto' ) : esc_html__( 'Planned areas', 'arctic-resto' ); ?></small></div>
						<div><b><?php echo (int) count( \ar_get_services() ); ?></b><small><?php esc_html_e( 'Service lines', 'arctic-resto' ); ?></small></div>
						<div><b>0</b><small><?php esc_html_e( 'Water or chemicals', 'arctic-resto' ); ?></small></div>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
}

/* ------------------------------------------------------------------ */
class W_Coverage extends Base {
	protected $ico = 'eicon-map-pin';

	public function get_name() {
		return 'ar_coverage';
	}
	public function get_title() {
		return __( 'AR Coverage Areas', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Coverage', 'Where we work in {{[state]}}', '', 'left' );
		$this->section(
			'c1',
			'Side card',
			array(
				'side_t' => array( 'l' => 'Title', 'd' => 'Not sure your address is covered?' ),
				'side_s' => array( 'l' => 'Text', 't' => 'area', 'd' => 'Tell us your location and we will confirm coverage and scheduling — usually the same day.' ),
				'b1_t'   => array( 'l' => 'Button text', 'd' => 'Check my address' ),
				'b1_u'   => array( 'l' => 'Button link (blank = contact page)', 't' => 'url' ),
			)
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$m = ar_terr_current();
		foreach ( array( 'eyebrow', 'title', 'subtitle' ) as $k ) {
			$s[ $k ] = ar_terr_fill( $s[ $k ], $m );
		}
		$l1 = ! empty( $s['b1_u']['url'] ) ? $s['b1_u'] : array( 'url' => '/contact/' );
		$this->open( $s, 'ar-covsec' );
		$this->heading( $s, 'left' );
		echo '<div class="ar-cov"><div class="ar-cov__grid">';
		if ( $m['areas'] ) {
			foreach ( $m['areas'] as $i => $a ) {
				echo '<div class="ar-cov__i"' . ar_rv( $i % 6 ) . '><span class="ar-ico">' . ar_svg( 'pin' ) . '</span><span>' . esc_html( $a ) . '</span></div>'; // phpcs:ignore
			}
		} else {
			echo '<p class="ar-empty">' . esc_html__( 'Add coverage areas in the "Territory details" box of this page.', 'arctic-resto' ) . '</p>';
		}
		echo '</div><aside class="ar-cov__side"' . ar_rv( 1, 'right' ) . '>' . ar_territory_art( $m ) . '<div><h3>' . esc_html( $s['side_t'] ) . '</h3><p>' . esc_html( $s['side_s'] ) . '</p>'; // phpcs:ignore
		echo '<div class="ar-actions">' . ar_btn( $l1, $s['b1_t'], 'primary' ) . '<a class="ar-btn ar-btn--ghost" href="' . esc_url( ar_phone_href() ) . '">' . ar_svg( 'phone' ) . '<span>' . esc_html( ar_phone() ) . '</span></a></div></div></aside></div>'; // phpcs:ignore
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_TerrCards extends Base {
	protected $ico = 'eicon-posts-grid';

	public function get_name() {
		return 'ar_terr_cards';
	}
	public function get_title() {
		return __( 'AR Territory Cards (dynamic)', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Territories', 'Explore our {{territories}}', '' );
		$this->section(
			'c1',
			'Query',
			array(
				'count'   => array( 'l' => 'Number of territories (-1 = all)', 't' => 'num', 'd' => -1, 'min' => -1, 'max' => 24 ),
				'exclude' => array( 'l' => 'Exclude the current page', 't' => 'switch', 'd' => '' ),
			)
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = array( 'posts_per_page' => (int) $s['count'] );
		if ( 'yes' === $s['exclude'] && get_the_ID() ) {
			$args['post__not_in'] = array( get_the_ID() );
		}
		$list = \ar_get_territories( $args );
		$this->open( $s, 'ar-tcardsec' );
		$this->heading( $s );
		if ( ! $list ) {
			echo '<p class="ar-empty">' . esc_html__( 'No territories yet. Create child pages of the Territories page, or run the demo importer.', 'arctic-resto' ) . '</p>';
			$this->close();
			return;
		}
		echo '<div class="ar-tcards">';
		foreach ( $list as $i => $p ) {
			$m     = \ar_terr_meta( $p->ID );
			$thumb = get_the_post_thumbnail( $p->ID, 'ar-card', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ) );
			echo '<a class="ar-card ar-tcard" href="' . esc_url( $m['link'] ) . '" data-ar-tilt' . ar_rv( $i % 4 ) . '>'; // phpcs:ignore
			echo '<span class="ar-tcard__media">' . $thumb . ar_territory_art( $m ) . '<span class="ar-tcard__shade"></span><span class="ar-status ar-status--' . esc_attr( $m['tone'] ) . '">' . esc_html( $m['status'] ) . '</span><span class="ar-tcard__code">' . esc_html( $m['code'] ) . '</span></span>'; // phpcs:ignore
			echo '<span class="ar-tcard__body"><strong>' . esc_html( $m['name'] ) . '</strong><em>' . esc_html( $m['blurb'] ) . '</em>';
			echo '<span class="ar-tcard__meta"><i>' . ar_svg( 'pin' ) . esc_html( sprintf( /* translators: %d number of areas */ _n( '%d area', '%d areas', count( $m['areas'] ), 'arctic-resto' ), count( $m['areas'] ) ) ) . '</i><i>' . ar_svg( 'check' ) . esc_html__( 'All services', 'arctic-resto' ) . '</i></span>'; // phpcs:ignore
			echo '<span class="ar-link">' . esc_html__( 'Explore territory', 'arctic-resto' ) . ' ' . ar_svg( 'arrow' ) . '</span></span></a>'; // phpcs:ignore
		}
		echo '</div>';
		$this->close();
	}
}
