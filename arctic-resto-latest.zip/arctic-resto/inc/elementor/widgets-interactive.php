<?php
/**
 * Interactive widgets.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
class W_BeforeAfter extends Base {
	protected $ico = 'eicon-image-before-after';

	public function get_name() {
		return 'ar_before_after';
	}
	public function get_title() {
		return __( 'AR Before / After Slider', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Results you can see', 'Drag to reveal the {{clean}}', '' );
		$this->rep(
			'items',
			'Comparisons',
			array(
				'label'  => array( 'l' => 'Tab label', 'd' => 'Engine restoration' ),
				'after'  => array( 'l' => 'After (clean) image', 't' => 'media' ),
				'before' => array( 'l' => 'Before (dirty) image – optional', 't' => 'media', 'desc' => 'Leave empty to auto-generate a dirty look from the After image.' ),
			),
			array(),
			'label'
		);
		$this->section( 'c2', 'Note', array( 'note' => array( 'l' => 'Caption', 'd' => 'Illustrative demo comparison.' ) ) );
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->items( $s );
		$this->open( $s, 'ar-basec' );
		$this->heading( $s );
		echo '<div class="ar-bawrap" data-ar-batabs' . ar_rv( 1, 'zoom' ) . '>'; // phpcs:ignore
		if ( count( $items ) > 1 ) {
			echo '<div class="ar-tabs" role="tablist">';
			foreach ( $items as $i => $it ) {
				echo '<button type="button" role="tab" class="' . ( 0 === $i ? 'is-active' : '' ) . '" data-tab="' . (int) $i . '">' . esc_html( $it['label'] ) . '</button>';
			}
			echo '</div>';
		}
		foreach ( $items as $i => $it ) {
			$real = ! empty( $it['before']['url'] );
			echo '<div class="ar-bapanel' . ( 0 === $i ? ' is-active' : '' ) . '"><div class="ar-ba' . ( $real ? ' ar-ba--real' : '' ) . '" data-ar-ba tabindex="0" role="slider" aria-label="' . esc_attr__( 'Before and after comparison', 'arctic-resto' ) . '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50">'; // phpcs:ignore
			echo ar_media( $it['after'], 'large', array( 'class' => 'ar-ba__after', 'draggable' => 'false', 'alt' => $it['label'] ) ); // phpcs:ignore
			echo '<div class="ar-ba__before">' . ar_media( $real ? $it['before'] : $it['after'], 'large', array( 'class' => 'ar-ba__bimg', 'draggable' => 'false', 'alt' => '' ) ) . ( $real ? '' : '<i class="ar-ba__dirt"></i>' ) . '</div>'; // phpcs:ignore
			echo '<span class="ar-ba__lab ar-ba__lab--b">' . esc_html__( 'Before', 'arctic-resto' ) . '</span><span class="ar-ba__lab ar-ba__lab--a">' . esc_html__( 'After', 'arctic-resto' ) . '</span>';
			echo '<div class="ar-ba__handle"><b>' . ar_svg( 'drag' ) . '</b></div></div></div>'; // phpcs:ignore
		}
		echo '</div>';
		if ( $s['note'] ) {
			echo '<p class="ar-note">' . esc_html( $s['note'] ) . '</p>';
		}
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Faq extends Base {
	protected $ico = 'eicon-accordion';

	public function get_name() {
		return 'ar_faq';
	}
	public function get_title() {
		return __( 'AR FAQ Accordion', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'FAQ', 'Common {{questions}}', '' );
		$this->section(
			'c1',
			'Options',
			array(
				'search'  => array( 'l' => 'Show search box', 't' => 'switch', 'd' => '' ),
				'filters' => array( 'l' => 'Show category chips', 't' => 'switch', 'd' => '' ),
				'width'   => array( 'l' => 'Width', 't' => 'select', 'd' => 'narrow', 'o' => array( 'narrow' => 'Narrow (centered)', 'full' => 'Full width' ) ),
				'schema'  => array( 'l' => 'Output FAQ schema for Google', 't' => 'switch', 'd' => 'yes' ),
			)
		);
		$this->rep(
			'items',
			'Questions',
			array(
				'q'   => array( 'l' => 'Question', 'd' => 'Question?' ),
				'a'   => array( 'l' => 'Answer', 't' => 'area', 'rows' => 4, 'd' => 'Answer.' ),
				'cat' => array( 'l' => 'Category', 'd' => 'General' ),
			),
			array( array( 'q' => 'What is dry ice cleaning?', 'a' => 'Dry ice cleaning uses solid CO₂ pellets…' ) ),
			'q'
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->items( $s );
		$cats  = array();
		foreach ( $items as $it ) {
			$cats[ $it['cat'] ] = true;
		}
		$this->open( $s, 'ar-faqsec' );
		$this->heading( $s );
		echo '<div class="ar-faq ar-faq--' . esc_attr( $s['width'] ) . '" data-ar-faq' . ar_rv( 1 ) . '>'; // phpcs:ignore
		if ( 'yes' === $s['search'] || ( 'yes' === $s['filters'] && count( $cats ) > 1 ) ) {
			echo '<div class="ar-faq__tools">';
			if ( 'yes' === $s['search'] ) {
				echo '<label class="ar-search">' . ar_svg( 'search' ) . '<input type="search" placeholder="' . esc_attr__( 'Search questions…', 'arctic-resto' ) . '" data-faq-search></label>'; // phpcs:ignore
			}
			if ( 'yes' === $s['filters'] && count( $cats ) > 1 ) {
				echo '<div class="ar-chips"><button type="button" class="is-active" data-cat="all">' . esc_html__( 'All', 'arctic-resto' ) . '</button>';
				foreach ( array_keys( $cats ) as $c ) {
					echo '<button type="button" data-cat="' . esc_attr( $c ) . '">' . esc_html( $c ) . '</button>';
				}
				echo '</div>';
			}
			echo '</div>';
		}
		echo '<div class="ar-acc">';
		foreach ( $items as $i => $it ) {
			echo '<div class="ar-acc__i' . ( 0 === $i ? ' is-open' : '' ) . '" data-cat="' . esc_attr( $it['cat'] ) . '"><button type="button" class="ar-acc__q" aria-expanded="' . ( 0 === $i ? 'true' : 'false' ) . '"><span>' . esc_html( $it['q'] ) . '</span><i>' . ar_svg( 'chev' ) . '</i></button><div class="ar-acc__a"><div><p>' . esc_html( $it['a'] ) . '</p></div></div></div>'; // phpcs:ignore
		}
		echo '</div><p class="ar-empty" hidden>' . esc_html__( 'No questions match your search.', 'arctic-resto' ) . '</p></div>';
		$this->close();

		if ( 'yes' === $s['schema'] && $items ) {
			$ents = array();
			foreach ( $items as $it ) {
				$ents[] = array(
					'@type'          => 'Question',
					'name'           => $it['q'],
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $it['a'] ),
				);
			}
			ar_json_ld(
				array(
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'mainEntity' => $ents,
				)
			);
		}
	}
}

/* ------------------------------------------------------------------ */
class W_Calculator extends Base {
	protected $ico = 'eicon-calculator';

	public function get_name() {
		return 'ar_calculator';
	}
	public function get_title() {
		return __( 'AR Revenue Calculator', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Explore the model', 'Play with the {{numbers}}', 'Adjust the sliders to see how job volume and ticket size could scale a single van.' );
		$this->section(
			'c1',
			'Defaults',
			array(
				'jobs'       => array( 'l' => 'Jobs per week', 't' => 'num', 'd' => 8, 'min' => 1, 'max' => 20 ),
				'ticket'     => array( 'l' => 'Average job ticket ($)', 't' => 'num', 'd' => 900, 'min' => 300, 'max' => 3000 ),
				'weeks'      => array( 'l' => 'Working weeks / year', 't' => 'num', 'd' => 46, 'min' => 20, 'max' => 52 ),
				'disclaimer' => array( 'l' => 'Disclaimer', 't' => 'area', 'd' => 'Interactive demo only. This is not a financial performance representation or earnings claim. Actual results vary. See the Franchise Disclosure Document.' ),
			)
		);
		$this->style_controls( 'dark', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-calcsec' );
		$this->heading( $s );
		$rows = array(
			array( 'jobs', __( 'Jobs per week', 'arctic-resto' ), 1, 20, 1, '', (int) $s['jobs'] ),
			array( 'ticket', __( 'Average job ticket', 'arctic-resto' ), 300, 3000, 50, '$', (int) $s['ticket'] ),
			array( 'weeks', __( 'Working weeks / year', 'arctic-resto' ), 20, 52, 1, '', (int) $s['weeks'] ),
		);
		echo '<div class="ar-calc ar-glass" data-ar-calc' . ar_rv( 1 ) . '><div class="ar-calc__ctl">'; // phpcs:ignore
		foreach ( $rows as $r ) {
			echo '<div><div class="ar-calc__row"><span>' . esc_html( $r[1] ) . '</span><b data-out="' . esc_attr( $r[0] ) . '" data-fmt="' . esc_attr( $r[5] ) . '"></b></div><input type="range" name="' . esc_attr( $r[0] ) . '" min="' . (int) $r[2] . '" max="' . (int) $r[3] . '" step="' . (int) $r[4] . '" value="' . (int) $r[6] . '" aria-label="' . esc_attr( $r[1] ) . '"></div>';
		}
		echo '</div><div class="ar-calc__res"><small>' . esc_html__( 'Illustrative gross revenue / year', 'arctic-resto' ) . '</small><b data-total>$0</b><p>' . esc_html( $s['disclaimer'] ) . '</p></div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Territories extends Base {
	protected $ico = 'eicon-map-pin';

	public function get_name() {
		return 'ar_territories';
	}
	public function get_title() {
		return __( 'AR Territory Map', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Territories', 'Serving {{NJ & CT}} — and growing.', '' );
		$this->section(
			'c1',
			'Source & buttons',
			array(
				'source' => array( 'l' => 'Territories come from', 't' => 'select', 'd' => 'pages', 'o' => array( 'pages' => 'Child pages of Territories (recommended)', 'manual' => 'The manual list below' ) ),
				'b1_t' => array( 'l' => 'Primary button text', 'd' => 'Get a quote' ),
				'b1_u' => array( 'l' => 'Primary button link', 't' => 'url' ),
				'b2_t' => array( 'l' => 'Button for non-live territories', 'd' => 'Claim territory' ),
				'b2_u' => array( 'l' => 'Link', 't' => 'url' ),
			)
		);
		$this->rep(
			'items',
			'Territories',
			array(
				'code'  => array( 'l' => 'Code', 'd' => 'CT' ),
				'name'  => array( 'l' => 'Name', 'd' => 'Connecticut' ),
				'tone'  => array( 'l' => 'Status colour', 't' => 'select', 'd' => 'live', 'o' => array( 'live' => 'Serving now (green)', 'soon' => 'Opening (amber)', 'plan' => 'Planned (grey)' ) ),
				'status' => array( 'l' => 'Status text', 'd' => 'Serving now' ),
				'blurb' => array( 'l' => 'Description', 't' => 'area', 'd' => '' ),
				'areas' => array( 'l' => 'Coverage (one per line)', 't' => 'area', 'rows' => 5, 'd' => '' ),
				'x'     => array( 'l' => 'Map X position (%)', 't' => 'num', 'd' => 50, 'min' => 5, 'max' => 95 ),
				'y'     => array( 'l' => 'Map Y position (%)', 't' => 'num', 'd' => 50, 'min' => 5, 'max' => 90 ),
			),
			array( array( 'name' => 'Connecticut' ) ),
			'name'
		);
		$this->style_controls( 'void', 'lg' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->items( $s );
		if ( 'manual' !== $s['source'] ) {
			$pages = ar_get_territories();
			if ( $pages ) {
				$items = array();
				foreach ( $pages as $tp ) {
					$tm      = ar_terr_meta( $tp->ID );
					$items[] = array(
						'code'   => $tm['code'],
						'name'   => $tm['name'],
						'tone'   => $tm['tone'],
						'status' => $tm['status'],
						'blurb'  => $tm['blurb'],
						'areas'  => implode( "\n", $tm['areas'] ),
						'x'      => $tm['x'],
						'y'      => $tm['y'],
						'link'   => $tm['link'],
					);
				}
			}
		}
		$this->open( $s, 'ar-terr' );
		$this->heading( $s );
		echo '<div class="ar-terr__grid" data-ar-terr>';
		echo '<div class="ar-glass ar-map"' . ar_rv( 0, 'left' ) . '><span class="ar-map__lab">' . esc_html__( 'Stylized map', 'arctic-resto' ) . '</span><svg class="ar-map__lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">'; // phpcs:ignore
		foreach ( $items as $i => $it ) {
			if ( $i ) {
				$p = $items[ $i - 1 ];
				echo '<line x1="' . (float) $p['x'] . '" y1="' . (float) $p['y'] . '" x2="' . (float) $it['x'] . '" y2="' . (float) $it['y'] . '" stroke="rgba(69,214,255,.3)" stroke-width=".3" stroke-dasharray="1.5 1.5"/>';
			}
		}
		echo '</svg>';
		foreach ( $items as $i => $it ) {
			echo '<button type="button" class="ar-pin' . ( 0 === $i ? ' is-active' : '' ) . '" data-i="' . (int) $i . '" style="left:' . (float) $it['x'] . '%;top:' . (float) $it['y'] . '%" aria-label="' . esc_attr( $it['name'] ) . '"><b>' . esc_html( $it['code'] ) . '</b><small>' . esc_html( $it['name'] ) . '</small></button>';
		}
		echo '<div class="ar-map__leg"><span class="live">' . esc_html__( 'Serving now', 'arctic-resto' ) . '</span><span class="soon">' . esc_html__( 'Opening', 'arctic-resto' ) . '</span><span class="plan">' . esc_html__( 'Planned', 'arctic-resto' ) . '</span></div></div>';
		echo '<div class="ar-terr__side"' . ar_rv( 1, 'right' ) . '>'; // phpcs:ignore
		foreach ( $items as $i => $it ) {
			echo '<div class="ar-glass ar-tpanel' . ( 0 === $i ? ' is-active' : '' ) . '" data-i="' . (int) $i . '"><span class="ar-status ar-status--' . esc_attr( $it['tone'] ) . '">' . esc_html( $it['status'] ) . '</span><h3>' . esc_html( $it['name'] ) . '</h3><p>' . esc_html( $it['blurb'] ) . '</p><h4>' . esc_html__( 'Coverage', 'arctic-resto' ) . '</h4><div class="ar-areas">'; // phpcs:ignore
			foreach ( ar_lines( $it['areas'] ) as $a ) {
				echo '<span>' . ar_svg( 'pin' ) . esc_html( $a ) . '</span>'; // phpcs:ignore
			}
			echo '</div><div class="ar-actions">' . ( ! empty( $it['link'] ) ? ar_btn( array( 'url' => $it['link'] ), sprintf( /* translators: %s territory name */ __( 'Explore %s', 'arctic-resto' ), $it['name'] ), 'primary' ) : '' ) . ar_btn( $s['b1_u'], $s['b1_t'], 'ghost', false ) . ( 'live' !== $it['tone'] ? ar_btn( $s['b2_u'], $s['b2_t'], 'ghost', false ) : '' ) . '</div></div>'; // phpcs:ignore
		}
		echo '<div class="ar-tabsq">';
		foreach ( $items as $i => $it ) {
			echo '<button type="button" class="' . ( 0 === $i ? 'is-active' : '' ) . '" data-i="' . (int) $i . '">' . esc_html( $it['code'] ) . '</button>';
		}
		echo '</div></div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Gallery extends Base {
	protected $ico = 'eicon-gallery-justified';

	public function get_name() {
		return 'ar_gallery';
	}
	public function get_title() {
		return __( 'AR Filterable Gallery', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls();
		$this->rep(
			'items',
			'Images',
			array(
				'image' => array( 'l' => 'Image', 't' => 'media' ),
				'title' => array( 'l' => 'Caption', 'd' => 'Project' ),
				'cat'   => array( 'l' => 'Category', 'd' => 'General' ),
			),
			array(),
			'title'
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->items( $s );
		$cats  = array();
		foreach ( $items as $it ) {
			$cats[ $it['cat'] ] = true;
		}
		$this->open( $s, 'ar-gallerysec' );
		$this->heading( $s );
		echo '<div data-ar-gallery><div class="ar-chips ar-chips--c"><button type="button" class="is-active" data-cat="all">' . esc_html__( 'All projects', 'arctic-resto' ) . '</button>';
		foreach ( array_keys( $cats ) as $c ) {
			echo '<button type="button" data-cat="' . esc_attr( $c ) . '">' . esc_html( $c ) . '</button>';
		}
		echo '</div><div class="ar-masonry">';
		foreach ( $items as $i => $it ) {
			$full = ! empty( $it['image']['id'] ) ? wp_get_attachment_image_url( (int) $it['image']['id'], 'ar-hero' ) : ( isset( $it['image']['url'] ) ? $it['image']['url'] : '' );
			echo '<button type="button" class="ar-gi" data-cat="' . esc_attr( $it['cat'] ) . '" data-src="' . esc_url( $full ) . '" data-title="' . esc_attr( $it['title'] ) . '">' . ar_media( $it['image'], 'medium_large', array( 'alt' => $it['title'] ) ) . '<span>' . esc_html( $it['title'] ) . ar_svg( 'expand' ) . '</span></button>'; // phpcs:ignore
		}
		echo '</div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Science extends Base {
	protected $ico = 'eicon-tabs';

	public function get_name() {
		return 'ar_science';
	}
	public function get_title() {
		return __( 'AR Science Tabs + Animation', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'The science', 'Three forces. {{One clean surface.}}', '', 'left' );
		$this->rep(
			'items',
			'Forces',
			array(
				'icon'  => array( 'l' => 'Icon', 't' => 'icon', 'd' => array( 'value' => 'fas fa-bolt', 'library' => 'fa-solid' ) ),
				'title' => array( 'l' => 'Title', 'd' => 'Kinetic energy' ),
				'tag'   => array( 'l' => 'Tag', 'd' => 'Impact' ),
				'text'  => array( 'l' => 'Text', 't' => 'area', 'd' => '' ),
			),
			array( array( 'title' => 'Kinetic energy' ) )
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-scisec' );
		echo '<div class="ar-sci"><div data-ar-tabs>';
		$this->heading( $s, 'left' );
		echo '<div class="ar-sci__tabs">';
		foreach ( $this->items( $s ) as $i => $it ) {
			echo '<button type="button" class="ar-sci__tab' . ( 0 === $i ? ' is-active' : '' ) . '"' . ar_rv( $i ) . '><span class="ar-ico">' . ar_icon( $it['icon'] ) . '</span><span><span class="ar-sci__h"><b>' . esc_html( $it['title'] ) . '</b><i>' . esc_html( $it['tag'] ) . '</i></span><em>' . esc_html( $it['text'] ) . '</em></span></button>'; // phpcs:ignore
		}
		echo '</div></div><div class="ar-sci__vis"' . ar_rv( 1, 'right' ) . '><div class="ar-diagram" aria-hidden="true"><span class="ar-diagram__lab">' . esc_html__( 'Live simulation', 'arctic-resto' ) . '</span><div class="ar-nozzle"></div>'; // phpcs:ignore
		for ( $n = 0; $n < 7; $n++ ) {
			echo '<i class="ar-pellet" style="top:calc(50% + ' . ( ( $n - 3 ) * 6 ) . 'px);animation-delay:' . ( $n * 0.18 ) . 's"></i>';
		}
		echo '<div class="ar-wall"><i></i></div>';
		for ( $n = 0; $n < 3; $n++ ) {
			echo '<i class="ar-puff" style="animation-delay:' . ( $n * 0.45 ) . 's"></i>';
		}
		echo '</div></div></div>';
		$this->close();
	}
}
