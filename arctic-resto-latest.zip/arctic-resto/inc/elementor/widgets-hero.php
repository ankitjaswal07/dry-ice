<?php
/**
 * Hero widgets.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class W_Hero extends Base {
	protected $ico = 'eicon-slider-full-screen';

	public function get_name() {
		return 'ar_hero';
	}
	public function get_title() {
		return __( 'AR Home Hero', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			__( 'Content', 'arctic-resto' ),
			array(
				'badge'    => array( 'l' => 'Badge', 'd' => 'Mobile dry ice cleaning · NJ & CT' ),
				'title_a'  => array( 'l' => 'Title – before rotating word', 't' => 'area', 'rows' => 2, 'd' => 'Experience the power of mobile dry ice cleaning for' ),
				'words'    => array( 'l' => 'Rotating words (one per line)', 't' => 'area', 'rows' => 6, 'd' => "Aerospace\nFood Plants\nFactories" ),
				'title_b'  => array( 'l' => 'Title – after rotating word', 'd' => '' ),
				'subtitle' => array( 'l' => 'Subtitle', 't' => 'area', 'd' => 'Arctic Resto is an eco-friendly mobile cleaning service with fully outfitted Mercedes Sprinter vans. No water. No chemicals. No mess — just clean and green.' ),
				'b1_t'     => array( 'l' => 'Primary button text', 'd' => 'Get Instant Quote' ),
				'b1_u'     => array( 'l' => 'Primary button link', 't' => 'url' ),
				'b2_t'     => array( 'l' => 'Secondary button text', 'd' => 'See how it works' ),
				'b2_u'     => array( 'l' => 'Secondary button link', 't' => 'url' ),
				'pills'    => array( 'l' => 'Feature pills (one per line)', 't' => 'area', 'd' => "No Water\nNo Chemicals\nClean & Green" ),
				'bg'       => array( 'l' => 'Background image', 't' => 'media' ),
			)
		);
		$this->rep(
			'cards',
			__( 'Floating stat cards', 'arctic-resto' ),
			array(
				'label'  => array( 'l' => 'Label', 'd' => 'Payload per van' ),
				'value'  => array( 'l' => 'Number', 't' => 'num', 'd' => 900 ),
				'suffix' => array( 'l' => 'Suffix', 'd' => ' lb' ),
				'note'   => array( 'l' => 'Note', 'd' => 'of dry ice · 3 insulated bins' ),
				'tone'   => array( 'l' => 'Accent', 't' => 'select', 'd' => 'glacier', 'o' => array( 'glacier' => 'Blue', 'mint' => 'Green' ) ),
			),
			array(),
			'label'
		);
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$words = ar_lines( $s['words'] );
		$first = $words ? $words[0] : '';
		?>
		<section class="ar-sec ar-hero ar-t-void">
			<?php if ( ! empty( $s['bg']['url'] ) ) : ?>
				<div class="ar-hero__bg"><?php echo ar_media( $s['bg'], 'ar-hero', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => '' ) ); // phpcs:ignore ?></div>
			<?php endif; ?>
			<div class="ar-hero__shade"></div>
			<div class="ar-hero__grid"></div>
			<i class="ar-fog ar-fog--1" aria-hidden="true"></i><i class="ar-fog ar-fog--2" aria-hidden="true"></i>
			<div class="ar-particles" data-ar-particles></div>
			<div class="ar-wrap ar-hero__inner">
				<div class="ar-hero__copy">
					<?php if ( $s['badge'] ) : ?><span class="ar-chip"<?php echo ar_rv(); // phpcs:ignore ?>><?php echo ar_svg( 'snow', 'ar-i ar-spin' ); // phpcs:ignore ?> <?php echo esc_html( $s['badge'] ); ?></span><?php endif; ?>
					<h1 class="ar-hero__title"<?php echo ar_rv( 1 ); // phpcs:ignore ?>>
						<?php echo esc_html( $s['title_a'] ); ?>
						<?php if ( $first ) : ?>
							<span class="ar-rot" data-ar-rotator data-words="<?php echo esc_attr( implode( '|', $words ) ); ?>"><span class="ar-rot__w ar-grad"><?php echo esc_html( $first ); ?></span></span>
						<?php endif; ?>
						<?php echo esc_html( $s['title_b'] ); ?>
					</h1>
					<p class="ar-hero__sub"<?php echo ar_rv( 2 ); // phpcs:ignore ?>><?php echo esc_html( $s['subtitle'] ); ?></p>
					<div class="ar-actions"<?php echo ar_rv( 3 ); // phpcs:ignore ?>>
						<?php echo ar_btn( $s['b1_u'], $s['b1_t'], 'primary' ); // phpcs:ignore ?>
						<?php echo ar_btn( $s['b2_u'], $s['b2_t'], 'ghost', false ); // phpcs:ignore ?>
					</div>
					<ul class="ar-pills"<?php echo ar_rv( 4 ); // phpcs:ignore ?>>
						<?php foreach ( ar_lines( $s['pills'] ) as $p ) : ?><li><?php echo ar_svg( 'check' ); // phpcs:ignore ?> <?php echo esc_html( $p ); ?></li><?php endforeach; ?>
					</ul>
				</div>
				<div class="ar-hero__cards">
					<?php foreach ( $this->items( $s, 'cards' ) as $i => $c ) : ?>
						<div class="ar-hc ar-hc--<?php echo (int) $i + 1; ?>"<?php echo ar_rv( $i + 2, 'zoom' ); // phpcs:ignore ?>>
							<div class="ar-glass ar-float ar-tone-<?php echo esc_attr( $c['tone'] ); ?>" style="animation-delay:-<?php echo (int) $i * 2; ?>s">
								<small><?php echo esc_html( $c['label'] ); ?></small>
								<?php echo $this->counter( $c['value'], '', $c['suffix'] ); // phpcs:ignore ?>
								<span><?php echo esc_html( $c['note'] ); ?></span>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="ar-scroll" aria-hidden="true"><i></i></div>
		</section>
		<?php
	}
}

class W_PageHero extends Base {
	protected $ico = 'eicon-banner';

	public function get_name() {
		return 'ar_page_hero';
	}
	public function get_title() {
		return __( 'AR Page Hero', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			__( 'Content', 'arctic-resto' ),
			array(
				'eyebrow'     => array( 'l' => 'Eyebrow', 'd' => 'About Arctic Resto' ),
				'title'       => array( 'l' => 'Title', 't' => 'area', 'rows' => 2, 'd' => 'Eco-friendly cleaning, {{delivered to your door.}}', 'desc' => 'Wrap words in {{double braces}} for gradient text.' ),
				'subtitle'    => array( 'l' => 'Subtitle', 't' => 'area', 'd' => '' ),
				'crumbs'      => array( 'l' => 'Show breadcrumbs', 't' => 'switch', 'd' => 'yes' ),
				'b1_t'        => array( 'l' => 'Primary button text', 'd' => '' ),
				'b1_u'        => array( 'l' => 'Primary button link', 't' => 'url' ),
				'b2_t'        => array( 'l' => 'Secondary button text', 'd' => '' ),
				'b2_u'        => array( 'l' => 'Secondary button link', 't' => 'url' ),
				'bg'          => array( 'l' => 'Background image', 't' => 'media' ),
			)
		);
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		?>
		<section class="ar-sec ar-phero ar-t-void">
			<?php if ( ! empty( $s['bg']['url'] ) ) : ?>
				<div class="ar-hero__bg"><?php echo ar_media( $s['bg'], 'ar-hero', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => '' ) ); // phpcs:ignore ?></div>
			<?php endif; ?>
			<div class="ar-hero__shade"></div>
			<div class="ar-hero__grid"></div>
			<i class="ar-fog ar-fog--1" aria-hidden="true"></i><i class="ar-fog ar-fog--2" aria-hidden="true"></i>
			<div class="ar-particles" data-ar-particles></div>
			<div class="ar-wrap ar-phero__inner">
				<?php if ( 'yes' === $s['crumbs'] ) { echo ar_breadcrumbs(); } // phpcs:ignore ?>
				<?php if ( $s['eyebrow'] ) : ?><p class="ar-eyebrow"><i></i><?php echo esc_html( $s['eyebrow'] ); ?></p><?php endif; ?>
				<h1 class="ar-phero__title"><?php echo ar_title( $s['title'] ); // phpcs:ignore ?></h1>
				<?php if ( $s['subtitle'] ) : ?><p class="ar-phero__sub"><?php echo esc_html( $s['subtitle'] ); ?></p><?php endif; ?>
				<?php if ( $s['b1_t'] || $s['b2_t'] ) : ?>
					<div class="ar-actions"><?php echo ar_btn( $s['b1_u'], $s['b1_t'], 'primary' ); // phpcs:ignore ?><?php echo ar_btn( $s['b2_u'], $s['b2_t'], 'ghost', false ); // phpcs:ignore ?></div>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}
