<?php
/**
 * Content block widgets: icon boxes, stats, split, marquee, CTA, timeline, team, compare.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
class W_IconBoxes extends Base {
	protected $ico = 'eicon-icon-box';

	public function get_name() {
		return 'ar_icon_boxes';
	}
	public function get_title() {
		return __( 'AR Icon Boxes / Steps', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( '', '', '' );
		$this->section(
			'c_layout',
			__( 'Layout', 'arctic-resto' ),
			array(
				'layout' => array(
					'l' => 'Layout',
					't' => 'select',
					'd' => 'cards',
					'o' => array(
						'cards'    => 'Cards',
						'numbered' => 'Numbered cards',
						'process'  => 'Process steps',
						'bar'      => 'Trust bar',
					),
				),
				'cols'   => array( 'l' => 'Columns', 't' => 'select', 'd' => '4', 'o' => array( '2' => '2', '3' => '3', '4' => '4' ) ),
				'howto'  => array( 'l' => 'Output HowTo schema (Process steps layout)', 't' => 'switch', 'd' => '' ),
			)
		);
		$this->rep(
			'items',
			__( 'Items', 'arctic-resto' ),
			array(
				'icon'  => array( 'l' => 'Icon', 't' => 'icon' ),
				'title' => array( 'l' => 'Title', 'd' => 'Feature title' ),
				'text'  => array( 'l' => 'Text', 't' => 'area', 'd' => 'Short description.' ),
				'link'  => array( 'l' => 'Link (optional)', 't' => 'url' ),
			),
			array( array( 'title' => 'Feature one' ), array( 'title' => 'Feature two' ) )
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$layout = $s['layout'];
		$this->open( $s, 'ar-ib ar-ib--' . $layout );
		$this->heading( $s );
		$cls = 'bar' === $layout ? 'ar-bar' : ( 'process' === $layout ? 'ar-steps' : 'ar-grid' );
		echo '<div class="' . esc_attr( $cls ) . ' ar-cols-' . esc_attr( $s['cols'] ) . '">';
		foreach ( $this->items( $s ) as $i => $it ) {
			$url   = ! empty( $it['link']['url'] );
			$open  = $url ? '<a class="ar-stretch"' . ar_link_attrs( $it['link'] ) . '>' : '<span class="ar-stretch">';
			$close = $url ? '</a>' : '</span>';
			$num   = str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT );
			if ( 'bar' === $layout ) {
				echo '<div class="ar-bar__i"' . ar_rv( $i ) . '><span class="ar-ico">' . ar_icon( $it['icon'] ) . '</span><div><b>' . esc_html( $it['title'] ) . '</b><small>' . esc_html( $it['text'] ) . '</small></div></div>'; // phpcs:ignore
			} elseif ( 'process' === $layout ) {
				echo '<div class="ar-step"' . ar_rv( $i ) . '><span class="ar-step__n">' . (int) ( $i + 1 ) . '</span><h3>' . esc_html( $it['title'] ) . '</h3><p>' . esc_html( $it['text'] ) . '</p></div>'; // phpcs:ignore
			} else {
				echo '<article class="ar-card ar-ibox" data-ar-tilt' . ar_rv( $i % 4 ) . '>'; // phpcs:ignore
				echo $open; // phpcs:ignore
				if ( 'numbered' === $layout ) {
					echo '<span class="ar-num">' . esc_html( $num ) . '</span>';
				} else {
					echo '<span class="ar-ico">' . ar_icon( $it['icon'] ) . '</span>'; // phpcs:ignore
				}
				echo '<h3>' . esc_html( $it['title'] ) . '</h3><p>' . esc_html( $it['text'] ) . '</p>';
				if ( $url ) {
					echo '<span class="ar-link">' . esc_html__( 'Learn more', 'arctic-resto' ) . ' ' . ar_svg( 'arrow' ) . '</span>'; // phpcs:ignore
				}
				echo $close; // phpcs:ignore
				echo '</article>';
			}
		}
		echo '</div>';
		$this->close();

		if ( 'process' === $layout && 'yes' === $s['howto'] && $this->items( $s ) ) {
			$steps = array();
			foreach ( $this->items( $s ) as $i => $it ) {
				$steps[] = array(
					'@type'    => 'HowToStep',
					'position' => $i + 1,
					'name'     => $it['title'],
					'text'     => $it['text'],
				);
			}
			ar_json_ld(
				array(
					'@context' => 'https://schema.org',
					'@type'    => 'HowTo',
					'name'     => ! empty( $s['title'] ) ? wp_strip_all_tags( preg_replace( '/\{\{(.+?)\}\}/s', '$1', $s['title'] ) ) : get_the_title(),
					'step'     => $steps,
				)
			);
		}
	}
}

/* ------------------------------------------------------------------ */
class W_Stats extends Base {
	protected $ico = 'eicon-counter';

	public function get_name() {
		return 'ar_stats';
	}
	public function get_title() {
		return __( 'AR Animated Stats', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls();
		$this->section( 'c_l', 'Layout', array( 'cols' => array( 'l' => 'Columns', 't' => 'select', 'd' => '4', 'o' => array( '2' => '2', '3' => '3', '4' => '4' ) ) ) );
		$this->rep(
			'items',
			'Stats',
			array(
				'num'    => array( 'l' => 'Number', 't' => 'num', 'd' => 100 ),
				'prefix' => array( 'l' => 'Prefix', 'd' => '' ),
				'suffix' => array( 'l' => 'Suffix', 'd' => '' ),
				'label'  => array( 'l' => 'Label', 'd' => 'Label' ),
				'note'   => array( 'l' => 'Note', 'd' => '' ),
			),
			array( array( 'label' => 'Stat one' ) ),
			'label'
		);
		$this->style_controls( 'light', 'md' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-stats' );
		$this->heading( $s );
		echo '<div class="ar-grid ar-cols-' . esc_attr( $s['cols'] ) . '">';
		foreach ( $this->items( $s ) as $i => $it ) {
			echo '<div class="ar-stat"' . ar_rv( $i ) . '>' . $this->counter( $it['num'], $it['prefix'], $it['suffix'] ) . '<span>' . esc_html( $it['label'] ) . '</span>' . ( $it['note'] ? '<small>' . esc_html( $it['note'] ) . '</small>' : '' ) . '</div>'; // phpcs:ignore
		}
		echo '</div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Split extends Base {
	protected $ico = 'eicon-image-box';

	public function get_name() {
		return 'ar_split';
	}
	public function get_title() {
		return __( 'AR Image + Text Split', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( '', '', '', 'left' );
		$this->section(
			'c1',
			'Content',
			array(
				'body'     => array( 'l' => 'Text', 't' => 'wys', 'd' => '' ),
				'checks'   => array( 'l' => 'Checklist (one per line)', 't' => 'area', 'rows' => 5, 'd' => '' ),
				'quote'    => array( 'l' => 'Quote (optional)', 't' => 'area', 'd' => '' ),
				'quote_by' => array( 'l' => 'Quote author', 'd' => '' ),
				'b1_t'     => array( 'l' => 'Button 1 text', 'd' => '' ),
				'b1_u'     => array( 'l' => 'Button 1 link', 't' => 'url' ),
				'b2_t'     => array( 'l' => 'Button 2 text', 'd' => '' ),
				'b2_u'     => array( 'l' => 'Button 2 link', 't' => 'url' ),
			)
		);
		$this->section(
			'c2',
			'Image',
			array(
				'image'      => array( 'l' => 'Image', 't' => 'media' ),
				'badge_t'    => array( 'l' => 'Floating badge title', 'd' => '' ),
				'badge_s'    => array( 'l' => 'Floating badge text', 'd' => '' ),
				'reverse'    => array( 'l' => 'Image on the right', 't' => 'switch', 'd' => '' ),
			)
		);
		$this->rep(
			'stats',
			'Mini stats',
			array(
				'num'    => array( 'l' => 'Number', 't' => 'num', 'd' => 0 ),
				'suffix' => array( 'l' => 'Suffix', 'd' => '' ),
				'label'  => array( 'l' => 'Label', 'd' => '' ),
			),
			array(),
			'label'
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$rev = 'yes' === $s['reverse'];
		$this->open( $s, 'ar-splitsec' );
		echo '<div class="ar-split' . ( $rev ? ' ar-split--rev' : '' ) . '">';
		echo '<div class="ar-split__media"' . ar_rv( 0, $rev ? 'right' : 'left' ) . '>'; // phpcs:ignore
		echo ar_media( $s['image'], 'large' ); // phpcs:ignore
		if ( $s['badge_t'] ) {
			echo '<div class="ar-badge ar-float"><span class="ar-ico">' . ar_svg( 'snow' ) . '</span><div><b>' . esc_html( $s['badge_t'] ) . '</b><small>' . esc_html( $s['badge_s'] ) . '</small></div></div>'; // phpcs:ignore
		}
		echo '</div><div class="ar-split__body">';
		$this->heading( $s, 'left' );
		if ( $s['body'] ) {
			echo '<div class="ar-prose"' . ar_rv( 1 ) . '>' . wp_kses_post( $s['body'] ) . '</div>'; // phpcs:ignore
		}
		if ( $s['checks'] ) {
			echo '<ul class="ar-checks">';
			foreach ( ar_lines( $s['checks'] ) as $i => $c ) {
				echo '<li' . ar_rv( $i ) . '>' . ar_svg( 'check' ) . '<span>' . esc_html( $c ) . '</span></li>'; // phpcs:ignore
			}
			echo '</ul>';
		}
		if ( $s['quote'] ) {
			echo '<blockquote class="ar-quote"' . ar_rv( 2 ) . '>' . esc_html( $s['quote'] ) . ( $s['quote_by'] ? '<footer>— ' . esc_html( $s['quote_by'] ) . '</footer>' : '' ) . '</blockquote>'; // phpcs:ignore
		}
		$stats = $this->items( $s, 'stats' );
		if ( $stats ) {
			echo '<div class="ar-ministats">';
			foreach ( $stats as $i => $st ) {
				echo '<div' . ar_rv( $i ) . '>' . $this->counter( $st['num'], '', $st['suffix'] ) . '<span>' . esc_html( $st['label'] ) . '</span></div>'; // phpcs:ignore
			}
			echo '</div>';
		}
		if ( $s['b1_t'] || $s['b2_t'] ) {
			$dark = in_array( $s['theme'], array( 'dark', 'void', 'gradient' ), true );
			echo '<div class="ar-actions">' . ar_btn( $s['b1_u'], $s['b1_t'], $dark ? 'primary' : 'dark' ) . ar_btn( $s['b2_u'], $s['b2_t'], $dark ? 'ghost' : 'outline', false ) . '</div>'; // phpcs:ignore
		}
		echo '</div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Marquee extends Base {
	protected $ico = 'eicon-slider-push';

	public function get_name() {
		return 'ar_marquee';
	}
	public function get_title() {
		return __( 'AR Scrolling Ticker', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section( 'c1', 'Content', array( 'items' => array( 'l' => 'Words (one per line)', 't' => 'area', 'rows' => 8, 'd' => "Aerospace\nFood Processing\nManufacturing" ) ) );
		$this->style_controls( 'void', 'none' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$lines = ar_lines( $s['items'] );
		$this->open( $s, 'ar-mq' );
		echo '</div><div class="ar-marquee" aria-hidden="true"><div class="ar-marquee__track">';
		for ( $r = 0; $r < 2; $r++ ) {
			foreach ( $lines as $l ) {
				echo '<span>' . esc_html( $l ) . ar_svg( 'snow' ) . '</span>'; // phpcs:ignore
			}
		}
		echo '</div></div></section>';
	}
}

/* ------------------------------------------------------------------ */
class W_Cta extends Base {
	protected $ico = 'eicon-call-to-action';

	public function get_name() {
		return 'ar_cta';
	}
	public function get_title() {
		return __( 'AR Call To Action', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Content',
			array(
				'title' => array( 'l' => 'Title', 't' => 'area', 'rows' => 2, 'd' => 'Book your free assessment' ),
				'text'  => array( 'l' => 'Text', 't' => 'area', 'd' => "Tell us about your surface, contaminant and timeline. We'll recommend the right pressure, pellet size and approach." ),
				'b1_t'  => array( 'l' => 'Button 1 text', 'd' => 'Get Instant Quote' ),
				'b1_u'  => array( 'l' => 'Button 1 link', 't' => 'url' ),
				'b2_t'  => array( 'l' => 'Button 2 text (blank = call button)', 'd' => '' ),
				'b2_u'  => array( 'l' => 'Button 2 link', 't' => 'url' ),
			)
		);
		$this->style_controls( 'gradient', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-cta' );
		echo '<div class="ar-particles" data-ar-particles></div><div class="ar-cta__in"' . ar_rv() . '>'; // phpcs:ignore
		echo '<h2 class="ar-cta__t">' . ar_title( $s['title'] ) . '</h2><p>' . esc_html( $s['text'] ) . '</p><div class="ar-actions ar-actions--c">'; // phpcs:ignore
		echo ar_btn( $s['b1_u'], $s['b1_t'], 'primary' ); // phpcs:ignore
		if ( $s['b2_t'] ) {
			echo ar_btn( $s['b2_u'], $s['b2_t'], 'ghost', false ); // phpcs:ignore
		} else {
			echo '<a class="ar-btn ar-btn--ghost" href="' . esc_url( ar_phone_href() ) . '">' . ar_svg( 'phone' ) . '<span>' . esc_html( ar_phone() ) . '</span></a>'; // phpcs:ignore
		}
		echo '</div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Timeline extends Base {
	protected $ico = 'eicon-time-line';

	public function get_name() {
		return 'ar_timeline';
	}
	public function get_title() {
		return __( 'AR Timeline', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls();
		$this->rep(
			'items',
			'Milestones',
			array(
				'year'  => array( 'l' => 'Year / label', 'd' => '2024' ),
				'title' => array( 'l' => 'Title', 'd' => 'Milestone' ),
				'text'  => array( 'l' => 'Text', 't' => 'area', 'd' => '' ),
			),
			array( array( 'title' => 'Launch' ) )
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-tlsec' );
		$this->heading( $s );
		echo '<ol class="ar-tl">';
		foreach ( $this->items( $s ) as $i => $it ) {
			echo '<li class="ar-tl__i"' . ar_rv( 0, $i % 2 ? 'right' : 'left' ) . '><i class="ar-tl__dot"></i><span class="ar-tl__y">' . esc_html( $it['year'] ) . '</span><h3>' . esc_html( $it['title'] ) . '</h3><p>' . esc_html( $it['text'] ) . '</p></li>'; // phpcs:ignore
		}
		echo '</ol>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Team extends Base {
	protected $ico = 'eicon-person';

	public function get_name() {
		return 'ar_team';
	}
	public function get_title() {
		return __( 'AR Team Members', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls();
		$this->rep(
			'items',
			'Team',
			array(
				'name'  => array( 'l' => 'Name', 'd' => 'Team member' ),
				'role'  => array( 'l' => 'Role', 'd' => '' ),
				'image' => array( 'l' => 'Photo (optional)', 't' => 'media' ),
			),
			array( array( 'name' => 'Team member' ) ),
			'name'
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-teamsec' );
		$this->heading( $s );
		echo '<div class="ar-grid ar-cols-4">';
		foreach ( $this->items( $s ) as $i => $m ) {
			$ini = '';
			foreach ( array_slice( preg_split( '/\s+/', trim( $m['name'] ) ), 0, 2 ) as $w ) {
				$ini .= strtoupper( substr( $w, 0, 1 ) );
			}
			echo '<div class="ar-member"' . ar_rv( $i ) . '>'; // phpcs:ignore
			echo ! empty( $m['image']['url'] ) ? ar_media( $m['image'], 'ar-card' ) : '<span class="ar-member__ph">' . esc_html( $ini ) . '</span>'; // phpcs:ignore
			echo '<div class="ar-member__cap"><b>' . esc_html( $m['name'] ) . '</b><small>' . esc_html( $m['role'] ) . '</small></div></div>'; // phpcs:ignore
		}
		echo '</div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Compare extends Base {
	protected $ico = 'eicon-price-table';

	public function get_name() {
		return 'ar_compare';
	}
	public function get_title() {
		return __( 'AR Comparison Table', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( '', '', '', 'left' );
		$this->section(
			'c1',
			'Columns',
			array(
				'col_a'   => array( 'l' => 'Column A label', 'd' => 'Dry ice' ),
				'col_b'   => array( 'l' => 'Column B label', 'd' => 'Traditional' ),
				'pills'   => array( 'l' => 'Highlights (one per line: Title|Description)', 't' => 'area', 'rows' => 4, 'd' => "Eco-friendly|Recycled CO₂, non-toxic\nNon-abrasive|Preserves the substrate\nFast|Minimal downtime" ),
			)
		);
		$this->rep(
			'items',
			'Rows',
			array(
				'title' => array( 'l' => 'Row label', 'd' => 'Water required' ),
				'a'     => array( 'l' => 'Column A', 'd' => 'None' ),
				'b'     => array( 'l' => 'Column B', 'd' => 'Gallons per job' ),
			),
			array( array( 'title' => 'Water required', 'a' => 'None', 'b' => 'Gallons per job' ) )
		);
		$this->style_controls( 'dark', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-cmp' );
		echo '<div class="ar-cmp__grid"><div>';
		$this->heading( $s, 'left' );
		echo '<div class="ar-hl">';
		foreach ( ar_lines( $s['pills'] ) as $i => $l ) {
			$p = explode( '|', $l );
			echo '<div class="ar-glass"' . ar_rv( $i ) . '><b>' . esc_html( $p[0] ) . '</b><small>' . esc_html( isset( $p[1] ) ? $p[1] : '' ) . '</small></div>'; // phpcs:ignore
		}
		echo '</div></div><div class="ar-glass ar-table"' . ar_rv( 1, 'right' ) . '>'; // phpcs:ignore
		echo '<div class="ar-table__h"><span></span><b class="a">' . esc_html( $s['col_a'] ) . '</b><b>' . esc_html( $s['col_b'] ) . '</b></div>';
		foreach ( $this->items( $s ) as $r ) {
			echo '<div class="ar-table__r"><strong>' . esc_html( $r['title'] ) . '</strong><span class="a">' . ar_svg( 'check' ) . esc_html( $r['a'] ) . '</span><span class="b">' . ar_svg( 'x' ) . esc_html( $r['b'] ) . '</span></div>'; // phpcs:ignore
		}
		echo '</div></div>';
		$this->close();
	}
}
