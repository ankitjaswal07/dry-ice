<?php
/**
 * Navigation and clarity widgets: sticky "On this page" bar and the Good fit / Not ideal grid.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
class W_PageNav extends Base {
	protected $ico = 'eicon-anchor';

	public function get_name() {
		return 'ar_page_nav';
	}
	public function get_title() {
		return __( 'AR On-page Navigation', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Bar',
			array(
				'label' => array( 'l' => 'Label', 'd' => 'On this page' ),
				'b1_t'  => array( 'l' => 'Button text (optional)', 'd' => 'Get a quote' ),
				'b1_u'  => array( 'l' => 'Button link', 't' => 'url' ),
			)
		);
		$this->rep(
			'items',
			'Links',
			array(
				'label'  => array( 'l' => 'Label', 'd' => 'Overview' ),
				'anchor' => array( 'l' => 'Section Anchor ID', 'd' => 'overview', 'desc' => 'Set the same value in the target widget: Style tab → Section Style → Anchor ID.' ),
			),
			array( array( 'label' => 'Overview', 'anchor' => 'overview' ) ),
			'label'
		);
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$label = $s['label'] ? $s['label'] : __( 'On this page', 'arctic-resto' );
		echo '<nav class="ar-pnav" data-ar-pnav aria-label="' . esc_attr( $label ) . '"><div class="ar-pnav__bar"><div class="ar-wrap ar-pnav__in">';
		echo '<span class="ar-pnav__lab">' . esc_html( $label ) . '</span><div class="ar-pnav__links">';
		foreach ( $this->items( $s ) as $it ) {
			$id = sanitize_title( ltrim( (string) $it['anchor'], '#' ) );
			echo '<a href="#' . esc_attr( $id ) . '">' . esc_html( $it['label'] ) . '</a>';
		}
		echo '</div>';
		if ( $s['b1_t'] ) {
			echo '<span class="ar-pnav__cta">' . ar_btn( $s['b1_u'], $s['b1_t'], 'dark', false ) . '</span>'; // phpcs:ignore
		}
		echo '</div></div></nav>';
	}
}

/* ------------------------------------------------------------------ */
class W_Fit extends Base {
	protected $ico = 'eicon-check-circle';

	public function get_name() {
		return 'ar_fit';
	}
	public function get_title() {
		return __( 'AR Good Fit / Not Ideal', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Is it right for you?', 'A clear look at {{when it fits}}', '' );
		$this->section(
			'c1',
			'Lists',
			array(
				'good_t' => array( 'l' => 'Good fit – title', 'd' => 'Good fit' ),
				'good'   => array( 'l' => 'Good fit – items (one per line)', 't' => 'area', 'rows' => 6, 'd' => '' ),
				'bad_t'  => array( 'l' => 'Not ideal – title', 'd' => 'Probably not the best fit' ),
				'bad'    => array( 'l' => 'Not ideal – items (one per line, blank hides the column)', 't' => 'area', 'rows' => 5, 'd' => '' ),
				'note'   => array( 'l' => 'Note under the lists', 'd' => '' ),
			)
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$good = ar_lines( $s['good'] );
		$bad  = ar_lines( $s['bad'] );
		$this->open( $s, 'ar-fitsec' );
		$this->heading( $s );
		echo '<div class="ar-fit' . ( $bad ? '' : ' ar-fit--one' ) . '">';
		echo '<div class="ar-fit__c ar-fit__c--good"' . ar_rv( 0, 'left' ) . '><h3>' . ar_svg( 'check' ) . esc_html( $s['good_t'] ) . '</h3><ul>'; // phpcs:ignore
		foreach ( $good as $g ) {
			echo '<li>' . ar_svg( 'check' ) . '<span>' . esc_html( $g ) . '</span></li>'; // phpcs:ignore
		}
		echo '</ul></div>';
		if ( $bad ) {
			echo '<div class="ar-fit__c ar-fit__c--bad"' . ar_rv( 1, 'right' ) . '><h3>' . ar_svg( 'x' ) . esc_html( $s['bad_t'] ) . '</h3><ul>'; // phpcs:ignore
			foreach ( $bad as $b ) {
				echo '<li>' . ar_svg( 'x' ) . '<span>' . esc_html( $b ) . '</span></li>'; // phpcs:ignore
			}
			echo '</ul></div>';
		}
		echo '</div>';
		if ( $s['note'] ) {
			echo '<p class="ar-fit__note">' . esc_html( $s['note'] ) . '</p>';
		}
		$this->close();
	}
}
