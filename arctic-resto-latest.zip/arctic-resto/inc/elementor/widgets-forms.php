<?php
/**
 * Form widgets: Contact/Franchise form and the instant estimator.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Hidden fields + anti-spam used by every form. */
function ar_form_meta( $type ) {
	return '<input type="hidden" name="action" value="ar_form"><input type="hidden" name="form_type" value="' . esc_attr( $type ) . '"><input type="hidden" name="ts" value=""><input class="ar-hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">';
}

function ar_service_titles() {
	$out = array();
	foreach ( ar_get_services() as $p ) {
		$out[] = get_the_title( $p );
	}
	$out[] = __( 'Other / not sure', 'arctic-resto' );
	return $out;
}

/* ------------------------------------------------------------------ */
class W_Form extends Base {
	protected $ico = 'eicon-form-horizontal';

	public function get_name() {
		return 'ar_form';
	}
	public function get_title() {
		return __( 'AR Lead Form', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Form',
			array(
				'type'      => array( 'l' => 'Form type', 't' => 'select', 'd' => 'contact', 'o' => array( 'contact' => 'Contact form', 'franchise' => 'Franchise inquiry' ) ),
				'form_t'    => array( 'l' => 'Form heading', 'd' => 'Send us a message' ),
				'form_s'    => array( 'l' => 'Form sub-heading', 'd' => '' ),
				'btn'       => array( 'l' => 'Button text', 'd' => 'Send message' ),
				'ok_t'      => array( 'l' => 'Success title', 'd' => 'Thank you!' ),
				'ok_s'      => array( 'l' => 'Success text', 't' => 'area', 'd' => 'Your message has been received. Our team will be in touch within one business day.' ),
				'aside'     => array( 'l' => 'Show contact details beside the form', 't' => 'switch', 'd' => 'yes' ),
				'hours'     => array( 'l' => 'Business hours (Label|Hours per line)', 't' => 'area', 'rows' => 4, 'd' => "Mon – Fri|7:00 AM – 6:00 PM\nSaturday|8:00 AM – 2:00 PM\nSunday|Emergency fire restoration" ),
				'consent'   => array( 'l' => 'Consent text (franchise form)', 't' => 'area', 'd' => 'I agree to be contacted about franchise opportunities. This is not an offer to sell a franchise.' ),
			)
		);
		$this->heading_controls( '', '', '', 'left' );
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$type = $s['type'];
		$this->open( $s, 'ar-formsec' );
		$aside = 'yes' === $s['aside'];
		echo '<div class="ar-formwrap' . ( $aside ? ' has-aside' : '' ) . '">';
		if ( $aside ) {
			echo '<aside' . ar_rv( 0, 'left' ) . '>'; // phpcs:ignore
			$this->heading( $s, 'left' );
			echo '<ul class="ar-contactlist">';
			foreach ( array(
				array( 'phone', __( 'Phone', 'arctic-resto' ), ar_phone(), ar_phone_href() ),
				array( 'mail', __( 'Email', 'arctic-resto' ), ar_email(), 'mailto:' . ar_email() ),
				array( 'pin', __( 'Location', 'arctic-resto' ), ar_location(), '' ),
			) as $c ) {
				$inner = '<span class="ar-ico">' . ar_svg( $c[0] ) . '</span><span><small>' . esc_html( $c[1] ) . '</small><b>' . esc_html( $c[2] ) . '</b></span>'; // phpcs:ignore
				echo '<li>' . ( $c[3] ? '<a href="' . esc_url( $c[3] ) . '">' . $inner . '</a>' : '<div>' . $inner . '</div>' ) . '</li>'; // phpcs:ignore
			}
			echo '</ul>';
			if ( $s['hours'] ) {
				echo '<div class="ar-hours"><p>' . ar_svg( 'clock' ) . ' ' . esc_html__( 'Business hours', 'arctic-resto' ) . '</p><dl>'; // phpcs:ignore
				foreach ( ar_lines( $s['hours'] ) as $h ) {
					$p = explode( '|', $h );
					echo '<div><dt>' . esc_html( $p[0] ) . '</dt><dd>' . esc_html( isset( $p[1] ) ? $p[1] : '' ) . '</dd></div>';
				}
				echo '</dl></div>';
			}
			echo '</aside>';
		}
		echo '<div class="ar-formbox"' . ar_rv( 1, 'right' ) . '>'; // phpcs:ignore
		if ( ! $aside ) {
			$this->heading( $s, 'left' );
		}
		echo '<form class="ar-form" data-ar-form method="post" action="#" novalidate>' . ar_form_meta( $type ); // phpcs:ignore
		if ( $s['form_t'] ) {
			echo '<div class="ar-field--full"><h3>' . esc_html( $s['form_t'] ) . '</h3>' . ( $s['form_s'] ? '<p>' . esc_html( $s['form_s'] ) . '</p>' : '' ) . '</div>';
		}
		if ( 'franchise' === $type ) {
			echo ar_field( 'first', __( 'First name', 'arctic-resto' ), 'text', true ) . ar_field( 'last', __( 'Last name', 'arctic-resto' ), 'text', true ) . ar_field( 'email', __( 'Email', 'arctic-resto' ), 'email', true ) . ar_field( 'phone', __( 'Phone', 'arctic-resto' ), 'tel', true ) . ar_field( 'city', __( 'City', 'arctic-resto' ), 'text', true ) . ar_field( 'state', __( 'State of interest', 'arctic-resto' ), 'select', false, false, array( 'Connecticut', 'New Jersey', 'Massachusetts', 'Southeast USA', 'Other' ) ) . ar_field( 'investment', __( 'Investment range', 'arctic-resto' ), 'select', false, true, array( 'Select a range', 'Under $75k', '$75k – $150k', '$150k – $250k', '$250k+' ) ) . ar_field( 'background', __( 'Tell us about your background', 'arctic-resto' ), 'textarea', false, true ); // phpcs:ignore
			echo '<label class="ar-check ar-field--full"><input type="checkbox" required><span>' . esc_html( $s['consent'] ) . '</span></label>';
		} else {
			echo ar_field( 'name', __( 'Full name', 'arctic-resto' ), 'text', true ) . ar_field( 'company', __( 'Company', 'arctic-resto' ) ) . ar_field( 'email', __( 'Email', 'arctic-resto' ), 'email', true ) . ar_field( 'phone', __( 'Phone', 'arctic-resto' ), 'tel' ) . ar_field( 'interest', __( "I'm interested in", 'arctic-resto' ), 'select', false, true, array( 'A quote for a cleaning project', 'Franchise opportunity', 'General questions', 'Partnership / referral' ) ) . ar_field( 'service', __( 'Service', 'arctic-resto' ), 'select', false, true, ar_service_titles() ) . ar_field( 'details', __( 'Project details', 'arctic-resto' ), 'textarea', false, true ); // phpcs:ignore
		}
		echo '<div class="ar-field--full"><button class="ar-btn ar-btn--primary" type="submit"><span>' . esc_html( $s['btn'] ) . '</span>' . ar_svg( 'arrow' ) . '</button><p class="ar-form__msg" role="status" aria-live="polite"></p></div></form>'; // phpcs:ignore
		echo '<div class="ar-success" hidden><span class="ar-success__i">' . ar_svg( 'check' ) . '</span><h3>' . esc_html( $s['ok_t'] ) . '</h3><p>' . esc_html( $s['ok_s'] ) . '</p><button type="button" class="ar-link" data-reset>' . esc_html__( 'Send another', 'arctic-resto' ) . '</button></div>'; // phpcs:ignore
		echo '</div></div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Estimator extends Base {
	protected $ico = 'eicon-price-list';

	public function get_name() {
		return 'ar_estimator';
	}
	public function get_title() {
		return __( 'AR Instant Estimator', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Pricing model',
			array(
				'rate'   => array( 'l' => 'Hourly rate ($)', 't' => 'num', 'd' => 275, 'min' => 50, 'max' => 2000, 'desc' => 'Demo formula: hours × rate, shown as a range. Replace with your real pricing.' ),
				'small'  => array( 'l' => 'Hours – small job', 't' => 'num', 'd' => 3 ),
				'medium' => array( 'l' => 'Hours – medium job', 't' => 'num', 'd' => 6 ),
				'large'  => array( 'l' => 'Hours – large job', 't' => 'num', 'd' => 12 ),
				'm_mod'  => array( 'l' => 'Multiplier – moderate condition', 't' => 'num', 'd' => 1.35, 'step' => 0.05 ),
				'm_hvy'  => array( 'l' => 'Multiplier – heavy condition', 't' => 'num', 'd' => 1.8, 'step' => 0.05 ),
				'legal'  => array( 'l' => 'Disclaimer', 'd' => 'Illustrative demo estimate only. Final quote follows a free assessment.' ),
			)
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$cfg = array(
			'rate'  => (float) $s['rate'],
			'hours' => array( (float) $s['small'], (float) $s['medium'], (float) $s['large'] ),
			'mult'  => array( 1, (float) $s['m_mod'], (float) $s['m_hvy'] ),
		);
		$svcs  = ar_get_services();
		$sizes = array(
			array( __( 'Small', 'arctic-resto' ), __( 'A single machine or engine bay', 'arctic-resto' ) ),
			array( __( 'Medium', 'arctic-resto' ), __( 'A production line or vehicle underside', 'arctic-resto' ) ),
			array( __( 'Large', 'arctic-resto' ), __( 'A facility area, hull or structure', 'arctic-resto' ) ),
		);
		$conds = array(
			array( __( 'Light buildup', 'arctic-resto' ), __( 'Dust, light grease, surface film', 'arctic-resto' ) ),
			array( __( 'Moderate', 'arctic-resto' ), __( 'Heavy grease, carbon, adhesive', 'arctic-resto' ) ),
			array( __( 'Heavy / coatings', 'arctic-resto' ), __( 'Paint, undercoating, char, marine growth', 'arctic-resto' ) ),
		);
		$this->open( $s, 'ar-estsec' );
		echo '<div class="ar-est" data-ar-est data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		echo '<ol class="ar-est__steps">';
		foreach ( array( __( 'Service', 'arctic-resto' ), __( 'Job details', 'arctic-resto' ), __( 'Estimate', 'arctic-resto' ) ) as $i => $l ) {
			echo '<li class="' . ( 0 === $i ? 'is-active' : '' ) . '"><b>' . (int) ( $i + 1 ) . '</b><span>' . esc_html( $l ) . '</span></li>';
		}
		echo '</ol><div class="ar-est__box">';

		echo '<div class="ar-est__pane is-active" data-pane="0"><h3>' . esc_html__( 'What do you need cleaned?', 'arctic-resto' ) . '</h3><div class="ar-est__opts ar-cols-2" data-group="service">'; // phpcs:ignore
		foreach ( $svcs as $i => $p ) {
			$m = ar_service_meta( $p->ID );
			echo '<button type="button" class="ar-opt' . ( 0 === $i ? ' is-sel' : '' ) . '" data-v="' . esc_attr( get_the_title( $p ) ) . '"><span class="ar-ico">' . ar_icon( $m['icon'] ) . '</span><b>' . esc_html( get_the_title( $p ) ) . '</b></button>'; // phpcs:ignore
		}
		echo '</div></div>';

		echo '<div class="ar-est__pane" data-pane="1"><h3>' . esc_html__( 'How big is the job?', 'arctic-resto' ) . '</h3><div class="ar-est__opts ar-cols-3" data-group="size">'; // phpcs:ignore
		foreach ( $sizes as $i => $z ) {
			echo '<button type="button" class="ar-opt' . ( 1 === $i ? ' is-sel' : '' ) . '" data-v="' . (int) $i . '" data-l="' . esc_attr( $z[0] ) . '"><b>' . esc_html( $z[0] ) . '</b><small>' . esc_html( $z[1] ) . '</small></button>';
		}
		echo '</div><h3 class="ar-mt">' . esc_html__( "What's the condition?", 'arctic-resto' ) . '</h3><div class="ar-est__opts ar-cols-3" data-group="cond">'; // phpcs:ignore
		foreach ( $conds as $i => $z ) {
			echo '<button type="button" class="ar-opt' . ( 1 === $i ? ' is-sel' : '' ) . '" data-v="' . (int) $i . '" data-l="' . esc_attr( $z[0] ) . '"><b>' . esc_html( $z[0] ) . '</b><small>' . esc_html( $z[1] ) . '</small></button>';
		}
		echo '</div></div>';

		echo '<div class="ar-est__pane" data-pane="2"><div class="ar-est__res"><small data-r-svc></small><b data-r-range>$0</b><p data-r-meta></p><em>' . esc_html( $s['legal'] ) . '</em></div>'; // phpcs:ignore
		echo '<form class="ar-form" data-ar-form method="post" action="#" novalidate>' . ar_form_meta( 'estimate' ) . '<input type="hidden" name="service"><input type="hidden" name="size"><input type="hidden" name="condition"><input type="hidden" name="estimate"><div class="ar-field--full"><h3>' . esc_html__( 'Where should we send your quote?', 'arctic-resto' ) . '</h3></div>'; // phpcs:ignore
		echo ar_field( 'name', __( 'Full name', 'arctic-resto' ), 'text', true ) . ar_field( 'email', __( 'Email', 'arctic-resto' ), 'email', true ) . ar_field( 'phone', __( 'Phone', 'arctic-resto' ), 'tel' ) . ar_field( 'loc', __( 'Location (town / state)', 'arctic-resto' ), 'text', true ); // phpcs:ignore
		echo '<div class="ar-field--full"><button class="ar-btn ar-btn--primary" type="submit"><span>' . esc_html__( 'Request my free assessment', 'arctic-resto' ) . '</span>' . ar_svg( 'arrow' ) . '</button><p class="ar-form__msg" role="status" aria-live="polite"></p></div></form>'; // phpcs:ignore
		echo '<div class="ar-success" hidden><span class="ar-success__i">' . ar_svg( 'check' ) . '</span><h3>' . esc_html__( 'Request received!', 'arctic-resto' ) . '</h3><p>' . esc_html__( "We've saved your estimate and a team member will follow up within one business day to schedule your free assessment.", 'arctic-resto' ) . '</p><button type="button" class="ar-link" data-restart>' . esc_html__( 'Start a new estimate', 'arctic-resto' ) . '</button></div></div>'; // phpcs:ignore

		echo '<div class="ar-est__nav"><button type="button" class="ar-link" data-back disabled>' . ar_svg( 'chev-l' ) . ' ' . esc_html__( 'Back', 'arctic-resto' ) . '</button><button type="button" class="ar-btn ar-btn--primary" data-next><span>' . esc_html__( 'Continue', 'arctic-resto' ) . '</span>' . ar_svg( 'arrow' ) . '</button></div>'; // phpcs:ignore
		echo '</div></div>';
		$this->close();
	}
}
