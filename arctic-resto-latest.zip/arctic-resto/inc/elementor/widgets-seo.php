<?php
/**
 * SEO / AI-search widgets: Answer Box + Quick Facts, Long-form Article, Franchise Portal card.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
class W_Answer extends Base {
	protected $ico = 'eicon-info-box';

	public function get_name() {
		return 'ar_answer';
	}
	public function get_title() {
		return __( 'AR Answer Box + Quick Facts', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->section(
			'c1',
			'Answer',
			array(
				'question'    => array( 'l' => 'Question (H2)', 'd' => 'What is dry ice cleaning?' ),
				'answer'      => array( 'l' => 'Direct answer (40–70 words works best)', 't' => 'area', 'rows' => 6, 'd' => 'Dry ice cleaning uses solid CO₂ pellets and compressed air to lift contaminants, then the pellets vanish as gas.' ),
				'updated'     => array( 'l' => 'Show "Last reviewed" date', 't' => 'switch', 'd' => 'yes' ),
				'note'        => array( 'l' => 'Small print (optional)', 'd' => '' ),
				'facts_title' => array( 'l' => 'Facts box title', 'd' => 'Quick facts' ),
				'b1_t'        => array( 'l' => 'Button 1 text', 'd' => '' ),
				'b1_u'        => array( 'l' => 'Button 1 link', 't' => 'url' ),
				'b2_t'        => array( 'l' => 'Button 2 text', 'd' => '' ),
				'b2_u'        => array( 'l' => 'Button 2 link', 't' => 'url' ),
			)
		);
		$this->rep(
			'facts',
			'Quick facts',
			array(
				'label' => array( 'l' => 'Label', 'd' => 'Best for' ),
				'value' => array( 'l' => 'Value', 't' => 'area', 'rows' => 2, 'd' => '' ),
			),
			array(),
			'label'
		);
		$this->style_controls( 'frost', 'md' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-answersec' );
		echo '<div class="ar-answer"><div class="ar-answer__main"' . ar_rv( 0, 'left' ) . '>'; // phpcs:ignore
		echo '<p class="ar-eyebrow"><i></i>' . esc_html__( 'Quick answer', 'arctic-resto' ) . '</p>';
		echo '<h2 class="ar-answer__q">' . esc_html( $s['question'] ) . '</h2>';
		echo '<p class="ar-answer__a">' . esc_html( $s['answer'] ) . '</p>';
		if ( 'yes' === $s['updated'] && get_the_ID() ) {
			echo '<p class="ar-answer__upd">' . ar_svg( 'clock' ) . ' ' . esc_html__( 'Last reviewed', 'arctic-resto' ) . ' <time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time></p>'; // phpcs:ignore
		}
		if ( $s['note'] ) {
			echo '<p class="ar-answer__note">' . esc_html( $s['note'] ) . '</p>';
		}
		if ( $s['b1_t'] || $s['b2_t'] ) {
			echo '<div class="ar-actions">' . ar_btn( $s['b1_u'], $s['b1_t'], 'dark' ) . ar_btn( $s['b2_u'], $s['b2_t'], 'outline', false ) . '</div>'; // phpcs:ignore
		}
		echo '</div>';
		$facts = $this->items( $s, 'facts' );
		if ( $facts ) {
			echo '<aside class="ar-answer__facts"' . ar_rv( 1, 'right' ) . '><h3>' . esc_html( $s['facts_title'] ) . '</h3><dl class="ar-facts">'; // phpcs:ignore
			foreach ( $facts as $f ) {
				echo '<div><dt>' . esc_html( $f['label'] ) . '</dt><dd>' . esc_html( $f['value'] ) . '</dd></div>';
			}
			echo '</dl></aside>';
		}
		echo '</div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Article extends Base {
	protected $ico = 'eicon-text';

	public function get_name() {
		return 'ar_article';
	}
	public function get_title() {
		return __( 'AR Long-form Article + Sidebar', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( '', '', '', 'left' );
		$this->section(
			'c1',
			'Content',
			array(
				'body'       => array( 'l' => 'Article text (use Heading 3 for sub-sections)', 't' => 'wys', 'd' => '' ),
				'aside_t'    => array( 'l' => 'Sidebar title', 'd' => 'Common applications' ),
				'aside_list' => array( 'l' => 'Sidebar list (one per line)', 't' => 'area', 'rows' => 6, 'd' => '' ),
				'b1_t'       => array( 'l' => 'Sidebar button text', 'd' => 'Get a free quote' ),
				'b1_u'       => array( 'l' => 'Sidebar button link', 't' => 'url' ),
			)
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->open( $s, 'ar-articlesec' );
		echo '<div class="ar-article"><div class="ar-article__main"' . ar_rv( 0, 'left' ) . '>'; // phpcs:ignore
		$this->heading( $s, 'left' );
		echo '<div class="ar-prose ar-prose--guide">' . wp_kses_post( $s['body'] ) . '</div></div>';
		if ( $s['aside_list'] ) {
			echo '<aside class="ar-article__aside"' . ar_rv( 1, 'right' ) . '><h3>' . esc_html( $s['aside_t'] ) . '</h3><ul class="ar-checks">'; // phpcs:ignore
			foreach ( ar_lines( $s['aside_list'] ) as $l ) {
				echo '<li>' . ar_svg( 'check' ) . '<span>' . esc_html( $l ) . '</span></li>'; // phpcs:ignore
			}
			echo '</ul>';
			if ( $s['b1_t'] ) {
				echo '<div class="ar-actions">' . ar_btn( $s['b1_u'], $s['b1_t'], 'dark' ) . '</div>'; // phpcs:ignore
			}
			echo '</aside>';
		}
		echo '</div>';
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Portal extends Base {
	protected $ico = 'eicon-lock-user';

	public function get_name() {
		return 'ar_portal';
	}
	public function get_title() {
		return __( 'AR Franchise Portal Card', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Franchise portal', 'Apply and manage your franchise in the {{portal}}', 'Start your application, review documents and track your onboarding in our franchise portal. Already an owner? Sign in to your dashboard.', 'left' );
		$this->section(
			'c1',
			'Buttons & details',
			array(
				'features' => array( 'l' => 'Highlights (one per line)', 't' => 'area', 'rows' => 5, 'd' => "Start or resume your application\nReview franchise documents securely\nTrack training and van build progress\nOwner dashboard, tools and resources" ),
				'card_t'   => array( 'l' => 'Card title', 'd' => 'Arctic Resto Franchise Portal' ),
				'card_s'   => array( 'l' => 'Card text', 't' => 'area', 'd' => 'Secure access for prospective and current franchise owners.' ),
				'b1_t'     => array( 'l' => 'Register button text', 'd' => 'Register for the franchise portal' ),
				'b1_u'     => array( 'l' => 'Register link (blank = Customizer register URL)', 't' => 'url' ),
				'b2_t'     => array( 'l' => 'Login button text', 'd' => 'Franchise owner login' ),
				'b2_u'     => array( 'l' => 'Login link (blank = Customizer login URL)', 't' => 'url' ),
				'note'     => array( 'l' => 'Small print', 'd' => 'Franchise offerings are made only by disclosure document.' ),
			)
		);
		$this->style_controls( 'dark', 'lg' );
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$l1 = ! empty( $s['b1_u']['url'] ) ? $s['b1_u'] : array( 'url' => ar_portal_register_url() );
		$l2 = ! empty( $s['b2_u']['url'] ) ? $s['b2_u'] : array( 'url' => ar_portal_login_url() );
		$this->open( $s, 'ar-portalsec' );
		echo '<div class="ar-portal ar-glass"><div' . ar_rv( 0, 'left' ) . '>'; // phpcs:ignore
		$this->heading( $s, 'left' );
		echo '<ul class="ar-portal__feats">';
		foreach ( ar_lines( $s['features'] ) as $f ) {
			echo '<li>' . ar_svg( 'check' ) . '<span>' . esc_html( $f ) . '</span></li>'; // phpcs:ignore
		}
		echo '</ul></div><div class="ar-portal__side"' . ar_rv( 1, 'right' ) . '><span class="ar-ico">' . ar_svg( 'snow' ) . '</span><h3>' . esc_html( $s['card_t'] ) . '</h3><p>' . esc_html( $s['card_s'] ) . '</p>'; // phpcs:ignore
		echo '<div class="ar-portal__btns">' . ( ar_portal_state() ? ar_btn( array( 'url' => ar_portal_dashboard_url() ), __( 'Open franchise dashboard', 'arctic-resto' ), 'primary' ) . ar_btn( array( 'url' => wp_logout_url( home_url( '/' ) ) ), __( 'Log out', 'arctic-resto' ), 'ghost', false ) : ar_btn( $l1, $s['b1_t'], 'primary' ) . ar_btn( $l2, $s['b2_t'], 'ghost', false ) ) . '</div>'; // phpcs:ignore
		if ( $s['note'] ) {
			echo '<small>' . esc_html( $s['note'] ) . '</small>';
		}
		if ( ! ar_has_portal() && current_user_can( 'manage_options' ) ) {
			echo '<small class="ar-portal__hint">' . esc_html__( 'Admin note: set your portal URL in Appearance → Customize → Arctic Resto Settings. Buttons currently point to the Contact page.', 'arctic-resto' ) . '</small>';
		}
		echo '</div></div>';
		$this->close();
	}
}
