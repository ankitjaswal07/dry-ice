<?php
/**
 * Dynamic widgets: Services, Testimonials, Posts.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
class W_Services extends Base {
	protected $ico = 'eicon-gallery-grid';

	public function get_name() {
		return 'ar_services';
	}
	public function get_title() {
		return __( 'AR Services (dynamic)', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Our dry ice cleaning services', 'One process. {{Seven demanding industries.}}', '' );
		$this->section(
			'c1',
			'Query & layout',
			array(
				'layout'  => array(
					'l' => 'Layout',
					't' => 'select',
					'd' => 'bento',
					'o' => array(
						'bento'       => 'Bento grid (image cards)',
						'grid'        => 'Simple card grid',
						'alternating' => 'Alternating rows (detailed)',
					),
				),
				'count'   => array( 'l' => 'Number of services (-1 = all)', 't' => 'num', 'd' => -1, 'min' => -1, 'max' => 24 ),
				'exclude' => array( 'l' => 'Exclude the current service (for related lists)', 't' => 'switch', 'd' => '' ),
				'bullets' => array( 'l' => 'Show key points on hover', 't' => 'switch', 'd' => 'yes' ),
			)
		);
		$this->style_controls( 'frost', 'lg' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = array( 'posts_per_page' => (int) $s['count'] );
		if ( 'yes' === $s['exclude'] && is_singular( 'ar_service' ) ) {
			$args['post__not_in'] = array( get_the_ID() );
		}
		$posts = ar_get_services( $args );
		$this->open( $s, 'ar-svcsec' );
		$this->heading( $s );
		if ( ! $posts ) {
			echo '<p class="ar-empty">' . esc_html__( 'No services yet. Add some under Services → Add New, or run the demo importer.', 'arctic-resto' ) . '</p>';
			$this->close();
			return;
		}
		if ( 'alternating' === $s['layout'] ) {
			echo '<div class="ar-alts">';
			foreach ( $posts as $i => $p ) {
				$m = ar_service_meta( $p->ID );
				echo '<div class="ar-alt' . ( $i % 2 ? ' ar-alt--rev' : '' ) . '"><div class="ar-alt__img"' . ar_rv( 0, $i % 2 ? 'right' : 'left' ) . '>' . get_the_post_thumbnail( $p->ID, 'ar-card', array( 'loading' => 'lazy' ) ) . '<span class="ar-ico">' . ar_icon( $m['icon'] ) . '</span></div>'; // phpcs:ignore
				echo '<div' . ar_rv( 1, $i % 2 ? 'left' : 'right' ) . '><p class="ar-eyebrow"><i></i>0' . (int) ( $i + 1 ) . ' · ' . esc_html( $m['tagline'] ) . '</p><h3>' . esc_html( get_the_title( $p ) ) . '</h3><p>' . esc_html( has_excerpt( $p ) ? $p->post_excerpt : '' ) . '</p><ul class="ar-checks">'; // phpcs:ignore
				foreach ( $m['points'] as $pt ) {
					echo '<li>' . ar_svg( 'check' ) . '<span>' . esc_html( $pt ) . '</span></li>'; // phpcs:ignore
				}
				echo '</ul><a class="ar-btn ar-btn--dark" href="' . esc_url( get_permalink( $p ) ) . '"><span>' . esc_html( sprintf( /* translators: %s service name */ __( 'Explore %s', 'arctic-resto' ), get_the_title( $p ) ) ) . '</span>' . ar_svg( 'arrow' ) . '</a></div></div>'; // phpcs:ignore
			}
			echo '</div>';
		} else {
			echo '<div class="' . ( 'grid' === $s['layout'] ? 'ar-grid ar-cols-3' : 'ar-bento' ) . '">';
			foreach ( $posts as $i => $p ) {
				echo ar_service_card( $p, $i, $s['layout'], 'yes' === $s['bullets'] ); // phpcs:ignore
			}
			echo '</div>';
		}
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Testimonials extends Base {
	protected $ico = 'eicon-testimonial-carousel';

	public function get_name() {
		return 'ar_testimonials';
	}
	public function get_title() {
		return __( 'AR Testimonials (dynamic)', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( 'Client stories', "Trusted by teams who can't afford {{downtime}}", '' );
		$this->section( 'c1', 'Query', array( 'count' => array( 'l' => 'Number of testimonials', 't' => 'num', 'd' => 6, 'min' => 1, 'max' => 20 ) ) );
		$this->style_controls( 'void', 'lg' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$posts = get_posts(
			array(
				'post_type'      => 'ar_testimonial',
				'posts_per_page' => (int) $s['count'],
				'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
			)
		);
		$this->open( $s, 'ar-testi' );
		$this->heading( $s );
		if ( ! $posts ) {
			echo '<p class="ar-empty">' . esc_html__( 'No testimonials yet. Add some under Testimonials → Add New.', 'arctic-resto' ) . '</p>';
			$this->close();
			return;
		}
		echo '<div class="ar-carousel" data-ar-carousel' . ar_rv() . '><div class="ar-glass ar-carousel__box">' . ar_svg( 'quote', 'ar-i ar-carousel__q' ); // phpcs:ignore
		foreach ( $posts as $i => $p ) {
			$name = get_the_title( $p );
			$ini  = '';
			foreach ( array_slice( preg_split( '/\s+/', trim( $name ) ), 0, 2 ) as $w ) {
				$ini .= strtoupper( substr( $w, 0, 1 ) );
			}
			echo '<figure class="ar-slide' . ( 0 === $i ? ' is-active' : '' ) . '">'; // phpcs:ignore
			if ( get_post_meta( $p->ID, '_ar_tag', true ) ) {
				echo '<span class="ar-tag ar-tag--glow">' . esc_html( get_post_meta( $p->ID, '_ar_tag', true ) ) . '</span>';
			}
			echo '<blockquote>“' . esc_html( wp_strip_all_tags( $p->post_content ) ) . '”</blockquote><figcaption><span class="ar-avatar">' . esc_html( $ini ) . '</span><span><b>' . esc_html( $name ) . '</b><small>' . esc_html( get_post_meta( $p->ID, '_ar_role', true ) ) . '</small></span></figcaption></figure>'; // phpcs:ignore
		}
		echo '</div><div class="ar-carousel__nav"><div class="ar-dots">';
		foreach ( $posts as $i => $p ) {
			echo '<button type="button" class="' . ( 0 === $i ? 'is-active' : '' ) . '" aria-label="' . esc_attr( sprintf( /* translators: %d slide number */ __( 'Testimonial %d', 'arctic-resto' ), $i + 1 ) ) . '"></button>';
		}
		echo '</div><div class="ar-arrows"><button type="button" data-dir="-1" aria-label="' . esc_attr__( 'Previous', 'arctic-resto' ) . '">' . ar_svg( 'chev-l' ) . '</button><button type="button" data-dir="1" aria-label="' . esc_attr__( 'Next', 'arctic-resto' ) . '">' . ar_svg( 'chev-r' ) . '</button></div></div></div>'; // phpcs:ignore
		$this->close();
	}
}

/* ------------------------------------------------------------------ */
class W_Posts extends Base {
	protected $ico = 'eicon-posts-grid';

	public function get_name() {
		return 'ar_posts';
	}
	public function get_title() {
		return __( 'AR Blog Posts (dynamic)', 'arctic-resto' );
	}

	protected function register_controls() {
		$this->heading_controls( '', '', '' );
		$this->section(
			'c1',
			'Query & layout',
			array(
				'count'    => array( 'l' => 'Posts per page', 't' => 'num', 'd' => 6, 'min' => 1, 'max' => 24 ),
				'category' => array( 'l' => 'Limit to category slug (optional)', 'd' => '' ),
				'filters'  => array( 'l' => 'Show search + category filters', 't' => 'switch', 'd' => '' ),
				'featured' => array( 'l' => 'Large featured first post', 't' => 'switch', 'd' => '' ),
				'more_t'   => array( 'l' => '"View all" link text', 'd' => '' ),
				'more_u'   => array( 'l' => '"View all" link', 't' => 'url' ),
			)
		);
		$this->style_controls( 'light', 'lg' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$cat  = $s['category'];
		$q    = '';
		$page = 1;
		if ( 'yes' === $s['filters'] ) { // phpcs:disable WordPress.Security.NonceVerification
			$cat  = isset( $_GET['ar_cat'] ) ? sanitize_title( wp_unslash( $_GET['ar_cat'] ) ) : $cat;
			$q    = isset( $_GET['ar_s'] ) ? sanitize_text_field( wp_unslash( $_GET['ar_s'] ) ) : '';
			$page = isset( $_GET['pg'] ) ? max( 1, (int) $_GET['pg'] ) : 1;
		} // phpcs:enable
		$args = array(
			'post_type'           => 'post',
			'posts_per_page'      => (int) $s['count'],
			'paged'               => $page,
			'ignore_sticky_posts' => true,
		);
		if ( $cat ) {
			$args['category_name'] = $cat;
		}
		if ( $q ) {
			$args['s'] = $q;
		}
		$query = new \WP_Query( $args );
		$this->open( $s, 'ar-postsec' );
		$this->heading( $s );

		if ( 'yes' === $s['filters'] ) {
			$base = remove_query_arg( array( 'pg', 'ar_cat' ) );
			echo '<form class="ar-blogtools" method="get" action="' . esc_url( remove_query_arg( array( 'pg', 'ar_s' ) ) ) . '"><div class="ar-chips">'; // phpcs:ignore
			echo '<a class="' . ( $cat ? '' : 'is-active' ) . '" href="' . esc_url( $base ) . '">' . esc_html__( 'All', 'arctic-resto' ) . '</a>';
			foreach ( get_categories( array( 'hide_empty' => true ) ) as $c ) {
				echo '<a class="' . ( $cat === $c->slug ? 'is-active' : '' ) . '" href="' . esc_url( add_query_arg( 'ar_cat', $c->slug, $base ) ) . '">' . esc_html( $c->name ) . '</a>';
			}
			echo '</div><label class="ar-search">' . ar_svg( 'search' ) . '<input type="search" name="ar_s" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'Search articles…', 'arctic-resto' ) . '"></label></form>'; // phpcs:ignore
		}

		if ( ! $query->have_posts() ) {
			echo '<p class="ar-empty">' . esc_html__( 'No articles found.', 'arctic-resto' ) . '</p>';
		} else {
			$list = $query->posts;
			if ( 'yes' === $s['featured'] && 1 === $page && ! $q ) {
				$f    = array_shift( $list );
				$cats = get_the_category( $f->ID );
				echo '<a class="ar-featpost" href="' . esc_url( get_permalink( $f ) ) . '"' . ar_rv() . '><span class="ar-featpost__img">' . get_the_post_thumbnail( $f->ID, 'large', array( 'loading' => 'lazy' ) ) . '</span><span class="ar-featpost__body"><span class="ar-tag ar-tag--glow">' . esc_html( __( 'Featured', 'arctic-resto' ) . ( $cats ? ' · ' . $cats[0]->name : '' ) ) . '</span><strong>' . esc_html( get_the_title( $f ) ) . '</strong><em>' . esc_html( wp_trim_words( has_excerpt( $f ) ? $f->post_excerpt : wp_strip_all_tags( $f->post_content ), 30 ) ) . '</em><small>' . esc_html( get_the_date( '', $f ) ) . ' · ' . esc_html( ar_read_time( $f ) ) . '</small><span class="ar-link ar-link--light">' . esc_html__( 'Read article', 'arctic-resto' ) . ' ' . ar_svg( 'arrow' ) . '</span></span></a>'; // phpcs:ignore
			}
			echo '<div class="ar-grid ar-cols-3">';
			foreach ( $list as $i => $p ) {
				echo ar_post_card( $p, $i ); // phpcs:ignore
			}
			echo '</div>';
			if ( 'yes' === $s['filters'] && $query->max_num_pages > 1 ) {
				echo '<nav class="ar-pager" aria-label="' . esc_attr__( 'Pagination', 'arctic-resto' ) . '">';
				for ( $i = 1; $i <= $query->max_num_pages; $i++ ) {
					echo '<a class="' . ( $i === $page ? 'is-active' : '' ) . '" href="' . esc_url( add_query_arg( 'pg', $i ) ) . '">' . (int) $i . '</a>';
				}
				echo '</nav>';
			}
		}
		wp_reset_postdata();
		if ( $s['more_t'] ) {
			echo '<p class="ar-more">' . ar_btn( $s['more_u'], $s['more_t'], 'outline' ) . '</p>'; // phpcs:ignore
		}
		$this->close();
	}
}
