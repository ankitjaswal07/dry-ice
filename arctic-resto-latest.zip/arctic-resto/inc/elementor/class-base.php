<?php
/**
 * Base widget with compact control builders and shared section markup.
 *
 * @package ArcticResto
 */

namespace ArcticResto;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

abstract class Base extends Widget_Base {

	protected $ico = 'eicon-apps';

	public function get_icon() {
		return $this->ico;
	}

	public function get_categories() {
		return array( 'arctic-resto' );
	}

	public function get_keywords() {
		return array( 'arctic', 'resto', 'dry ice', 'cleaning' );
	}

	/* ---------------- control shorthand ---------------- */

	/**
	 * Convert a shorthand field definition to Elementor control args.
	 * Keys: l=label, t=type, d=default, o=options, rows, min, max, step, desc.
	 */
	protected function ctl( $f ) {
		$map = array(
			'text'   => Controls_Manager::TEXT,
			'area'   => Controls_Manager::TEXTAREA,
			'icon'   => Controls_Manager::ICONS,
			'media'  => Controls_Manager::MEDIA,
			'url'    => Controls_Manager::URL,
			'select' => Controls_Manager::SELECT,
			'num'    => Controls_Manager::NUMBER,
			'wys'    => Controls_Manager::WYSIWYG,
			'switch' => Controls_Manager::SWITCHER,
		);
		$t = isset( $f['t'] ) ? $f['t'] : 'text';
		$a = array(
			'label' => $f['l'],
			'type'  => $map[ $t ],
		);
		if ( isset( $f['d'] ) ) {
			$a['default'] = $f['d'];
		}
		switch ( $t ) {
			case 'icon':
				if ( ! isset( $f['d'] ) ) {
					$a['default'] = array(
						'value'   => 'fas fa-snowflake',
						'library' => 'fa-solid',
					);
				}
				break;
			case 'media':
				$a['default'] = array( 'url' => '' );
				break;
			case 'url':
				$a['default']     = array( 'url' => '' );
				$a['placeholder'] = 'https://your-link.com';
				break;
			case 'select':
				$a['options'] = $f['o'];
				break;
			case 'switch':
				$a['return_value'] = 'yes';
				$a['default']      = isset( $f['d'] ) ? $f['d'] : '';
				break;
			case 'area':
				$a['rows'] = isset( $f['rows'] ) ? $f['rows'] : 3;
				break;
			case 'num':
				foreach ( array( 'min', 'max', 'step' ) as $k ) {
					if ( isset( $f[ $k ] ) ) {
						$a[ $k ] = $f[ $k ];
					}
				}
				break;
		}
		if ( isset( $f['desc'] ) ) {
			$a['description'] = $f['desc'];
		}
		return $a;
	}

	protected function section( $id, $label, $fields, $tab = Controls_Manager::TAB_CONTENT ) {
		$this->start_controls_section(
			$id,
			array(
				'label' => $label,
				'tab'   => $tab,
			)
		);
		foreach ( $fields as $name => $f ) {
			$this->add_control( $name, $this->ctl( $f ) );
		}
		$this->end_controls_section();
	}

	protected function rep( $id, $label, $fields, $default = array(), $title = 'title' ) {
		$this->start_controls_section(
			'sec_' . $id,
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);
		$r = new Repeater();
		foreach ( $fields as $name => $f ) {
			$r->add_control( $name, $this->ctl( $f ) );
		}
		$this->add_control(
			$id,
			array(
				'label'       => $label,
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $r->get_controls(),
				'default'     => $default,
				'title_field' => '{{{ ' . $title . ' }}}',
			)
		);
		$this->end_controls_section();
	}

	/** Eyebrow / title / subtitle / alignment. */
	protected function heading_controls( $eyebrow = '', $title = '', $sub = '', $align = 'center' ) {
		$this->section(
			'sec_head',
			__( 'Heading', 'arctic-resto' ),
			array(
				'eyebrow'  => array( 'l' => __( 'Eyebrow', 'arctic-resto' ), 'd' => $eyebrow ),
				'title'    => array( 'l' => __( 'Title', 'arctic-resto' ), 't' => 'area', 'd' => $title, 'rows' => 2, 'desc' => __( 'Wrap words in {{double braces}} for gradient text.', 'arctic-resto' ) ),
				'subtitle' => array( 'l' => __( 'Subtitle', 'arctic-resto' ), 't' => 'area', 'd' => $sub ),
				'align'    => array( 'l' => __( 'Alignment', 'arctic-resto' ), 't' => 'select', 'd' => $align, 'o' => array( 'center' => __( 'Center', 'arctic-resto' ), 'left' => __( 'Left', 'arctic-resto' ) ) ),
			)
		);
	}

	/** Theme / spacing / anchor controls (Style tab). */
	protected function style_controls( $theme = 'light', $pad = 'lg' ) {
		$this->section(
			'sec_style',
			__( 'Section Style', 'arctic-resto' ),
			array(
				'theme'  => array(
					'l' => __( 'Background theme', 'arctic-resto' ),
					't' => 'select',
					'd' => $theme,
					'o' => array(
						'light'    => __( 'White', 'arctic-resto' ),
						'frost'    => __( 'Frost (light blue)', 'arctic-resto' ),
						'dark'     => __( 'Dark navy', 'arctic-resto' ),
						'void'     => __( 'Deep space', 'arctic-resto' ),
						'gradient' => __( 'Blue gradient', 'arctic-resto' ),
					),
				),
				'pad'    => array(
					'l' => __( 'Vertical spacing', 'arctic-resto' ),
					't' => 'select',
					'd' => $pad,
					'o' => array(
						'none' => __( 'None', 'arctic-resto' ),
						'sm'   => __( 'Small', 'arctic-resto' ),
						'md'   => __( 'Medium', 'arctic-resto' ),
						'lg'   => __( 'Large', 'arctic-resto' ),
					),
				),
				'anchor' => array( 'l' => __( 'Anchor ID (optional)', 'arctic-resto' ), 'd' => '' ),
			),
			Controls_Manager::TAB_STYLE
		);
	}

	/* ---------------- render helpers ---------------- */

	protected function open( $s, $cls = '' ) {
		$theme = isset( $s['theme'] ) ? $s['theme'] : 'light';
		$pad   = isset( $s['pad'] ) ? $s['pad'] : 'lg';
		$id    = ! empty( $s['anchor'] ) ? ' id="' . esc_attr( sanitize_title( ltrim( (string) $s['anchor'], '#' ) ) ) . '"' : '';
		echo '<section' . $id . ' class="ar-sec ar-t-' . esc_attr( $theme ) . ' ar-pad-' . esc_attr( $pad ) . ' ' . esc_attr( $cls ) . '">'; // phpcs:ignore
		if ( in_array( $theme, array( 'dark', 'void', 'gradient' ), true ) ) {
			echo '<i class="ar-fog ar-fog--1" aria-hidden="true"></i>';
		}
		echo '<div class="ar-wrap">';
	}

	protected function close() {
		echo '</div></section>';
	}

	protected function heading( $s, $align = null ) {
		if ( empty( $s['title'] ) && empty( $s['eyebrow'] ) && empty( $s['subtitle'] ) ) {
			return;
		}
		$al = $align ? $align : ( isset( $s['align'] ) ? $s['align'] : 'center' );
		echo '<header class="ar-head ar-head--' . esc_attr( $al ) . '"' . ar_rv() . '>'; // phpcs:ignore
		if ( ! empty( $s['eyebrow'] ) ) {
			echo '<p class="ar-eyebrow"><i></i>' . esc_html( $s['eyebrow'] ) . '</p>';
		}
		if ( ! empty( $s['title'] ) ) {
			echo '<h2 class="ar-h2">' . ar_title( $s['title'] ) . '</h2>'; // phpcs:ignore
		}
		if ( ! empty( $s['subtitle'] ) ) {
			echo '<p class="ar-sub">' . esc_html( $s['subtitle'] ) . '</p>';
		}
		echo '</header>';
	}

	protected function items( $s, $key = 'items' ) {
		return ( isset( $s[ $key ] ) && is_array( $s[ $key ] ) ) ? $s[ $key ] : array();
	}

	/** Safe static helper for counter markup. */
	protected function counter( $to, $prefix = '', $suffix = '' ) {
		return '<b class="ar-count" data-ar-count data-to="' . esc_attr( (string) (float) $to ) . '" data-prefix="' . esc_attr( $prefix ) . '" data-suffix="' . esc_attr( $suffix ) . '">' . esc_html( $prefix . '0' . $suffix ) . '</b>';
	}
}
