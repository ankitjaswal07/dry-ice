<?php
/**
 * Elementor integration: theme-builder locations, widget category and widget loader.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Theme Builder: header, footer, single, archive locations */
add_action(
	'elementor/theme/register_locations',
	function ( $manager ) {
		$manager->register_all_core_location();
	}
);

add_action(
	'elementor/elements/categories_registered',
	function ( $manager ) {
		$manager->add_category(
			'arctic-resto',
			array(
				'title' => __( 'Arctic Resto', 'arctic-resto' ),
				'icon'  => 'eicon-star',
			),
			1
		);
	}
);

add_action(
	'elementor/widgets/register',
	function ( $widgets ) {
		$dir = AR_DIR . '/inc/elementor/';
		require_once $dir . 'class-base.php';
		foreach ( array( 'hero', 'blocks', 'dynamic', 'interactive', 'forms', 'seo', 'territory', 'extra' ) as $f ) {
			require_once $dir . 'widgets-' . $f . '.php';
		}
		$classes = array(
			'W_Hero',
			'W_PageHero',
			'W_IconBoxes',
			'W_Stats',
			'W_Split',
			'W_Marquee',
			'W_Cta',
			'W_Timeline',
			'W_Team',
			'W_Compare',
			'W_Services',
			'W_Testimonials',
			'W_Posts',
			'W_BeforeAfter',
			'W_Faq',
			'W_Calculator',
			'W_Territories',
			'W_Gallery',
			'W_Science',
			'W_Form',
			'W_Estimator',
			'W_Answer',
			'W_Article',
			'W_Portal',
			'W_TerrHero',
			'W_Coverage',
			'W_TerrCards',
			'W_PageNav',
			'W_Fit',
		);
		foreach ( $classes as $c ) {
			$cls = '\\ArcticResto\\' . $c;
			$widgets->register( new $cls() );
		}
	}
);

/* Admin notice when Elementor is missing */
add_action(
	'admin_notices',
	function () {
		if ( did_action( 'elementor/loaded' ) || ! current_user_can( 'install_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>Arctic Resto</strong> ' . esc_html__( 'works best with the free Elementor plugin. Install and activate Elementor to edit every page visually and to import the demo content.', 'arctic-resto' ) . ' <a href="' . esc_url( admin_url( 'plugin-install.php?s=elementor&tab=search&type=term' ) ) . '">' . esc_html__( 'Install Elementor', 'arctic-resto' ) . '</a></p></div>';
	}
);
