<?php
/**
 * Template helpers shared by the theme and the Elementor widgets.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
/* Options                                                             */
/* ------------------------------------------------------------------ */
function ar_mod( $key, $default = '' ) {
	$v = get_theme_mod( $key, $default );
	return ( '' === $v || false === $v || null === $v ) ? $default : $v;
}
function ar_phone() {
	return ar_mod( 'ar_phone', '203-404-5788' );
}
function ar_phone_href() {
	return 'tel:+1' . preg_replace( '/\D+/', '', ar_phone() );
}
function ar_email() {
	return ar_mod( 'ar_email', 'info@arcticresto.com' );
}
function ar_location() {
	return ar_mod( 'ar_location', 'Serving NJ & CT' );
}
function ar_abs_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return home_url( '/' );
	}
	if ( '{portal}' === $url ) {
		return ar_portal_url();
	}
	if ( '{portal-login}' === $url ) {
		return ar_portal_login_url();
	}
	if ( '{portal-register}' === $url ) {
		return ar_portal_register_url();
	}
	if ( '{portal-dashboard}' === $url ) {
		return ar_portal_dashboard_url();
	}
	return ( 0 === strpos( $url, '/' ) ) ? home_url( $url ) : $url;
}

/* ------------------------------------------------------------------ */
/* Franchise portal                                                    */
/* ------------------------------------------------------------------ */
function ar_portal_opt( $key ) {
	return trim( (string) get_theme_mod( $key, '' ) );
}
/** True once at least one portal URL has been entered in the Customizer. */
function ar_has_portal() {
	foreach ( array( 'ar_portal_url', 'ar_portal_login', 'ar_portal_register', 'ar_portal_dash' ) as $k ) {
		if ( '' !== ar_portal_opt( $k ) ) {
			return true;
		}
	}
	return false;
}
/** Login page. Falls back to the portal URL, then the WordPress login. Filter: ar_portal_login_url. */
function ar_portal_login_url() {
	$u = ar_portal_opt( 'ar_portal_login' );
	if ( '' === $u ) {
		$u = ar_portal_opt( 'ar_portal_url' );
	}
	if ( '' === $u ) {
		$u = wp_login_url();
	}
	return apply_filters( 'ar_portal_login_url', esc_url_raw( $u ) );
}
/** Registration page. Falls back to the portal URL, WordPress registration (if enabled), then Contact. */
function ar_portal_register_url() {
	$u = ar_portal_opt( 'ar_portal_register' );
	if ( '' === $u ) {
		$u = ar_portal_opt( 'ar_portal_url' );
	}
	if ( '' === $u ) {
		$u = get_option( 'users_can_register' ) ? wp_registration_url() : home_url( '/contact/' );
	}
	return apply_filters( 'ar_portal_register_url', esc_url_raw( $u ) );
}
/** Dashboard for logged-in owners. Empty when none is configured. */
function ar_portal_dashboard_url() {
	$u = ar_portal_opt( 'ar_portal_dash' );
	if ( '' === $u ) {
		$u = ar_portal_opt( 'ar_portal_url' );
	}
	return apply_filters( 'ar_portal_dashboard_url', $u ? esc_url_raw( $u ) : '' );
}
/** Main portal entry (apply). Same as the register URL unless a portal URL is set. */
function ar_portal_url() {
	$u = ar_portal_opt( 'ar_portal_url' );
	return $u ? esc_url_raw( $u ) : ar_portal_register_url();
}
function ar_is_offsite( $url ) {
	$h = wp_parse_url( $url, PHP_URL_HOST );
	$s = wp_parse_url( home_url(), PHP_URL_HOST );
	return $h && $s && strtolower( $h ) !== strtolower( $s );
}

/** Breadcrumb trail as [ [name, url], … ] — used by the visible breadcrumbs and the schema graph. */
function ar_crumb_list() {
	$crumbs = array( array( __( 'Home', 'arctic-resto' ), home_url( '/' ) ) );
	$id     = get_queried_object_id();
	if ( is_singular( 'ar_service' ) ) {
		$sp = get_page_by_path( 'services' );
		if ( $sp ) {
			$crumbs[] = array( get_the_title( $sp ), get_permalink( $sp ) );
		}
	} elseif ( is_singular( 'post' ) ) {
		$bp = get_page_by_path( 'blog' );
		if ( $bp ) {
			$crumbs[] = array( get_the_title( $bp ), get_permalink( $bp ) );
		}
	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( $id ) ) as $a ) {
			$crumbs[] = array( get_the_title( $a ), get_permalink( $a ) );
		}
	}
	$crumbs[] = array( $id ? get_the_title( $id ) : wp_get_document_title(), $id ? get_permalink( $id ) : '' );
	return $crumbs;
}
function ar_theme_img( $name ) {
	return AR_URI . '/assets/images/' . $name . '.jpg';
}

/* ------------------------------------------------------------------ */
/* Output helpers                                                      */
/* ------------------------------------------------------------------ */
function ar_svg( $name, $class = 'ar-i' ) {
	$p = array(
		'arrow'    => '<path d="M5 12h14M13 5l7 7-7 7"/>',
		'arrow-up' => '<path d="M12 19V5M5 12l7-7 7 7"/>',
		'arrow-ur' => '<path d="M7 17 17 7M8 7h9v9"/>',
		'phone'    => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
		'mail'     => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
		'pin'      => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
		'clock'    => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
		'check'    => '<path d="M20 6 9 17l-5-5"/>',
		'x'        => '<path d="M18 6 6 18M6 6l12 12"/>',
		'chev'     => '<path d="m6 9 6 6 6-6"/>',
		'chev-l'   => '<path d="m15 18-6-6 6-6"/>',
		'chev-r'   => '<path d="m9 18 6-6-6-6"/>',
		'menu'     => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		'snow'     => '<path d="M12 2v20M4.9 7l14.2 10M4.9 17 19.1 7M9 4l3 2 3-2M9 20l3-2 3 2"/>',
		'quote'    => '<path d="M3 21c3 0 7-1 7-8V5a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h4M15 21c3 0 7-1 7-8V5a1 1 0 0 0-1-1h-5a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h4"/>',
		'search'   => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'expand'   => '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
		'drag'     => '<path d="m18 8 4 4-4 4M6 8l-4 4 4 4M2 12h20"/>',
		'lock'     => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
		'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
	);
	if ( ! isset( $p[ $name ] ) ) {
		return '';
	}
	return '<svg class="' . esc_attr( $class ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p[ $name ] . '</svg>';
}

/** Escape a title and turn {{words}} into gradient text. */
function ar_title( $text ) {
	$text = esc_html( $text );
	return preg_replace( '/\{\{(.+?)\}\}/s', '<span class="ar-grad">$1</span>', $text );
}

function ar_link_attrs( $link ) {
	if ( empty( $link['url'] ) ) {
		return ' href="#"';
	}
	$abs = ar_abs_url( $link['url'] );
	$a   = ' href="' . esc_url( $abs ) . '"';
	$rel = array();
	if ( ! empty( $link['is_external'] ) || ar_is_offsite( $abs ) ) {
		$a    .= ' target="_blank"';
		$rel[] = 'noopener';
	}
	if ( ! empty( $link['nofollow'] ) ) {
		$rel[] = 'nofollow';
	}
	if ( $rel ) {
		$a .= ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"';
	}
	return $a;
}

function ar_btn( $link, $text, $variant = 'primary', $arrow = true ) {
	if ( '' === trim( (string) $text ) ) {
		return '';
	}
	return '<a class="ar-btn ar-btn--' . esc_attr( $variant ) . '"' . ar_link_attrs( (array) $link ) . '><span>' . esc_html( $text ) . '</span>' . ( $arrow ? ar_svg( 'arrow' ) : '' ) . '</a>';
}

/** Render an Elementor media control value as an <img>. */
function ar_media( $m, $size = 'large', $attr = array() ) {
	if ( ! empty( $m['id'] ) ) {
		return wp_get_attachment_image( (int) $m['id'], $size, false, $attr );
	}
	if ( ! empty( $m['url'] ) ) {
		$attr = array_merge(
			array(
				'loading'  => 'lazy',
				'decoding' => 'async',
				'alt'      => '',
			),
			$attr
		);
		$a    = '';
		foreach ( $attr as $k => $v ) {
			$a .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		return '<img src="' . esc_url( $m['url'] ) . '"' . $a . '>';
	}
	return '';
}

/** Render an icon (Elementor icon array or a "fas fa-x" string). */
function ar_icon( $icon, $class = '' ) {
	if ( is_string( $icon ) && '' !== $icon ) {
		$lib  = 0 === strpos( $icon, 'fab ' ) ? 'fa-brands' : ( 0 === strpos( $icon, 'far ' ) ? 'fa-regular' : 'fa-solid' );
		$icon = array(
			'value'   => $icon,
			'library' => $lib,
		);
	}
	if ( empty( $icon['value'] ) || ! class_exists( '\Elementor\Icons_Manager' ) ) {
		return '';
	}
	// Elementor's SVG-icon mode does `$attributes['class'][] = ...`, so `class` MUST be an array.
	// Passing a string (even an empty one) is a fatal "[] operator not supported for strings".
	$attrs = array( 'aria-hidden' => 'true' );
	if ( is_string( $class ) && '' !== trim( $class ) ) {
		$attrs['class'] = preg_split( '/\s+/', trim( $class ) );
	} elseif ( is_array( $class ) && $class ) {
		$attrs['class'] = array_values( $class );
	}

	ob_start();
	try {
		\Elementor\Icons_Manager::render_icon( $icon, $attrs );
	} catch ( \Throwable $e ) {
		// An icon must never be able to break a whole page.
		ob_end_clean();
		return '';
	}
	return ob_get_clean();
}

/** Scroll-reveal attributes. */
function ar_rv( $i = 0, $dir = '' ) {
	$d = min( (int) $i, 6 ) * 90;
	return ' data-ar-reveal' . ( $dir ? ' data-dir="' . esc_attr( $dir ) . '"' : '' ) . ' style="--d:' . $d . 'ms"';
}

function ar_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ), 'strlen' ) );
}

function ar_is_elementor( $id = 0 ) {
	$id = $id ? $id : get_the_ID();
	return $id && 'builder' === get_post_meta( $id, '_elementor_edit_mode', true );
}

/* ------------------------------------------------------------------ */
/* Services                                                            */
/* ------------------------------------------------------------------ */
function ar_service_meta( $id ) {
	return array(
		'tagline'  => get_post_meta( $id, '_ar_tagline', true ),
		'icon'     => get_post_meta( $id, '_ar_icon', true ) ? get_post_meta( $id, '_ar_icon', true ) : 'fas fa-snowflake',
		'points'   => ar_lines( get_post_meta( $id, '_ar_points', true ) ),
		'surfaces' => ar_lines( get_post_meta( $id, '_ar_surfaces', true ) ),
	);
}

function ar_get_services( $args = array() ) {
	return get_posts(
		wp_parse_args(
			$args,
			array(
				'post_type'        => 'ar_service',
				'posts_per_page'   => -1,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'date'       => 'ASC',
				),
				'suppress_filters' => false,
			)
		)
	);
}

function ar_service_card( $p, $i = 0, $layout = 'bento', $bullets = true ) {
	$m     = ar_service_meta( $p->ID );
	$thumb = get_the_post_thumbnail( $p->ID, 'ar-card', array( 'loading' => 'lazy', 'decoding' => 'async' ) );
	$num   = str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT );
	ob_start();
	if ( 'grid' === $layout ) {
		?>
		<a class="ar-card ar-gcard" href="<?php echo esc_url( get_permalink( $p ) ); ?>" data-ar-tilt<?php echo ar_rv( $i % 3 ); // phpcs:ignore ?>>
			<span class="ar-gcard__img"><?php echo $thumb; // phpcs:ignore ?><span class="ar-ico"><?php echo ar_icon( $m['icon'] ); // phpcs:ignore ?></span></span>
			<span class="ar-gcard__body">
				<strong><?php echo esc_html( get_the_title( $p ) ); ?></strong>
				<em><?php echo esc_html( $m['tagline'] ); ?></em>
				<span class="ar-link"><?php esc_html_e( 'Learn more', 'arctic-resto' ); ?> <?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></span>
			</span>
		</a>
		<?php
	} else {
		?>
		<a class="ar-svc" href="<?php echo esc_url( get_permalink( $p ) ); ?>" data-ar-tilt<?php echo ar_rv( $i % 4 ); // phpcs:ignore ?>>
			<?php echo $thumb; // phpcs:ignore ?>
			<span class="ar-svc__shade"></span>
			<span class="ar-svc__in">
				<span class="ar-svc__top">
					<span class="ar-ico"><?php echo ar_icon( $m['icon'] ); // phpcs:ignore ?></span>
					<span class="ar-svc__go"><?php echo ar_svg( 'arrow-ur' ); // phpcs:ignore ?></span>
				</span>
				<span class="ar-svc__txt">
					<small><?php echo esc_html( $num ); ?></small>
					<strong><?php echo esc_html( get_the_title( $p ) ); ?></strong>
					<em><?php echo esc_html( $m['tagline'] ); ?></em>
					<?php if ( $bullets && $m['points'] ) : ?>
						<span class="ar-svc__pts"><?php foreach ( array_slice( $m['points'], 0, 3 ) as $pt ) : ?><i><?php echo esc_html( $pt ); ?></i><?php endforeach; ?></span>
					<?php endif; ?>
				</span>
			</span>
		</a>
		<?php
	}
	return ob_get_clean();
}

/* ------------------------------------------------------------------ */
/* Blog                                                                */
/* ------------------------------------------------------------------ */
function ar_read_time( $post ) {
	$words = str_word_count( wp_strip_all_tags( $post->post_content ) );
	return max( 1, (int) ceil( $words / 200 ) ) . ' ' . __( 'min read', 'arctic-resto' );
}

function ar_post_card( $p, $i = 0 ) {
	$cats = get_the_category( $p->ID );
	ob_start();
	?>
	<article class="ar-card ar-post" data-ar-tilt<?php echo ar_rv( $i % 3 ); // phpcs:ignore ?>>
		<a class="ar-post__img" href="<?php echo esc_url( get_permalink( $p ) ); ?>" tabindex="-1" aria-hidden="true">
			<?php echo get_the_post_thumbnail( $p->ID, 'ar-card', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ) ); // phpcs:ignore ?>
			<?php if ( $cats ) : ?><span class="ar-tag"><?php echo esc_html( $cats[0]->name ); ?></span><?php endif; ?>
		</a>
		<div class="ar-post__body">
			<p class="ar-meta"><?php echo esc_html( get_the_date( '', $p ) ); ?> · <?php echo esc_html( ar_read_time( $p ) ); ?></p>
			<h3><a href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a></h3>
			<p><?php echo esc_html( wp_trim_words( has_excerpt( $p ) ? $p->post_excerpt : wp_strip_all_tags( $p->post_content ), 24 ) ); ?></p>
			<a class="ar-link" href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php esc_html_e( 'Read article', 'arctic-resto' ); ?> <?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></a>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------------------ */
/* Breadcrumbs                                                         */
/* ------------------------------------------------------------------ */
function ar_breadcrumbs() {
	$crumbs = array( array( __( 'Home', 'arctic-resto' ), home_url( '/' ) ) );
	$id     = get_queried_object_id();
	if ( is_singular( 'ar_service' ) ) {
		$sp = get_page_by_path( 'services' );
		if ( $sp ) {
			$crumbs[] = array( get_the_title( $sp ), get_permalink( $sp ) );
		}
	} elseif ( is_singular( 'post' ) ) {
		$bp = get_page_by_path( 'blog' );
		if ( $bp ) {
			$crumbs[] = array( get_the_title( $bp ), get_permalink( $bp ) );
		}
	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( $id ) ) as $a ) {
			$crumbs[] = array( get_the_title( $a ), get_permalink( $a ) );
		}
	}
	$crumbs[] = array( $id ? get_the_title( $id ) : wp_get_document_title(), '' );
	$out      = '<nav class="ar-crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'arctic-resto' ) . '">';
	$last     = count( $crumbs ) - 1;
	foreach ( $crumbs as $k => $c ) {
		if ( $k ) {
			$out .= '<span class="ar-crumbs__sep">/</span>';
		}
		$out .= ( $k === $last || '' === $c[1] ) ? '<span class="ar-crumbs__cur">' . esc_html( $c[0] ) . '</span>' : '<a href="' . esc_url( $c[1] ) . '">' . esc_html( $c[0] ) . '</a>';
	}
	return $out . '</nav>';
}

/* ------------------------------------------------------------------ */
/* Fallback nav                                                        */
/* ------------------------------------------------------------------ */
function ar_fallback_menu() {
	echo '<ul class="ar-menu">';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'arctic-resto' ) . '</a></li>';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 6,
		)
	);
	echo '</ul>';
}
