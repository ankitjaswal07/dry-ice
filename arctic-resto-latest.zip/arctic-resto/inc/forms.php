<?php
/**
 * Lead capture: contact, franchise, estimate and newsletter forms.
 * Anti-spam: honeypot, JS timing token and per-IP rate limit (cache-safe, no nonce needed).
 * Every submission is stored as a private "Lead" and emailed to the site owner.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_form_schema() {
	return array(
		'contact'    => array(
			'label'    => __( 'Contact form', 'arctic-resto' ),
			'required' => array( 'name', 'email' ),
			'fields'   => array(
				'name'     => 'text',
				'company'  => 'text',
				'email'    => 'email',
				'phone'    => 'text',
				'interest' => 'text',
				'service'  => 'text',
				'details'  => 'textarea',
			),
		),
		'franchise'  => array(
			'label'    => __( 'Franchise inquiry', 'arctic-resto' ),
			'required' => array( 'first', 'last', 'email', 'phone' ),
			'fields'   => array(
				'first'      => 'text',
				'last'       => 'text',
				'email'      => 'email',
				'phone'      => 'text',
				'city'       => 'text',
				'state'      => 'text',
				'investment' => 'text',
				'background' => 'textarea',
			),
		),
		'estimate'   => array(
			'label'    => __( 'Instant estimate request', 'arctic-resto' ),
			'required' => array( 'name', 'email' ),
			'fields'   => array(
				'name'      => 'text',
				'email'     => 'email',
				'phone'     => 'text',
				'loc'       => 'text',
				'service'   => 'text',
				'size'      => 'text',
				'condition' => 'text',
				'estimate'  => 'text',
			),
		),
		'newsletter' => array(
			'label'    => __( 'Newsletter signup', 'arctic-resto' ),
			'required' => array( 'email' ),
			'fields'   => array( 'email' => 'email' ),
		),
	);
}

function ar_form_handler() {
	// Honeypot.
	if ( ! empty( $_POST['website'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_send_json_success( array( 'message' => __( 'Thank you!', 'arctic-resto' ) ) );
	}
	// Timing token: milliseconds the visitor kept the form open (measured in the browser, so it
	// is immune to clock differences). Bots that post instantly send 0 or a tiny value.
	$ts = isset( $_POST['ts'] ) ? (int) $_POST['ts'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $ts < 1500 ) {
		wp_send_json_error( array( 'message' => __( 'Please wait a moment and try again.', 'arctic-resto' ) ), 400 );
	}
	// Rate limit.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
	$key = 'ar_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 8 ) {
		wp_send_json_error( array( 'message' => __( 'Too many submissions. Please try again later.', 'arctic-resto' ) ), 429 );
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );

	$schema = ar_form_schema();
	$type   = isset( $_POST['form_type'] ) ? sanitize_key( wp_unslash( $_POST['form_type'] ) ) : 'contact'; // phpcs:ignore
	if ( ! isset( $schema[ $type ] ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid form.', 'arctic-resto' ) ), 400 );
	}
	$def  = $schema[ $type ];
	$data = array();
	foreach ( $def['fields'] as $f => $kind ) {
		$raw = isset( $_POST[ $f ] ) ? wp_unslash( $_POST[ $f ] ) : ''; // phpcs:ignore
		if ( is_array( $raw ) ) {
			$raw = '';
		}
		if ( 'email' === $kind ) {
			$data[ $f ] = sanitize_email( $raw );
		} elseif ( 'textarea' === $kind ) {
			$data[ $f ] = sanitize_textarea_field( $raw );
		} else {
			$data[ $f ] = sanitize_text_field( $raw );
		}
	}
	foreach ( $def['required'] as $r ) {
		if ( '' === $data[ $r ] ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in all required fields with valid details.', 'arctic-resto' ) ), 422 );
		}
	}

	$name = trim( ( $data['name'] ?? '' ) . ' ' . ( $data['first'] ?? '' ) . ' ' . ( $data['last'] ?? '' ) );
	$name = $name ? $name : ( $data['email'] ?? '' );
	$body = '';
	foreach ( $data as $k => $v ) {
		if ( '' !== $v ) {
			$body .= ucfirst( $k ) . ': ' . $v . "\n";
		}
	}

	$lead = wp_insert_post(
		array(
			'post_type'    => 'ar_lead',
			'post_status'  => 'private',
			'post_title'   => sprintf( '%s – %s', $def['label'], $name ),
			'post_content' => $body,
		)
	);
	if ( $lead && ! is_wp_error( $lead ) ) {
		update_post_meta( $lead, '_ar_type', $type );
		update_post_meta( $lead, '_ar_email', $data['email'] ?? '' );
	}

	$to      = ar_mod( 'ar_form_email', get_option( 'admin_email' ) );
	$subject = sprintf( '[%s] %s: %s', get_bloginfo( 'name' ), $def['label'], $name );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
	if ( ! empty( $data['email'] ) ) {
		$headers[] = 'Reply-To: ' . $name . ' <' . $data['email'] . '>';
	}
	wp_mail( $to, $subject, $body, $headers );

	wp_send_json_success( array( 'message' => __( 'Thank you! We will be in touch shortly.', 'arctic-resto' ) ) );
}
add_action( 'wp_ajax_nopriv_ar_form', 'ar_form_handler' );
add_action( 'wp_ajax_ar_form', 'ar_form_handler' );

/** Render a labelled form field. */
function ar_field( $name, $label, $type = 'text', $required = false, $full = false, $opts = array() ) {
	$cls = 'ar-field' . ( $full ? ' ar-field--full' : '' );
	$req = $required ? ' required' : '';
	$out = '<label class="' . esc_attr( $cls ) . '"><span>' . esc_html( $label ) . ( $required ? ' <i>*</i>' : '' ) . '</span>';
	if ( 'select' === $type ) {
		$out .= '<select name="' . esc_attr( $name ) . '">';
		foreach ( $opts as $o ) {
			$out .= '<option>' . esc_html( $o ) . '</option>';
		}
		$out .= '</select>';
	} elseif ( 'textarea' === $type ) {
		$out .= '<textarea name="' . esc_attr( $name ) . '" rows="4"' . $req . '></textarea>';
	} else {
		$out .= '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '"' . $req . '>';
	}
	return $out . '</label>';
}
