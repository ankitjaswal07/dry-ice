<?php
/**
 * Custom post types: Services, Testimonials, Leads.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'init',
	function () {
		register_post_type(
			'ar_service',
			array(
				'labels'       => array(
					'name'          => __( 'Services', 'arctic-resto' ),
					'singular_name' => __( 'Service', 'arctic-resto' ),
					'add_new_item'  => __( 'Add New Service', 'arctic-resto' ),
					'edit_item'     => __( 'Edit Service', 'arctic-resto' ),
					'all_items'     => __( 'All Services', 'arctic-resto' ),
				),
				'public'       => true,
				'has_archive'  => false, // /services/ is an Elementor page.
				'rewrite'      => array(
					'slug'       => 'services',
					'with_front' => false,
				),
				'menu_icon'    => 'dashicons-superhero-alt',
				'menu_position' => 21,
				'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
				'show_in_rest' => true,
			)
		);

		register_post_type(
			'ar_testimonial',
			array(
				'labels'       => array(
					'name'          => __( 'Testimonials', 'arctic-resto' ),
					'singular_name' => __( 'Testimonial', 'arctic-resto' ),
					'add_new_item'  => __( 'Add New Testimonial', 'arctic-resto' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'menu_icon'    => 'dashicons-format-quote',
				'menu_position' => 22,
				'supports'     => array( 'title', 'editor', 'page-attributes' ),
				'show_in_rest' => true,
			)
		);

		register_post_type(
			'ar_lead',
			array(
				'labels'          => array(
					'name'          => __( 'Leads', 'arctic-resto' ),
					'singular_name' => __( 'Lead', 'arctic-resto' ),
					'all_items'     => __( 'All Leads', 'arctic-resto' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'menu_icon'       => 'dashicons-email-alt',
				'menu_position'   => 23,
				'supports'        => array( 'title', 'editor' ),
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
			)
		);
	}
);

/* Let Elementor edit services, posts and pages */
function ar_enable_elementor_cpt() {
	$cur = get_option( 'elementor_cpt_support', array( 'page', 'post' ) );
	$cur = is_array( $cur ) ? $cur : array( 'page', 'post' );
	$new = array_values( array_unique( array_merge( $cur, array( 'page', 'post', 'ar_service' ) ) ) );
	if ( $new !== $cur ) {
		update_option( 'elementor_cpt_support', $new );
	}
}
add_action( 'after_switch_theme', 'ar_enable_elementor_cpt' );
add_action( 'admin_init', 'ar_enable_elementor_cpt' );

add_action(
	'after_switch_theme',
	function () {
		flush_rewrite_rules();
	}
);

/* ------------------------------------------------------------------ */
/* Meta boxes                                                          */
/* ------------------------------------------------------------------ */
add_action(
	'add_meta_boxes',
	function () {
		add_meta_box( 'ar_service_meta', __( 'Service card details', 'arctic-resto' ), 'ar_service_metabox', 'ar_service', 'normal', 'high' );
		add_meta_box( 'ar_testi_meta', __( 'Testimonial details', 'arctic-resto' ), 'ar_testi_metabox', 'ar_testimonial', 'normal', 'high' );
		add_meta_box( 'ar_lead_meta', __( 'Lead details', 'arctic-resto' ), 'ar_lead_metabox', 'ar_lead', 'side', 'default' );
	}
);

function ar_service_metabox( $post ) {
	wp_nonce_field( 'ar_meta', 'ar_meta_nonce' );
	$f = array(
		'_ar_tagline'  => array( __( 'Tagline (shown on cards)', 'arctic-resto' ), 'text' ),
		'_ar_icon'     => array( __( 'Icon class (Font Awesome, e.g. fas fa-plane)', 'arctic-resto' ), 'text' ),
		'_ar_points'   => array( __( 'Key points (one per line)', 'arctic-resto' ), 'area' ),
		'_ar_surfaces' => array( __( 'Surfaces we clean (one per line)', 'arctic-resto' ), 'area' ),
	);
	echo '<p class="description">' . esc_html__( 'The featured image is used on service cards. Edit the full page layout with Elementor.', 'arctic-resto' ) . '</p>';
	foreach ( $f as $k => $d ) {
		$v = get_post_meta( $post->ID, $k, true );
		echo '<p><label><strong>' . esc_html( $d[0] ) . '</strong><br>';
		if ( 'area' === $d[1] ) {
			echo '<textarea class="widefat" rows="4" name="' . esc_attr( $k ) . '">' . esc_textarea( $v ) . '</textarea>';
		} else {
			echo '<input class="widefat" type="text" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		echo '</label></p>';
	}
}

function ar_testi_metabox( $post ) {
	wp_nonce_field( 'ar_meta', 'ar_meta_nonce' );
	foreach ( array( '_ar_role' => __( 'Role / company', 'arctic-resto' ), '_ar_tag' => __( 'Service tag', 'arctic-resto' ) ) as $k => $l ) {
		echo '<p><label><strong>' . esc_html( $l ) . '</strong><br><input class="widefat" type="text" name="' . esc_attr( $k ) . '" value="' . esc_attr( get_post_meta( $post->ID, $k, true ) ) . '"></label></p>';
	}
	echo '<p class="description">' . esc_html__( 'Title = person name. Content = the quote.', 'arctic-resto' ) . '</p>';
}

function ar_lead_metabox( $post ) {
	echo '<p><strong>' . esc_html__( 'Type', 'arctic-resto' ) . ':</strong> ' . esc_html( get_post_meta( $post->ID, '_ar_type', true ) ) . '</p>';
	$em = get_post_meta( $post->ID, '_ar_email', true );
	if ( $em ) {
		echo '<p><a class="button" href="' . esc_url( 'mailto:' . $em ) . '">' . esc_html__( 'Reply by email', 'arctic-resto' ) . '</a></p>';
	}
}

add_action(
	'save_post',
	function ( $post_id ) {
		if ( ! isset( $_POST['ar_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ar_meta_nonce'] ) ), 'ar_meta' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		foreach ( array( '_ar_tagline', '_ar_icon', '_ar_role', '_ar_tag' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				update_post_meta( $post_id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
			}
		}
		foreach ( array( '_ar_points', '_ar_surfaces' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				update_post_meta( $post_id, $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) );
			}
		}
	}
);

/* Lead list columns */
add_filter(
	'manage_ar_lead_posts_columns',
	function ( $c ) {
		return array(
			'cb'    => $c['cb'],
			'title' => __( 'Lead', 'arctic-resto' ),
			'type'  => __( 'Type', 'arctic-resto' ),
			'email' => __( 'Email', 'arctic-resto' ),
			'date'  => __( 'Date', 'arctic-resto' ),
		);
	}
);
add_action(
	'manage_ar_lead_posts_custom_column',
	function ( $col, $id ) {
		if ( 'type' === $col ) {
			echo esc_html( get_post_meta( $id, '_ar_type', true ) );
		}
		if ( 'email' === $col ) {
			echo esc_html( get_post_meta( $id, '_ar_email', true ) );
		}
	},
	10,
	2
);
