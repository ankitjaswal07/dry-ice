<?php
/**
 * Customizer settings.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'customize_register',
	function ( $wp ) {
		$wp->add_section(
			'ar_site',
			array(
				'title'    => __( 'Arctic Resto Settings', 'arctic-resto' ),
				'priority' => 30,
			)
		);

		$fields = array(
			'ar_topbar'      => array( __( 'Top bar text', 'arctic-resto' ), 'Now serving New Jersey & Connecticut · Franchise territories available', 'text' ),
			'ar_phone'       => array( __( 'Phone number', 'arctic-resto' ), '203-404-5788', 'text' ),
			'ar_email'       => array( __( 'Email address', 'arctic-resto' ), 'info@arcticresto.com', 'email' ),
			'ar_location'    => array( __( 'Service area', 'arctic-resto' ), 'Serving NJ & CT', 'text' ),
			'ar_form_email'  => array( __( 'Send form leads to (email)', 'arctic-resto' ), '', 'email' ),
			'ar_cta_text'    => array( __( 'Header button text', 'arctic-resto' ), 'Get Instant Quote', 'text' ),
			'ar_cta_url'     => array( __( 'Header button link', 'arctic-resto' ), '/estimator/', 'text' ),
			'ar_footer_text' => array( __( 'Footer description', 'arctic-resto' ), 'Eco-friendly mobile dry ice cleaning using fully outfitted Mercedes Sprinter vans and a franchise owner business model. No water. No chemicals. No mess — just clean and green.', 'textarea' ),
			'ar_legal_text'  => array( __( 'Footer legal note', 'arctic-resto' ), 'Franchise offerings are made only by disclosure document.', 'text' ),
			'ar_facebook'    => array( __( 'Facebook URL', 'arctic-resto' ), '', 'url' ),
			'ar_instagram'   => array( __( 'Instagram URL', 'arctic-resto' ), '', 'url' ),
			'ar_linkedin'    => array( __( 'LinkedIn URL', 'arctic-resto' ), '', 'url' ),
			'ar_youtube'     => array( __( 'YouTube URL', 'arctic-resto' ), '', 'url' ),
			'ar_portal_url'   => array( __( 'Franchise portal URL (apply / dashboard)', 'arctic-resto' ), '', 'url' ),
			'ar_portal_login' => array( __( 'Franchise owner login URL (optional)', 'arctic-resto' ), '', 'url' ),
			'ar_areas'        => array( __( 'Service areas for search engines (comma separated)', 'arctic-resto' ), 'New Jersey, Connecticut', 'text' ),
			'ar_founded'      => array( __( 'Founding year', 'arctic-resto' ), '2024', 'text' ),
			'ar_ai_summary'   => array( __( 'Company summary for search & AI (one paragraph)', 'arctic-resto' ), 'Arctic Resto is an eco-friendly mobile dry ice cleaning service serving New Jersey and Connecticut. Fully outfitted Mercedes Sprinter vans bring dry ice cleaning to aerospace and defense, food processing, manufacturing, utilities and power plants, automotive restoration, boats and marinas, and fire restoration — with no water, no chemicals and no secondary waste. Arctic Resto is the industry’s first mobile dry ice cleaning franchise.', 'textarea' ),
		);
		foreach ( $fields as $id => $f ) {
			$cb = 'url' === $f[2] ? 'esc_url_raw' : ( 'email' === $f[2] ? 'sanitize_email' : ( 'textarea' === $f[2] ? 'sanitize_textarea_field' : 'sanitize_text_field' ) );
			$wp->add_setting(
				$id,
				array(
					'default'           => $f[1],
					'sanitize_callback' => $cb,
					'transport'         => 'refresh',
				)
			);
			$wp->add_control(
				$id,
				array(
					'label'   => $f[0],
					'section' => 'ar_site',
					'type'    => $f[2],
				)
			);
		}

		foreach ( array(
			'ar_c_accent' => array( __( 'Accent colour', 'arctic-resto' ), '#45d6ff' ),
			'ar_c_dark'   => array( __( 'Dark background colour', 'arctic-resto' ), '#061325' ),
		) as $id => $f ) {
			$wp->add_setting(
				$id,
				array(
					'default'           => $f[1],
					'sanitize_callback' => 'sanitize_hex_color',
				)
			);
			$wp->add_control( new WP_Customize_Color_Control( $wp, $id, array( 'label' => $f[0], 'section' => 'ar_site' ) ) );
		}

		$wp->add_setting(
			'ar_ai_access',
			array(
				'default'           => 'allow',
				'sanitize_callback' => 'sanitize_key',
			)
		);
		$wp->add_control(
			'ar_ai_access',
			array(
				'label'       => __( 'AI crawler access (robots.txt)', 'arctic-resto' ),
				'description' => __( 'Allow AI search and assistant crawlers (GPTBot, ClaudeBot, PerplexityBot, Google-Extended…) to read your public pages.', 'arctic-resto' ),
				'section'     => 'ar_site',
				'type'        => 'select',
				'choices'     => array(
					'allow' => __( 'Allow (recommended for visibility in AI answers)', 'arctic-resto' ),
					'block' => __( 'Block AI crawlers', 'arctic-resto' ),
				),
			)
		);
	}
);
