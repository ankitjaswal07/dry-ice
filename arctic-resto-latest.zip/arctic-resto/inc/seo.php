<?php
/**
 * SEO: per-page SEO fields, titles, meta, Open Graph and a connected JSON-LD graph
 * (Organization / LocalBusiness, WebSite, WebPage, BreadcrumbList, Service, Article).
 * With Yoast, Rank Math, AIOSEO or SEOPress active the theme only adds the Service node
 * (which those plugins do not know about) and leaves everything else to the plugin.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ar_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

function ar_json_ld( $data ) {
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore
}

function ar_ai_summary() {
	return ar_mod( 'ar_ai_summary', 'Arctic Resto is an eco-friendly mobile dry ice cleaning service serving New Jersey and Connecticut, with no water, no chemicals and no secondary waste.' );
}

function ar_areas() {
	return array_values( array_filter( array_map( 'trim', explode( ',', ar_mod( 'ar_areas', 'New Jersey, Connecticut' ) ) ) ) );
}

/* ------------------------------------------------------------------ */
/* SEO meta box                                                        */
/* ------------------------------------------------------------------ */
add_action(
	'add_meta_boxes',
	function () {
		foreach ( array( 'page', 'post', 'ar_service' ) as $pt ) {
			add_meta_box( 'ar_seo', __( 'SEO & AI search (Arctic Resto)', 'arctic-resto' ), 'ar_seo_metabox', $pt, 'normal', 'low' );
		}
	}
);

function ar_seo_metabox( $post ) {
	wp_nonce_field( 'ar_seo', 'ar_seo_nonce' );
	$t = get_post_meta( $post->ID, '_ar_seo_title', true );
	$d = get_post_meta( $post->ID, '_ar_seo_desc', true );
	$n = get_post_meta( $post->ID, '_ar_noindex', true );
	echo '<p><label><strong>' . esc_html__( 'SEO title', 'arctic-resto' ) . '</strong> <span class="description">(' . esc_html__( 'aim for 50–65 characters; leave blank to auto-generate', 'arctic-resto' ) . ')</span><br><input class="widefat" type="text" maxlength="90" name="ar_seo_title" value="' . esc_attr( $t ) . '"></label></p>';
	echo '<p><label><strong>' . esc_html__( 'Meta description', 'arctic-resto' ) . '</strong> <span class="description">(' . esc_html__( '120–160 characters; leave blank to use the excerpt', 'arctic-resto' ) . ')</span><br><textarea class="widefat" rows="3" maxlength="200" name="ar_seo_desc">' . esc_textarea( $d ) . '</textarea></label></p>';
	echo '<p><label><input type="checkbox" name="ar_noindex" value="1" ' . checked( $n, '1', false ) . '> ' . esc_html__( 'Hide this page from search engines (noindex)', 'arctic-resto' ) . '</label></p>';
	echo '<p class="description">' . esc_html__( 'Tip: write the first sentence of the page as a direct answer — search engines and AI assistants often quote it.', 'arctic-resto' ) . '</p>';
}

add_action(
	'save_post',
	function ( $post_id ) {
		if ( ! isset( $_POST['ar_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ar_seo_nonce'] ) ), 'ar_seo' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_ar_seo_title', isset( $_POST['ar_seo_title'] ) ? sanitize_text_field( wp_unslash( $_POST['ar_seo_title'] ) ) : '' );
		update_post_meta( $post_id, '_ar_seo_desc', isset( $_POST['ar_seo_desc'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ar_seo_desc'] ) ) : '' );
		update_post_meta( $post_id, '_ar_noindex', isset( $_POST['ar_noindex'] ) ? '1' : '' );
	}
);

/* ------------------------------------------------------------------ */
/* Titles & robots                                                     */
/* ------------------------------------------------------------------ */
add_filter(
	'pre_get_document_title',
	function ( $title ) {
		if ( ar_has_seo_plugin() || ! is_singular() ) {
			return $title;
		}
		$m = get_post_meta( get_queried_object_id(), '_ar_seo_title', true );
		return $m ? $m : $title;
	},
	20
);

add_filter(
	'wp_robots',
	function ( $robots ) {
		if ( is_search() || is_404() ) {
			$robots['noindex'] = true;
		}
		if ( is_singular() && '1' === get_post_meta( get_queried_object_id(), '_ar_noindex', true ) ) {
			$robots['noindex'] = true;
			unset( $robots['max-image-preview'] );
		} else {
			// Allow full snippets and large previews (helps rich results and AI answers).
			$robots['max-snippet']       = '-1';
			$robots['max-video-preview'] = '-1';
		}
		return $robots;
	}
);

function ar_meta_description() {
	if ( is_singular() ) {
		$p = get_queried_object();
		$m = get_post_meta( $p->ID, '_ar_seo_desc', true );
		if ( $m ) {
			return $m;
		}
		if ( has_excerpt( $p ) ) {
			return wp_strip_all_tags( get_the_excerpt( $p ) );
		}
		if ( ! ar_is_elementor( $p->ID ) && $p->post_content ) {
			return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $p->post_content ) ), 30 );
		}
	}
	return wp_trim_words( ar_ai_summary(), 30 );
}

/* ------------------------------------------------------------------ */
/* Schema graph                                                        */
/* ------------------------------------------------------------------ */
function ar_org_node( $catalog = false ) {
	$logo  = has_custom_logo() ? wp_get_attachment_image_url( (int) get_theme_mod( 'custom_logo' ), 'full' ) : ar_theme_img( 'hero-blast' );
	$same  = array_values( array_filter( array( ar_mod( 'ar_facebook' ), ar_mod( 'ar_instagram' ), ar_mod( 'ar_linkedin' ), ar_mod( 'ar_youtube' ) ) ) );
	$areas = array();
	foreach ( ar_areas() as $a ) {
		$areas[] = array( '@type' => 'AdministrativeArea', 'name' => $a );
	}
	$svcs  = ar_get_services();
	$known = array();
	$items = array();
	foreach ( $svcs as $i => $p ) {
		$known[] = get_the_title( $p );
		$items[] = array(
			'@type'           => 'Offer',
			'itemOffered'     => array(
				'@type' => 'Service',
				'name'  => get_the_title( $p ),
				'url'   => get_permalink( $p ),
			),
		);
	}
	$node = array(
		'@type'         => 'LocalBusiness',
		'@id'           => home_url( '/#organization' ),
		'name'          => get_bloginfo( 'name' ),
		'url'           => home_url( '/' ),
		'logo'          => array( '@type' => 'ImageObject', 'url' => $logo ),
		'image'         => $logo,
		'telephone'     => ar_phone(),
		'email'         => ar_email(),
		'description'   => ar_ai_summary(),
		'areaServed'    => $areas,
		'foundingDate'  => ar_mod( 'ar_founded', '2024' ),
		'knowsAbout'    => array_merge( array( 'Dry ice cleaning', 'Dry ice blasting', 'Mobile industrial cleaning', 'Fire restoration' ), $known ),
	);
	if ( $same ) {
		$node['sameAs'] = $same;
	}
	if ( $catalog && $items ) {
		$node['hasOfferCatalog'] = array(
			'@type'           => 'OfferCatalog',
			'name'            => __( 'Dry ice cleaning services', 'arctic-resto' ),
			'itemListElement' => $items,
		);
	}
	return $node;
}

function ar_page_type( $p ) {
	$map = array(
		'about'       => 'AboutPage',
		'contact'     => 'ContactPage',
		'services'    => 'CollectionPage',
		'blog'        => 'CollectionPage',
		'gallery'     => 'CollectionPage',
		'territories' => 'CollectionPage',
	);
	return isset( $map[ $p->post_name ] ) ? $map[ $p->post_name ] : 'WebPage';
}

function ar_service_node( $p, $url, $desc ) {
	$m     = ar_service_meta( $p->ID );
	$thumb = get_the_post_thumbnail_url( $p, 'ar-hero' );
	$areas = array();
	foreach ( ar_areas() as $a ) {
		$areas[] = array( '@type' => 'AdministrativeArea', 'name' => $a );
	}
	$node = array(
		'@type'            => 'Service',
		'@id'              => $url . '#service',
		'name'             => get_the_title( $p ),
		'serviceType'      => get_the_title( $p ),
		'description'      => $desc,
		'url'              => $url,
		'provider'         => array( '@id' => home_url( '/#organization' ) ),
		'areaServed'       => $areas,
		'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
	);
	if ( $m['tagline'] ) {
		$node['slogan'] = $m['tagline'];
	}
	if ( $thumb ) {
		$node['image'] = $thumb;
	}
	return $node;
}

add_action(
	'wp_head',
	function () {
		if ( ar_has_seo_plugin() ) {
			// Plugins do not know the Service post type — add only that node.
			if ( is_singular( 'ar_service' ) ) {
				$p   = get_queried_object();
				$url = get_permalink( $p );
				ar_json_ld( array_merge( array( '@context' => 'https://schema.org' ), ar_service_node( $p, $url, ar_meta_description() ) ) );
			}
			return;
		}

		$graph = array();
		$front = is_front_page();
		$svc   = is_singular( 'ar_service' );
		$graph[] = ar_org_node( $front || $svc || is_page( 'services' ) );

		if ( $front ) {
			$graph[] = array(
				'@type'           => 'WebSite',
				'@id'             => home_url( '/#website' ),
				'url'             => home_url( '/' ),
				'name'            => get_bloginfo( 'name' ),
				'description'     => get_bloginfo( 'description' ),
				'publisher'       => array( '@id' => home_url( '/#organization' ) ),
				'inLanguage'      => get_bloginfo( 'language' ),
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => array( '@type' => 'EntryPoint', 'urlTemplate' => home_url( '/?s={search_term_string}' ) ),
					'query-input' => 'required name=search_term_string',
				),
			);
		}

		if ( is_singular() ) {
			$p    = get_queried_object();
			$url  = get_permalink( $p );
			$desc = ar_meta_description();
			$img  = has_post_thumbnail( $p ) ? get_the_post_thumbnail_url( $p, 'ar-hero' ) : ar_theme_img( 'hero-blast' );

			$page = array(
				'@type'         => is_singular( 'post' ) ? 'WebPage' : ar_page_type( $p ),
				'@id'           => $url . '#webpage',
				'url'           => $url,
				'name'          => wp_get_document_title(),
				'description'   => $desc,
				'isPartOf'      => array( '@id' => home_url( '/#website' ) ),
				'about'         => array( '@id' => home_url( '/#organization' ) ),
				'breadcrumb'    => array( '@id' => $url . '#breadcrumb' ),
				'datePublished' => get_the_date( 'c', $p ),
				'dateModified'  => get_the_modified_date( 'c', $p ),
				'inLanguage'    => get_bloginfo( 'language' ),
				'primaryImageOfPage' => array( '@type' => 'ImageObject', 'url' => $img ),
			);
			if ( $svc ) {
				$page['speakable'] = array(
					'@type'       => 'SpeakableSpecification',
					'cssSelector' => array( 'h1', '.ar-answer__q', '.ar-answer__a' ),
				);
			}
			$graph[] = $page;

			$list = array();
			foreach ( ar_crumb_list() as $i => $c ) {
				$list[] = array(
					'@type'    => 'ListItem',
					'position' => $i + 1,
					'name'     => $c[0],
					'item'     => '' !== $c[1] ? $c[1] : $url,
				);
			}
			$graph[] = array(
				'@type'           => 'BreadcrumbList',
				'@id'             => $url . '#breadcrumb',
				'itemListElement' => $list,
			);

			if ( $svc ) {
				$graph[] = ar_service_node( $p, $url, $desc );
			}
			if ( is_page() && function_exists( 'ar_is_territory' ) && ar_is_territory( $p->ID ) ) {
				$graph[] = ar_territory_node( $p, $url, $desc );
			}
			if ( is_singular( 'post' ) ) {
				$graph[] = array(
					'@type'            => 'Article',
					'@id'              => $url . '#article',
					'headline'         => get_the_title( $p ),
					'description'      => $desc,
					'image'            => $img,
					'datePublished'    => get_the_date( 'c', $p ),
					'dateModified'     => get_the_modified_date( 'c', $p ),
					'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
					'author'           => array( '@id' => home_url( '/#organization' ) ),
					'publisher'        => array( '@id' => home_url( '/#organization' ) ),
				);
			}
		}

		ar_json_ld( array( '@context' => 'https://schema.org', '@graph' => $graph ) );
	},
	4
);

/* ------------------------------------------------------------------ */
/* Meta tags                                                           */
/* ------------------------------------------------------------------ */
add_action(
	'wp_head',
	function () {
		$site = get_bloginfo( 'name' );

		// Discovery links for AI agents and markdown-aware tools (always useful).
		echo '<link rel="alternate" type="text/plain" href="' . esc_url( home_url( '/llms.txt' ) ) . '" title="LLMs.txt">' . "\n"; // phpcs:ignore
		if ( is_singular() && function_exists( 'ar_md_url' ) && ar_md_url( get_queried_object() ) ) {
			echo '<link rel="alternate" type="text/markdown" href="' . esc_url( ar_md_url( get_queried_object() ) ) . '">' . "\n"; // phpcs:ignore
		}

		if ( ar_has_seo_plugin() ) {
			return;
		}

		global $wp;
		$desc  = esc_attr( wp_strip_all_tags( ar_meta_description() ) );
		$title = wp_get_document_title();
		$img   = ar_theme_img( 'hero-blast' );
		$type  = 'website';
		$url   = home_url( ( isset( $wp->request ) && $wp->request ) ? '/' . $wp->request . '/' : '/' );

		if ( is_singular() ) {
			$p = get_queried_object();
			if ( has_post_thumbnail( $p ) ) {
				$img = get_the_post_thumbnail_url( $p, 'ar-hero' );
			}
			$url  = get_permalink( $p );
			$type = is_singular( 'post' ) ? 'article' : 'website';
		}

		echo '<meta name="description" content="' . $desc . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:site_name" content="' . esc_attr( $site ) . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:locale" content="' . esc_attr( str_replace( '-', '_', get_bloginfo( 'language' ) ) ) . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:description" content="' . $desc . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n"; // phpcs:ignore
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n"; // phpcs:ignore
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n"; // phpcs:ignore
		echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n"; // phpcs:ignore
		echo '<meta name="twitter:description" content="' . $desc . '">' . "\n"; // phpcs:ignore
		echo '<meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n"; // phpcs:ignore
		if ( is_singular( 'post' ) ) {
			echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c' ) ) . '">' . "\n"; // phpcs:ignore
			echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . "\n"; // phpcs:ignore
		}
	},
	5
);
