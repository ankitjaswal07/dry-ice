<?php
/**
 * Single blog post.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
while ( have_posts() ) {
	the_post();
	if ( ar_is_elementor() ) {
		the_content();
		continue;
	}
	$cats = get_the_category();
	?>
	<section class="ar-sec ar-phero ar-t-void">
		<?php if ( has_post_thumbnail() ) : ?>
			<div class="ar-hero__bg"><?php the_post_thumbnail( 'ar-hero', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => '' ) ); ?></div>
		<?php endif; ?>
		<div class="ar-hero__shade"></div><div class="ar-hero__grid"></div>
		<i class="ar-fog ar-fog--1" aria-hidden="true"></i>
		<div class="ar-wrap ar-phero__inner">
			<?php echo ar_breadcrumbs(); // phpcs:ignore ?>
			<p class="ar-eyebrow"><i></i><?php echo esc_html( ( $cats ? $cats[0]->name . ' · ' : '' ) . ar_read_time( get_post() ) ); ?></p>
			<h1 class="ar-phero__title"><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?><p class="ar-phero__sub"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
		</div>
	</section>

	<article class="ar-sec ar-t-light ar-pad-lg">
		<div class="ar-wrap ar-wrap--narrow">
			<p class="ar-meta"><?php echo esc_html__( 'Published', 'arctic-resto' ) . ' ' . esc_html( get_the_date() ); ?></p>
			<div class="ar-prose ar-prose--article"><?php the_content(); ?></div>
			<div class="ar-postcta">
				<h3><?php esc_html_e( 'Have a project in mind?', 'arctic-resto' ); ?></h3>
				<p><?php esc_html_e( 'Get an instant estimate or talk to our team about your surface and timeline.', 'arctic-resto' ); ?></p>
				<a class="ar-btn ar-btn--primary" href="<?php echo esc_url( ar_abs_url( ar_mod( 'ar_cta_url', '/estimator/' ) ) ); ?>"><span><?php echo esc_html( ar_mod( 'ar_cta_text', 'Get Instant Quote' ) ); ?></span><?php echo ar_svg( 'arrow' ); // phpcs:ignore ?></a>
			</div>
		</div>
	</article>

	<?php
	$related = get_posts(
		array(
			'post_type'      => 'post',
			'posts_per_page' => 3,
			'post__not_in'   => array( get_the_ID() ),
		)
	);
	if ( $related ) :
		?>
		<section class="ar-sec ar-t-frost ar-pad-lg">
			<div class="ar-wrap">
				<header class="ar-head ar-head--left"><h2 class="ar-h2"><?php esc_html_e( 'Keep reading', 'arctic-resto' ); ?></h2></header>
				<div class="ar-grid ar-cols-3">
					<?php foreach ( $related as $i => $p ) { echo ar_post_card( $p, $i ); } // phpcs:ignore ?>
				</div>
			</div>
		</section>
	<?php endif; ?>
	<?php
}
get_footer();
