<?php
/**
 * Footer. Uses an Elementor Theme Builder footer when one exists.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main>
<?php
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
	get_template_part( 'template-parts/site-footer' );
}
?>
<button class="ar-top" type="button" aria-label="<?php esc_attr_e( 'Back to top', 'arctic-resto' ); ?>"><?php echo ar_svg( 'arrow-up' ); // phpcs:ignore ?></button>
<div class="ar-mobilebar">
	<a href="<?php echo esc_url( ar_phone_href() ); ?>"><?php echo ar_svg( 'phone' ); // phpcs:ignore ?> <?php esc_html_e( 'Call now', 'arctic-resto' ); ?></a>
	<a class="is-cta" href="<?php echo esc_url( ar_abs_url( ar_mod( 'ar_cta_url', '/estimator/' ) ) ); ?>"><?php echo esc_html( ar_mod( 'ar_cta_text', 'Get Instant Quote' ) ); ?></a>
</div>
<?php wp_footer(); ?>
</body>
</html>
