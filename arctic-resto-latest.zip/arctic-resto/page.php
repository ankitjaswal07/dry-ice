<?php
/**
 * Pages. Elementor-built pages render full-width; classic pages get a themed hero.
 *
 * @package ArcticResto
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
while ( have_posts() ) {
	the_post();
	if ( ar_is_elementor() ) {
		the_content();
	} else {
		?>
		<section class="ar-sec ar-phero ar-t-void">
			<div class="ar-hero__shade"></div><div class="ar-hero__grid"></div>
			<div class="ar-wrap ar-phero__inner">
				<?php echo ar_breadcrumbs(); // phpcs:ignore ?>
				<h1 class="ar-phero__title"><?php the_title(); ?></h1>
			</div>
		</section>
		<section class="ar-sec ar-t-light ar-pad-lg">
			<div class="ar-wrap ar-wrap--narrow"><div class="ar-prose ar-prose--article"><?php the_content(); ?></div></div>
		</section>
		<?php
	}
}
get_footer();
