# Arctic Resto — WordPress + Elementor theme

A fast, professional theme for **mobile dry ice cleaning, restoration and franchise** businesses.
Every page is built from custom **Elementor widgets**, so the whole site is editable visually — and a
**one-click importer** creates all pages, services, testimonials, posts and menus with demo data.

## Requirements
- WordPress 6.3+ · PHP 7.4+
- **Elementor** (free) 3.5 or newer — Elementor Pro is *not* required

## Install (3 steps)
1. **Appearance → Themes → Add New → Upload Theme** → choose `arctic-resto.zip` → Install → **Activate**.
2. Install and activate the free **Elementor** plugin (Plugins → Add New).
3. Go to **Appearance → Demo Import** → click **Import demo content**. Done — open the site.

> Use a fresh WordPress install for the demo. The importer never deletes your own pages, and it can be re-run safely.

## What the importer creates
| Type | Items |
|---|---|
| Pages (Elementor) | Home, About, Services, How It Works, Franchise, Territories, Gallery, Blog, FAQ, Instant Estimator, Contact, Privacy Policy |
| Services (custom post type, Elementor) | Aerospace & Defense · Food Processing & Equipment · Manufacturing & Machinery · Utilities & Power Plants · Automotive Restoration · Boats & Marinas · Fire Restoration |
| Testimonials | 5 |
| Blog posts | 6 (with categories + featured images) |
| Menus | Primary (with Services mega menu + Resources dropdown), Footer Company, Footer Services |
| Media | 24 demo images (7 bundled, 17 downloaded during import) |
| Settings | Static homepage, `/%postname%/` permalinks, Elementor options |

Use **Appearance → Demo Import → Remove demo content** to undo.

## Editing with Elementor
Open any page → **Edit with Elementor** → in the widget panel find the **Arctic Resto** category:

| Widget | Purpose |
|---|---|
| AR Home Hero | Full-screen hero with rotating word, floating stat cards, particles |
| AR Page Hero | Inner-page hero with breadcrumbs |
| AR Icon Boxes / Steps | Trust bar, feature cards, numbered cards, process steps |
| AR Animated Stats | Counting numbers |
| AR Image + Text Split | Image with badge, text, checklist, quote, mini-stats, buttons |
| AR Scrolling Ticker | Marquee of words |
| AR Call To Action | Gradient CTA with particles |
| AR Timeline · AR Team Members · AR Comparison Table | Content blocks |
| AR Services *(dynamic)* | Bento grid / card grid / alternating rows, from the **Services** post type |
| AR Testimonials *(dynamic)* | Carousel from the **Testimonials** post type |
| AR Blog Posts *(dynamic)* | Grid with featured post, search, category filters, pagination |
| AR Before / After Slider | Drag slider with tabs (auto-generates a "dirty" look, or upload a real before image) |
| AR FAQ Accordion | Search, category chips and Google FAQ schema |
| AR Revenue Calculator | Interactive sliders (franchise) |
| AR Territory Map | Clickable stylised map with coverage lists |
| AR Filterable Gallery | Category filters + lightbox |
| AR Science Tabs + Animation | Tabs and a live CSS blasting simulation |
| AR Lead Form | Contact or Franchise form (working, see below) |
| AR Instant Estimator | 3-step price estimator that captures a lead |

Every widget has **Section Style** controls (background theme, spacing, anchor ID). Wrap words in
`{{double braces}}` inside any title for the gradient highlight.

**Theme Builder:** with Elementor Pro you can replace the header, footer, single-post and archive
templates — the theme registers all locations and falls back to its own header/footer otherwise.

## Content management
- **Services** — add/edit under *Services*. Set the featured image, tagline, icon (Font Awesome class), key points and surfaces in the *Service card details* box; build the full page with Elementor.
- **Testimonials** — title = name, content = quote.
- **Leads** — every form submission is saved under *Leads* and emailed to you.

## Customizer — *Appearance → Customize → Arctic Resto Settings*
Top-bar text, phone, email, service area, lead notification email, header button, footer text,
social links and the two brand colours (accent + dark).

## Forms & spam protection
All forms post via AJAX to WordPress, are stored as private **Leads** and emailed to the address in
the Customizer (default: the admin email). Protection: honeypot, JS timing token, per-IP rate limit —
no nonce, so they keep working behind full-page caches. Configure an SMTP plugin for reliable delivery.

## Performance & optimisation
- One small CSS file and one dependency-free JS file (minified builds are loaded automatically; `SCRIPT_DEBUG` loads the readable sources)
- JS loaded with `defer`; no jQuery dependency in the theme; jQuery Migrate removed
- No icon font or Google Fonts loaded twice (Elementor's font printing disabled; SVG icons respected)
- Gutenberg CSS removed on Elementor pages; emoji, embed, generator and RSD/WLW head bloat removed
- Lazy-loaded images, `fetchpriority="high"` on hero images, async decoding, preconnect for fonts
- Animations use `transform`/`opacity` only, pause off-screen, and respect `prefers-reduced-motion`
- Structured data: LocalBusiness, Service, Article and FAQ (auto-disabled if Yoast / Rank Math / AIOSEO is active); Open Graph tags
- Accessible: skip link, ARIA on menu/accordion/slider, focus styles, keyboard support for sliders and lightbox
- Security: escaped output, sanitised input, capability-checked importer, security headers, author-enumeration redirect

## Franchise portal
Your franchise portal lives outside WordPress, so the theme links to it instead of collecting applications itself.

1. **Appearance → Customize → Arctic Resto Settings → Franchise portal URL** — paste the portal's apply/dashboard URL.
2. Optionally add a separate **Franchise owner login URL**.

Every "Apply" and "Login" button (Franchise page hero, the *AR Franchise Portal Card* widget, Territories page), plus a *Franchise Portal Login* link in the top bar and footer, then point to your portal automatically. In any Elementor URL field you can also type `{portal}` or `{portal-login}` as a shortcut. Until a URL is set, the buttons open the Contact page and an admin notice reminds you.

## Franchise portal: log in & register (v1.2)
Your portal plugin lives outside the theme, so the theme links to it. Set the URLs once under
**Appearance → Customize → Arctic Resto Settings**:

| Field | Used for |
|---|---|
| Franchise portal URL | Fallback for anything left blank |
| Franchise owner login URL | "Log in" links |
| Franchise portal – Register URL | "Register" buttons |
| Franchise portal – Dashboard URL | "Dashboard" link shown to logged-in visitors |
| Portal label | Text in the top bar (default "Franchise Portal") |

**Where it appears:** top bar (Log in · Register) · mobile menu · footer · Franchise page hero, overview box, "Where to start" cards and portal card · every territory page · the CTA at the bottom of the Franchise page.
If your plugin uses WordPress accounts, leave the fields blank and the theme falls back to the standard WordPress login and (if enabled) registration pages.
Logged-in visitors see **Dashboard / Log out** instead (switch this off in the Customizer). Administrators are logged in too, so they see the logged-in links — that is normal.

Shortcut tokens for any Elementor URL field: `{portal-login}` `{portal-register}` `{portal-dashboard}` `{portal}`.
Shortcode for posts and text widgets: `[ar_portal_links]` (or `[ar_portal_links style="top"]`).
Developer hooks: `ar_portal_login_url`, `ar_portal_register_url`, `ar_portal_dashboard_url`, `ar_portal_links_html`.

## Territories (v1.2)
Territories are ordinary **child pages of the Territories page**, so each one is fully editable in Elementor and gets its own URL (`/territories/connecticut/`).
- **Add a territory:** Pages → Add New → set *Parent: Territories* → Save Draft → fill in the **Territory details** box (code, status colour, description, coverage areas, map position) → set a Featured Image → design the page with Elementor → Publish.
- The details box feeds the interactive map, the territory cards and the coverage list, so nothing is typed twice.
- New widgets: **AR Territory Hero**, **AR Coverage Areas**, **AR Territory Cards**, **AR Territory Map** (now reads the child pages), **AR On-page Navigation**, **AR Good Fit / Not Ideal**.
- Text fields in the hero and coverage widgets accept `[state]` `[code]` `[status]` `[blurb]`.
- The territory graphic (grid, coverage rings, pulsing pin) is generated as SVG from each territory's map position — no image files to maintain.
- The demo imports four territories (Connecticut, New Jersey, Massachusetts, Southeast USA). **Coverage lists are examples — edit them to match where you really operate.**

## Clarity & conversion (v1.2)
- **Franchise page** now follows a clear order: overview → pick your path (register / log in / ask a question) → what is included → franchise vs starting alone → honest "is it for you?" → path to ownership → territories → portal card → FAQ. It states no fees, earnings or guarantees.
- **Service pages** add a sticky *On this page* bar, an honest *Good fit / Probably not the best fit* grid, a "before we arrive" checklist, pricing factors (no invented prices), and links to every territory.
- Every long page has an *On this page* bar with scroll-spy highlighting. Add one anywhere with the **AR On-page Navigation** widget and give each target widget an **Anchor ID** (Style tab → Section Style).

## SEO & AI-agent optimisation
**Service pages** were expanded with answer-first content: a direct answer + *Quick facts* box, capabilities, problems solved, a long-form guide with applications, a dry-ice vs traditional comparison, a step-by-step process (HowTo schema) and 6 FAQs (FAQ schema) — all editable in Elementor using the new **AR Answer Box + Quick Facts**, **AR Long-form Article + Sidebar** and **AR Franchise Portal Card** widgets.

| Feature | Details |
|---|---|
| Per-page SEO box | SEO title, meta description and noindex on every page, post and service (auto-filled by the demo import) |
| Connected JSON-LD graph | LocalBusiness (with service catalogue, areas served, founding date), WebSite + SearchAction, WebPage/AboutPage/ContactPage/CollectionPage, BreadcrumbList, Service, Article, plus FAQPage and HowTo from the widgets |
| Answer-engine friendly | Direct-answer block, `speakable` markup, visible "Last reviewed" dates, semantic H1 → H2 → H3, descriptive alt text |
| `/llms.txt` | Curated, always-current map of services, key pages, franchise and contact details for AI assistants |
| `/llms-full.txt` | Full text of every service and key page in Markdown |
| `/page-name.md` | Clean Markdown version of every page (add `.md` to any URL); marked `noindex` with a canonical header so it never competes with the real page |
| robots.txt | Explicit rules for GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-User, Claude-SearchBot, PerplexityBot, Perplexity-User, Google-Extended, Applebot-Extended, CCBot, Amazonbot and meta-externalagent — allow or block from the Customizer |
| Snippet controls | `max-snippet:-1`, `max-image-preview:large`, `max-video-preview:-1` |
| Sitemap | Uses the built-in WordPress sitemap (`/wp-sitemap.xml`), which includes Services |

The text-file endpoints need pretty permalinks (the importer sets `/%postname%/`). If your server has a physical `robots.txt` file, delete it so WordPress can serve the AI rules. If you install Yoast, Rank Math, AIOSEO or SEOPress, the theme steps back and only adds the Service schema those plugins cannot know about.

## Recommended plugins
Elementor · a caching plugin (LiteSpeed Cache / WP Rocket) · an SMTP plugin (WP Mail SMTP) · an SEO plugin (Rank Math or Yoast) · an image optimiser (ShortPixel / Imagify).

## Notes
- Demo photography is from Pexels (free licence); van, hero and pellet images are AI-generated. Replace them with your own in the Media Library and inside each widget.
- Team, testimonials, gallery, before/after images and the franchise calculator are **demo content**. The calculator is not a financial performance representation — have counsel review franchise claims.
- The estimator's price formula (hourly rate × hours) is a placeholder; edit the rate and hours in the widget.

## Folder structure
```
arctic-resto/
├─ style.css · functions.php · header.php · footer.php · index.php · page.php · single.php
├─ single-ar_service.php · 404.php · screenshot.png
├─ template-parts/   site-header.php · site-footer.php
├─ inc/              setup · helpers · optimize · seo · post-types · customizer · forms · elementor · demo-importer
│  ├─ elementor/     class-base.php + widgets-*.php (21 widgets)
│  └─ demo/          content.php (all demo data as Elementor JSON builders)
└─ assets/           css/theme(.min).css · js/theme(.min).js · images/ (demo photos)
```

## Installing
1. Compress the **`arctic-resto`** folder into `arctic-resto.zip` (the folder itself must be the top level inside the zip).
2. WordPress → Appearance → Themes → Add New → Upload Theme → choose the zip → Activate.
3. Plugins → Add New → install and activate **Elementor** (free; version 3.16 or newer recommended — the theme's pages use Elementor Containers).
4. Appearance → **Demo Import** → Import demo content.

**Demo images:** 7 brand images ship inside the theme; 17 stock photos are downloaded from Pexels into your Media Library during import, so the server needs outbound internet access. If a download fails the import reports it and the affected pages simply show the image straight from its source URL — nothing breaks. There is no `screenshot.png` in the package; add a 1200×900 PNG named `screenshot.png` to the theme folder if you want a thumbnail on the Themes screen.

**First-run checklist (2 minutes):** Home loads with the hero animation → open Services and click a service → open Franchise and check Log in / Register → open Territories and click a pin → open FAQ and expand a question → drag a Before/After slider → open the Estimator and go through all three steps → submit the Contact form and confirm a *Lead* appears under Leads. If anything above misbehaves, open your browser console and send the message.

## Changelog
**1.2.1** — Audit fixes. (1) Fixed a script bug that stopped the FAQ accordion, before/after slider, revenue calculator, territory map, science tabs and estimator from starting. (2) Form spam check no longer depends on the visitor's clock. (3) Sticky sidebars work (sections now use `overflow: clip`). (4) Mobile menu no longer collapses after scrolling. (5) Tablet layouts use two columns instead of three. (6) Page content shows even if the theme script fails to load (fail-safe after 4 s). (7) Elementor's global kit can no longer override theme headings. (8) Demo importer downloads stock photos instead of relying on bundled files.

**1.2.0** — Territories as child pages (main page + Connecticut, New Jersey, Massachusetts, Southeast USA) with interactive map, SVG territory graphics, coverage lists and local-service schema; franchise portal Log in / Register in the top bar, mobile menu, footer and franchise pages; rebuilt Franchise page; service pages gain on-page navigation, fit grid, preparation checklist, pricing factors and territory links; 5 new Elementor widgets (29 total); territories added to `/llms.txt`.
Build note: this version removed the stale minified files — the theme loads the readable `theme.css` / `theme.js` until you run `node tools/build-theme.cjs`, which regenerates the minified files and the zip.

**1.1.0** — Franchise portal integration; expanded answer-first service pages; per-page SEO fields; connected schema graph (LocalBusiness, Service, BreadcrumbList, HowTo, FAQ); `/llms.txt`, `/llms-full.txt` and `.md` page mirrors; AI-crawler rules in robots.txt; 3 new Elementor widgets (24 total).
Rebuild note: `assets/css/theme.min.css` is regenerated by `node tools/build-theme.cjs`; until then the theme automatically loads the readable `theme.css`.

**1.0.0** — Initial release.
